# NEXVERSE SMM — VPS / Hosting Panel Start

This project is a Node.js Telegram bot/API workspace. Some hosting panels require a root `.js` entry file; this package now includes `index.js` for that purpose.

## Recommended VPS setup

1. Install Node.js 22+.
2. Install/enable pnpm (Corepack is recommended):
   `corepack enable`
3. In the project folder run:
   `pnpm install --frozen-lockfile`
4. Build:
   `pnpm --dir artifacts/api-server build`
5. Configure environment variables from `.env.example` in the VPS panel.
6. Start with:
   `node index.js`
   or `pnpm start`

## Hosting panels that ask for a JavaScript file

Set the startup/entry file to:

`index.js`

Do not point the panel directly at a TypeScript source file.

## Important environment settings

For the Telegram bot, configure `BOT_TOKEN`, `ADMIN_TELEGRAM_IDS`, `ADMIN_PASSWORD`, `DATABASE_URL`, `UPI_ID`, and provider credentials as required by your deployment.

Keep `BOT_ENABLED=false` and `BOT_DELIVERY_ENABLED=false` until PostgreSQL and the production configuration are ready. Then enable them explicitly.

## If the panel only has "Node.js app" fields

- Application type: Node.js
- Node version: 22 or newer
- Entry/start file: `index.js`
- Install command: `corepack pnpm install --frozen-lockfile`
- Build command: `corepack pnpm --dir artifacts/api-server build`
- Start command: `node index.js`

The root `index.js` launches the existing production build; it does not replace or rebuild the NEXVERSE SMM application.
