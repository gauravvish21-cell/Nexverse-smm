#!/usr/bin/env bash
set -euo pipefail
# Restore ONLY after verifying the target database and taking a fresh backup.
FILE="${1:-}"
: "${POSTGRES_USER:?Set POSTGRES_USER}"
: "${POSTGRES_DB:?Set POSTGRES_DB}"
if [[ -z "$FILE" || ! -f "$FILE" ]]; then
  echo "Usage: POSTGRES_USER=... POSTGRES_DB=... $0 backups/file.sql.gz" >&2
  exit 2
fi
read -r -p "RESTORE WILL MODIFY THE TARGET DATABASE. Type RESTORE to continue: " CONFIRM
[[ "$CONFIRM" == "RESTORE" ]] || { echo "Cancelled."; exit 1; }
gunzip -c "$FILE" | docker compose exec -T db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1
echo "Restore completed."
