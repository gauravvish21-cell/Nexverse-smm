const fs=require('node:fs');
for (const f of ['pnpm-lock.yaml','yarn.lock']) { try { fs.rmSync(f,{force:true}); } catch {} }
