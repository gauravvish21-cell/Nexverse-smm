# NEXVERSE SMM production checklist

## Safety
1. Copy `.env.example` to `.env`.
2. Set `DATABASE_URL`, `BOT_TOKEN`, `ADMIN_TELEGRAM_IDS`, `ADMIN_PASSWORD`, and `UPI_ID`.
3. Keep `BOT_ENABLED=false` and `BOT_DELIVERY_ENABLED=false` until the deployment is verified.
4. Take a PostgreSQL backup before migrations.
5. Only then set the bot switches to `true` and start exactly one production polling instance.

## Docker
```bash
docker compose build
docker compose up -d db
# Apply the application's database setup/migrations using the project's existing setup procedure.
docker compose up -d bot
docker compose logs -f bot
```

## Backup
```bash
POSTGRES_USER=nexverse POSTGRES_DB=nexverse ./scripts/backup.sh
```

## Restore
Only after taking a fresh backup:
```bash
POSTGRES_USER=nexverse POSTGRES_DB=nexverse ./scripts/restore.sh backups/<file>.sql.gz
```

## Verification
Run:
```bash
pnpm --filter @workspace/api-server run typecheck
node --test artifacts/api-server/test/nexverse.test.mjs
pnpm run typecheck
```

The Telegram bot must not be considered production-ready until Telegram, PostgreSQL, and provider integration have also been exercised in the target VPS environment.
