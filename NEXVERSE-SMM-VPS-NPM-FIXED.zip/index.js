#!/usr/bin/env node
/** NEXVERSE SMM production entry point for VPS hosting panels. */
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import process from "node:process";

const apiDir = "artifacts/api-server";
const distEntry = `${apiDir}/dist/index.mjs`;

function run(args, cwd = process.cwd()) {
  const result = spawnSync(args[0], args.slice(1), { stdio: "inherit", cwd, env: process.env });
  if (result.error) { console.error(`NEXVERSE startup failed: ${result.error.message}`); process.exit(1); }
  if (result.status !== 0) process.exit(result.status ?? 1);
}

if (!existsSync(distEntry)) {
  console.log("NEXVERSE: production build not found; building existing API server...");
  run(["npm", "run", "build", "--workspace=@workspace/api-server"]);
}

console.log("NEXVERSE: starting production server...");
run(["--enable-source-maps", distEntry]);
