---
name: Production test-data boundary
description: Do not put synthetic customer or transaction records in the NEXVERSE product database.
---

Never seed demo or fake users, orders, payments, balances, or analytics into the product schema. Keep the live catalogue limited to its actual services.

**Why:** The owner explicitly prohibited fake customer and transaction data.

**How to apply:** Use an isolated, temporary test schema for integration tests and verify it is removed after the test run.