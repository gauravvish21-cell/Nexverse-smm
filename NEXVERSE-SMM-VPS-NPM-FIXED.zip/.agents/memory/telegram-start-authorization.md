---
name: Telegram start authorization
description: Approval rule for starting NEXVERSE Telegram polling and queued message delivery.
---

Do not start Telegram polling or queued message delivery until the user explicitly approves it.

**Why:** The user wants to prevent customer messages from being processed or queued replies from being sent before approval. Concurrent `getUpdates` pollers using the same bot token also conflict; the database advisory lock does not coordinate Replit's separate development and production databases.

**How to apply:** Before restarting the API workflow, verify the bot and delivery switches remain disabled unless the user has explicitly approved starting the bot. Before starting the production poller, stop the development poller so only one environment uses the token.