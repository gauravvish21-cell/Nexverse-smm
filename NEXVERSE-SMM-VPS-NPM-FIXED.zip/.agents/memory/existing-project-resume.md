---
name: Resuming existing projects
description: Verify that an existing project handoff opened the intended source before making changes.
---

When resuming a known Replit project, verify the actual source tree before editing or running database operations. A title-based transition may leave the conversation in a generic starter workspace rather than the indexed project's code.

**Why:** After selecting the existing NEXORA project by name, the opened workspace contained only generic scaffolding, while the bot source existed only in the uploaded archive.

**How to apply:** Check expected feature files and Git history first. If they are absent, pause before copying archives or touching the configured database; have the user open the actual project workspace.