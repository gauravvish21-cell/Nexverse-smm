import test from "node:test";
import assert from "node:assert/strict";
import { catalogue } from "../src/nexverse/catalogue.mjs";
import { DomainError, money, price, quantity, rupees, targetUrl } from "../src/nexverse/money.mjs";
import { detectImageContentType } from "../src/nexverse/image-validation.mjs";
import { classifyOutboxFailure } from "../src/nexverse/outbox-policy.mjs";
import { missingRequiredBotConfiguration } from "../src/nexverse/config.mjs";
import { getUserSafeErrorMessage } from "../src/nexverse/user-errors.mjs";
import { config } from "../src/nexverse/config.mjs";
import { configuredAdminRole, roleCan } from "../src/nexverse/admin-auth.mjs";
import { assertCallbackData } from "../src/nexverse/telegram-callback.mjs";

test("official catalogue contains 50 services with exact 2x customer prices", () => {
  assert.equal(catalogue.length, 50);
  assert.deepEqual(catalogue.map((service) => service.id), Array.from({ length: 50 }, (_, index) => index + 1));
  for (const service of catalogue) {
    assert.ok(service.supplier_paise > 0);
    assert.equal(service.customer_paise, service.supplier_paise * 2);
  }
});

test("money stays exact in micro-rupees and formats without floating point", () => {
  assert.equal(money("12.34"), 12_340_000n);
  assert.equal(rupees(12_340_000n), "₹12.34");
  assert.equal(rupees(-1_250_000n), "-₹1.25");
  assert.equal(price({ customer_paise: "3334", minimum: 10, maximum: 50000 }, 1000), 33_340_000n);
});

test("money and quantity reject malformed or out-of-range values", () => {
  assert.throws(() => money("1.001"), DomainError);
  assert.throws(() => money("-1"), DomainError);
  assert.throws(() => quantity("9", { minimum: 10, maximum: 100 }), DomainError);
  assert.throws(() => quantity("101", { minimum: 10, maximum: 100 }), DomainError);
});

test("targets must be public HTTPS links", () => {
  assert.equal(targetUrl("https://t.me/channel"), "https://t.me/channel");
  for (const value of ["http://example.com", "https://localhost/a", "https://127.0.0.1/a", "https://user:pass@example.com/a"]) {
    assert.throws(() => targetUrl(value), DomainError);
  }
});

test("screenshot uploads are checked against actual JPEG, PNG, and WebP signatures", () => {
  assert.equal(detectImageContentType(Uint8Array.from([0xff, 0xd8, 0xff, 0x00])), "image/jpeg");
  assert.equal(
    detectImageContentType(Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])),
    "image/png",
  );
  assert.equal(
    detectImageContentType(Uint8Array.from([0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50])),
    "image/webp",
  );
  assert.equal(detectImageContentType(Uint8Array.from([0x00, 0x01, 0x02, 0x03])), undefined);
});

test("outbox retries transient failures with bounded delay and stops at the attempt limit", () => {
  assert.deepEqual(classifyOutboxFailure(429, 2, 1), {
    status: "PENDING",
    waitSeconds: 2,
    safeCode: "429",
  });
  assert.deepEqual(classifyOutboxFailure(0, undefined, 1), {
    status: "PENDING",
    waitSeconds: 5,
    safeCode: "NETWORK",
  });
  assert.deepEqual(classifyOutboxFailure(503, undefined, 2), {
    status: "PENDING",
    waitSeconds: 10,
    safeCode: "503",
  });
  assert.equal(classifyOutboxFailure(400, undefined, 1).status, "FAILED");
  assert.equal(classifyOutboxFailure(503, undefined, 8).status, "FAILED");
});

test("required bot credentials are reported without exposing their values", () => {
  assert.deepEqual(
    missingRequiredBotConfiguration({ token: "", adminPassword: "" }),
    ["BOT_TOKEN", "ADMIN_PASSWORD"],
  );
  assert.deepEqual(
    missingRequiredBotConfiguration({ token: "present", adminPassword: "present" }),
    [],
  );
});

test("only domain validation messages are returned to Telegram users", () => {
  assert.equal(getUserSafeErrorMessage(new DomainError("Invalid quantity.")), "Invalid quantity.");
  assert.equal(
    getUserSafeErrorMessage(new Error('relation "nx_users" does not exist at query...')),
    undefined,
  );
});

test("the configured Telegram ID resolves to the owner role with owner-only permissions", () => {
  const configuredValue = process.env.ADMIN_TELEGRAM_IDS?.trim();
  if (!configuredValue) return;
  const configuredValues = configuredValue.split(",").map((value) => value.trim()).filter(Boolean);
  assert.deepEqual(config.adminIds, [...new Set(configuredValues)]);
  const ownerRole = configuredAdminRole(config.adminIds[0], config.adminIds);
  assert.equal(ownerRole, "OWNER");
  assert.equal(configuredAdminRole("", config.adminIds), null);
  assert.equal(roleCan(ownerRole, "payments"), true);
  assert.equal(roleCan(ownerRole, "maintenance"), true);
  assert.equal(roleCan("PAYMENT_ADMIN", "payments"), true);
  assert.equal(roleCan("PAYMENT_ADMIN", "orders"), false);
});
test("Telegram callback data is limited to 64 UTF-8 bytes", () => {
  assertCallbackData("adm:ss:12345678-1234-4123-8123-123456789012:WAITING_USER");
  assert.throws(() => assertCallbackData("😀".repeat(17)), /exceeds 64 bytes/);
  assert.equal(Buffer.byteLength("😀".repeat(16), "utf8"), 64);
});
