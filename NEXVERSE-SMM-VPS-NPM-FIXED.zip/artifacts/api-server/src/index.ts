import app from "./app";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";
import { startTelegramBot, stopTelegramBot } from "./nexverse/bot";

const port = Number(process.env["PORT"] || 3000);
if (!Number.isInteger(port) || port <= 0 || port > 65535) {
  throw new Error("Invalid PORT value.");
}

const server = app.listen(port, "0.0.0.0", () => {
  logger.info({ port, host: "0.0.0.0" }, "Server listening");
  void startTelegramBot().catch((error) => {
    logger.error(
      { errorCode: (error as { code?: string })?.code ?? "BOT_START" },
      "Telegram bot startup failed",
    );
  });
});

let shuttingDown = false;
async function shutdown(signal: string) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, "Server shutdown started");
  await stopTelegramBot();
  await new Promise<void>((resolve) => server.close(() => resolve()));
  await pool.end();
  process.exit(0);
}

process.once("SIGINT", () => void shutdown("SIGINT"));
process.once("SIGTERM", () => void shutdown("SIGTERM"));
