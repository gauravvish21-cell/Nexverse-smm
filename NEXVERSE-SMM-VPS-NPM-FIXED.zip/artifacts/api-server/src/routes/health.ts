import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";
import { getBotRuntimeHealth } from "../nexverse/bot";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

router.get("/nexverse/healthz", async (_req, res) => {
  const health = await getBotRuntimeHealth();
  const configured = health.bot.configured;
  const botReady =
    configured &&
    (!health.bot.enabled || (health.bot.running && health.bot.healthy));
  res.status(health.database && botReady ? 200 : 503).json(health);
});

export default router;
