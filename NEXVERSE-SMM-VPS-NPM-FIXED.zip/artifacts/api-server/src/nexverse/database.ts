import { randomUUID } from "node:crypto";
import { pool } from "@workspace/db";
import { assert, DomainError, money, price, quantity, rupees, targetUrl, text } from "./money.mjs";

type Queryable = { query: (sql: string, values?: unknown[]) => Promise<{ rows: Record<string, unknown>[]; rowCount: number | null }> };
type Client = Queryable & { release: () => void };

export { pool };

export async function transaction<T>(work: (client: Client) => Promise<T>): Promise<T> {
  const client = await pool.connect() as unknown as Client;
  try {
    await client.query("BEGIN");
    await client.query("SET LOCAL lock_timeout = '10s'");
    await client.query("SET LOCAL statement_timeout = '30s'");
    const result = await work(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    if ((error as { code?: string }).code === "23505") {
      throw new DomainError("That reference has already been used.", "DUPLICATE");
    }
    throw error;
  } finally {
    client.release();
  }
}

export async function one<T extends Record<string, unknown>>(db: Queryable, sql: string, values: unknown[] = []): Promise<T | undefined> {
  const result = await db.query(sql, values);
  return result.rows[0] as T | undefined;
}

export async function audit(db: Queryable, actorId: string | number | null, action: string, target: string, details: Record<string, unknown> = {}, amount: bigint | null = null) {
  await db.query(
    "INSERT INTO nx_audit(id,actor_id,action,target,amount,details) VALUES($1,$2,$3,$4,$5,$6::jsonb)",
    [randomUUID(), actorId, action, target, amount?.toString() ?? null, JSON.stringify(details)],
  );
}

export async function enqueueOutbox(db: Queryable, chatId: string | number, message: string, dedupeKey: string, replyMarkup?: unknown) {
  const params: Record<string, unknown> = { chat_id: String(chatId), text: message };
  if (replyMarkup) params.reply_markup = replyMarkup;
  await db.query(
    "INSERT INTO nx_outbox(id,method,params,dedupe_key) VALUES($1,'sendMessage',$2::jsonb,$3) ON CONFLICT(dedupe_key) DO NOTHING",
    [randomUUID(), JSON.stringify(params), dedupeKey],
  );
}

export async function notifyUser(db: Queryable, userId: string | number, kind: string, message: string, dedupeKey: string) {
  const inserted = await db.query(
    "INSERT INTO nx_notifications(id,user_id,kind,body,dedupe_key) VALUES($1,$2,$3,$4,$5) ON CONFLICT(dedupe_key) DO NOTHING RETURNING id",
    [randomUUID(), userId, kind, message, dedupeKey],
  );
  if (inserted.rowCount) await enqueueOutbox(db, userId, message, `notification:${dedupeKey}`);
}

export interface TelegramIdentity {
  id: string;
  username?: string;
  name: string;
}

export async function ensureUser(identity: TelegramIdentity) {
  assert(/^\d{1,20}$/.test(identity.id), "Invalid Telegram account.");
  const name = text(identity.name || identity.username || "Telegram user", 160);
  await transaction(async (db) => {
    await db.query(
      `INSERT INTO nx_users(id,username,name,referral_code)
       VALUES($1,$2,$3,$4)
       ON CONFLICT(id) DO UPDATE SET username=EXCLUDED.username,name=EXCLUDED.name,updated_at=now()`,
      [identity.id, identity.username?.slice(0, 64) || null, name, `NX${randomUUID().replaceAll("-", "").slice(0, 8).toUpperCase()}`],
    );
    await db.query("INSERT INTO nx_wallets(user_id,balance) VALUES($1,0) ON CONFLICT(user_id) DO NOTHING", [identity.id]);
    await db.query("INSERT INTO nx_sessions(user_id) VALUES($1) ON CONFLICT(user_id) DO NOTHING", [identity.id]);
  });
}

export async function attachReferral(newUserId: string, referralCode: string) {
  if (!/^[A-Z0-9]{5,20}$/i.test(referralCode)) return false;
  return transaction(async (db) => {
    const referrer = await one<{ id: string }>(
      db,
      "SELECT id::text FROM nx_users WHERE upper(referral_code)=upper($1) LIMIT 1",
      [referralCode],
    );
    if (!referrer || referrer.id === newUserId) return false;
    const result = await db.query(
      "INSERT INTO nx_referrals(referred_id,referrer_id) VALUES($1,$2) ON CONFLICT(referred_id) DO NOTHING",
      [newUserId, referrer.id],
    );
    if (result.rowCount) await audit(db, newUserId, "REFERRAL_JOINED", referrer.id, {});
    return Boolean(result.rowCount);
  });
}

export async function createOrderDraft(userId: string, serviceId: number, inputQuantity: string, inputTarget: string, extras = "") {
  return transaction(async (db) => {
    const service = await one<{
      id: number; name: string; customer_paise: string; minimum: number; maximum: number; enabled: boolean;
    }>(db, "SELECT id,name,customer_paise,minimum,maximum,enabled FROM nx_services WHERE id=$1", [serviceId]);
    assert(service && service.enabled, "This service is unavailable.", "NOT_FOUND");
    const q = quantity(inputQuantity, service);
    const target = targetUrl(inputTarget);
    const total = price(service, q);
    assert(total > 0n && total <= 9223372036854775807n, "This order amount is outside the supported range.");
    const id = randomUUID();
    await db.query(
      "INSERT INTO nx_order_drafts(id,user_id,service_id,quantity,target,quoted_amount,extras) VALUES($1,$2,$3,$4,$5,$6,$7)",
      [id, userId, serviceId, q, target, total.toString(), extras ? text(extras, 1000) : ""],
    );
    await db.query(
      `INSERT INTO nx_recent_services(user_id,service_id,last_used_at) VALUES($1,$2,now())
       ON CONFLICT(user_id,service_id) DO UPDATE SET last_used_at=now()`,
      [userId, serviceId],
    );
    return { id, service, quantity: q, target, amount: total };
  });
}

export async function placeOrder(userId: string, draftId: string) {
  return transaction(async (db) => {
    const maintenance = await one<{ value: Record<string, unknown> }>(db, "SELECT value FROM nx_settings WHERE key='maintenance' FOR SHARE");
    assert(maintenance?.value?.enabled !== true && maintenance?.value?.orders !== true, "Ordering is temporarily paused.", "MAINTENANCE");
    const draft = await one<{
      id: string; user_id: string; service_id: number; quantity: number; target: string;
      quoted_amount: string; extras: string; coupon_code: string | null; discount: string;
    }>(db, "SELECT id,user_id::text,service_id,quantity,target,quoted_amount::text,extras,coupon_code,discount::text FROM nx_order_drafts WHERE id=$1 FOR UPDATE", [draftId]);
    assert(draft && draft.user_id === userId, "This order confirmation is no longer available.", "NOT_FOUND");
    const previous = await one<{ id: string; amount: string }>(db, "SELECT id,amount::text FROM nx_orders WHERE draft_id=$1", [draftId]);
    if (previous) return { id: previous.id, amount: BigInt(previous.amount), duplicate: true };
    const service = await one<{ name: string; enabled: boolean; customer_paise: string; minimum: number; maximum: number }>(
      db, "SELECT name,enabled,customer_paise::text,minimum,maximum FROM nx_services WHERE id=$1", [draft.service_id],
    );
    assert(service && service.enabled, "This service is no longer available.", "NOT_FOUND");
    const expected = price(service, draft.quantity);
    assert(expected.toString() === draft.quoted_amount, "The price changed. Please start again.", "PRICE_CHANGED");
    const discount = BigInt(draft.discount);
    assert(discount >= 0n && discount < expected && Boolean(draft.coupon_code) === (discount > 0n), "Order discount is invalid.", "COUPON");
    const amount = expected - discount;
    assert(amount > 0n && amount <= 9223372036854775807n, "This order amount is outside the supported range.");
    const wallet = await one<{ balance: string }>(db, "SELECT balance::text FROM nx_wallets WHERE user_id=$1 FOR UPDATE", [userId]);
    assert(wallet, "Your wallet is not ready. Use /start and try again.", "WALLET");
    const balance = BigInt(wallet.balance);
    assert(balance >= amount, "Your wallet balance is too low. Add funds, then try again.", "BALANCE");
    const orderId = randomUUID();
    await db.query(
      `INSERT INTO nx_orders(id,user_id,service_id,draft_id,quantity,target,amount,service_name,extras)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [orderId, userId, draft.service_id, draft.id, draft.quantity, draft.target, amount.toString(), service.name, draft.extras],
    );
    const result = await db.query("UPDATE nx_wallets SET balance=balance-$1,updated_at=now() WHERE user_id=$2 AND balance >= $1 RETURNING balance::text", [amount.toString(), userId]);
    assert(result.rowCount === 1, "Wallet balance changed. Please review your balance and try again.", "BALANCE");
    await db.query(
      `INSERT INTO nx_ledger(id,user_id,type,amount,balance_before,balance_after,reference_id,description)
       VALUES($1,$2,'ORDER_DEBIT',$3,$4,$5,$6,$7)`,
      [randomUUID(), userId, (-amount).toString(), balance.toString(), (balance - amount).toString(), orderId, `Order ${orderId}`],
    );
    await db.query(
      "INSERT INTO nx_order_items(order_id,service_id,quantity,customer_paise,amount) VALUES($1,$2,$3,$4,$5)",
      [orderId, draft.service_id, draft.quantity, service.customer_paise, amount.toString()],
    );
    if (draft.coupon_code) {
      const coupon = await one<{ code: string }>(
        db, "UPDATE nx_coupons SET used=used+1 WHERE code=$1 AND enabled=true AND used<maximum_uses AND (expiry IS NULL OR expiry>now()) RETURNING code",
        [draft.coupon_code],
      );
      assert(coupon, "That coupon is no longer available. Please start a new order.", "COUPON");
      await db.query("INSERT INTO nx_coupon_uses(code,user_id,order_id,discount) VALUES($1,$2,$3,$4)", [coupon.code, userId, orderId, discount.toString()]);
    }
    await audit(db, userId, "ORDER_CREATED", orderId, { serviceId: draft.service_id, quantity: draft.quantity }, amount);
    const note = `Order ${orderId} was placed. Status: PENDING.`;
    await notifyUser(db, userId, "ORDER_CREATED", note, `order-created:${orderId}`);
    return { id: orderId, amount, duplicate: false };
  });
}

export async function applyCouponToDraft(userId: string, draftId: string, rawCode: string) {
  const code = text(rawCode.toUpperCase(), 40);
  assert(/^[A-Z0-9-]{3,32}$/.test(code), "Enter a valid coupon code.");
  return transaction(async (db) => {
    const draft = await one<{ id: string; quoted_amount: string; user_id: string }>(
      db, "SELECT id,user_id::text,quoted_amount::text FROM nx_order_drafts WHERE id=$1 FOR UPDATE", [draftId],
    );
    assert(draft && draft.user_id === userId, "Order draft expired.", "NOT_FOUND");
    const coupon = await one<{ code: string; percent: number; enabled: boolean; used: number; maximum_uses: number; expiry: Date | null }>(
      db, "SELECT code,percent,enabled,used,maximum_uses,expiry FROM nx_coupons WHERE code=$1 FOR UPDATE", [code],
    );
    assert(coupon && coupon.enabled && coupon.used < coupon.maximum_uses && (!coupon.expiry || coupon.expiry.getTime() > Date.now()), "Coupon is invalid, expired, or fully used.", "COUPON");
    const prior = await one<{ order_id: string }>(db, "SELECT order_id FROM nx_coupon_uses WHERE code=$1 AND user_id=$2", [code, userId]);
    assert(!prior, "You have already used this coupon.", "DUPLICATE");
    const quoted = BigInt(draft.quoted_amount);
    const discount = (quoted * BigInt(coupon.percent) / 100n / 10000n) * 10000n;
    assert(discount > 0n && discount < quoted, "This coupon would make the order free or has no monetary discount.", "COUPON");
    await db.query("UPDATE nx_order_drafts SET coupon_code=$1,discount=$2 WHERE id=$3", [code, discount.toString(), draftId]);
    await audit(db, userId, "COUPON_APPLIED", draftId, { code, percent: coupon.percent }, discount);
    return { code, percent: coupon.percent, discount, amount: quoted - discount };
  });
}

export async function createPayment(
  userId: string,
  identity: { username?: string; name: string },
  amount: bigint,
  utr: string,
  asset: { id: string; fileId: string; size: number; sha256: string; contentType: string },
) {
  assert(amount > 0n && amount <= 100000000000000n, "Enter a valid deposit amount.");
  assert(/^[A-Za-z0-9-]{6,32}$/.test(utr), "Enter a valid UTR/reference (6–32 letters or digits).");
  assert(["image/jpeg", "image/png", "image/webp"].includes(asset.contentType), "Upload a JPEG, PNG, or WebP screenshot.");
  assert(asset.size > 0 && asset.size <= 10 * 1024 * 1024 && /^[a-f0-9]{64}$/i.test(asset.sha256), "Screenshot is invalid.");
  return transaction(async (db) => {
    const maintenance = await one<{ value: Record<string, unknown> }>(db, "SELECT value FROM nx_settings WHERE key='maintenance' FOR SHARE");
    assert(maintenance?.value?.enabled !== true && maintenance?.value?.payments !== true, "Payments are temporarily paused.", "MAINTENANCE");
    const requestKey = randomUUID();
    const paymentId = randomUUID();
    await db.query(
      `INSERT INTO nx_assets(id,user_id,object_key,telegram_file_id,content_type,size,sha256)
       VALUES($1,$2,$3,$4,$5,$6,$7)`,
      [asset.id, userId, `telegram-file:${asset.id}`, asset.fileId, asset.contentType, asset.size, asset.sha256],
    );
    await db.query(
      `INSERT INTO nx_payments(id,user_id,username,user_name,amount,utr,screenshot_id,request_key)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,
      [paymentId, userId, identity.username?.slice(0, 64) || null, text(identity.name, 160), amount.toString(), utr.toUpperCase(), asset.id, requestKey],
    );
    await audit(db, userId, "PAYMENT_SUBMITTED", paymentId, { utr: utr.toUpperCase() }, amount);
    await notifyUser(db, userId, "PAYMENT_SUBMITTED", `Deposit request ${paymentId} is pending review.`, `payment-submitted:${paymentId}`);
    return paymentId;
  });
}

export async function approvePayment(paymentId: string, adminId: string) {
  return transaction(async (db) => {
    const payment = await one<{ id: string; user_id: string; amount: string; status: string }>(
      db, "SELECT id,user_id::text,amount::text,status FROM nx_payments WHERE id=$1 FOR UPDATE", [paymentId],
    );
    assert(payment, "Payment not found.", "NOT_FOUND");
    if (payment.status !== "PENDING") return { status: payment.status, duplicate: true };
    const wallet = await one<{ balance: string }>(db, "SELECT balance::text FROM nx_wallets WHERE user_id=$1 FOR UPDATE", [payment.user_id]);
    assert(wallet, "Wallet not found.", "WALLET");
    const amount = BigInt(payment.amount);
    const balance = BigInt(wallet.balance);
    const updated = await db.query(
      "UPDATE nx_payments SET status='APPROVED',reviewed_by=$1,reviewed_at=now(),updated_at=now() WHERE id=$2 AND status='PENDING' RETURNING id",
      [adminId, paymentId],
    );
    if (!updated.rowCount) return { status: "APPROVED", duplicate: true };
    await db.query("UPDATE nx_wallets SET balance=balance+$1,updated_at=now() WHERE user_id=$2", [amount.toString(), payment.user_id]);
    await db.query(
      `INSERT INTO nx_ledger(id,user_id,type,amount,balance_before,balance_after,reference_id,created_by,description)
       VALUES($1,$2,'DEPOSIT',$3,$4,$5,$6,$7,$8)`,
      [randomUUID(), payment.user_id, amount.toString(), balance.toString(), (balance + amount).toString(), paymentId, adminId, `Approved payment ${paymentId}`],
    );
    await audit(db, adminId, "PAYMENT_APPROVED", paymentId, {}, amount);
    await notifyUser(db, payment.user_id, "PAYMENT_APPROVED", `Your deposit of ${rupees(amount)} was approved.`, `payment-approved:${paymentId}`);
    await maybeRewardReferral(db, payment.user_id, amount, paymentId);
    return { status: "APPROVED", duplicate: false };
  });
}

async function maybeRewardReferral(db: Queryable, referredId: string, deposit: bigint, paymentId: string) {
  const setting = await one<{ value: { enabled?: boolean; reward?: string; minimum_deposit?: string } }>(
    db, "SELECT value FROM nx_settings WHERE key='referral'",
  );
  const reward = BigInt(setting?.value?.reward || "0");
  const minDeposit = BigInt(setting?.value?.minimum_deposit || "0");
  if (!setting?.value?.enabled || reward <= 0n || deposit < minDeposit) return;
  const referral = await one<{ referrer_id: string; reward_status: string }>(
    db, "SELECT referrer_id::text,reward_status FROM nx_referrals WHERE referred_id=$1 FOR UPDATE", [referredId],
  );
  if (!referral || referral.reward_status !== "PENDING") return;
  const wallet = await one<{ balance: string }>(db, "SELECT balance::text FROM nx_wallets WHERE user_id=$1 FOR UPDATE", [referral.referrer_id]);
  if (!wallet) return;
  const before = BigInt(wallet.balance);
  await db.query("UPDATE nx_wallets SET balance=balance+$1,updated_at=now() WHERE user_id=$2", [reward.toString(), referral.referrer_id]);
  await db.query(
    `INSERT INTO nx_ledger(id,user_id,type,amount,balance_before,balance_after,reference_id,description)
     VALUES($1,$2,'BONUS',$3,$4,$5,$6,$7)`,
    [randomUUID(), referral.referrer_id, reward.toString(), before.toString(), (before + reward).toString(), `referral:${referredId}`, `Referral reward after ${paymentId}`],
  );
  await db.query("UPDATE nx_referrals SET reward_status='REWARDED',amount=$1,rewarded_at=now() WHERE referred_id=$2 AND reward_status='PENDING'", [reward.toString(), referredId]);
  await notifyUser(db, referral.referrer_id, "REFERRAL_REWARD", "A referral reward was added to your wallet.", `referral-reward:${referredId}`);
}

export async function rejectPayment(paymentId: string, adminId: string, reason: string) {
  const safeReason = text(reason, 300);
  return transaction(async (db) => {
    const result = await db.query(
      `UPDATE nx_payments SET status='REJECTED',reviewed_by=$1,reviewed_at=now(),updated_at=now(),rejection_reason=$2
       WHERE id=$3 AND status='PENDING' RETURNING user_id::text,amount::text`,
      [adminId, safeReason, paymentId],
    );
    if (!result.rowCount) {
      const current = await one<{ status: string }>(db, "SELECT status FROM nx_payments WHERE id=$1", [paymentId]);
      assert(current, "Payment not found.", "NOT_FOUND");
      return { status: current.status, duplicate: true };
    }
    const row = result.rows[0];
    await audit(db, adminId, "PAYMENT_REJECTED", paymentId, { reason: safeReason }, BigInt(row.amount as string));
    await notifyUser(db, row.user_id as string, "PAYMENT_REJECTED", `Your deposit request was rejected. Reason: ${safeReason}`, `payment-rejected:${paymentId}`);
    return { status: "REJECTED", duplicate: false };
  });
}

export async function rejectAndRefund(orderId: string, adminId: string, reason: string) {
  const safeReason = text(reason, 300);
  return transaction(async (db) => {
    const order = await one<{ user_id: string; status: string }>(
      db, "SELECT user_id::text,status FROM nx_orders WHERE id=$1 FOR UPDATE", [orderId],
    );
    assert(order, "Order not found.", "NOT_FOUND");
    const existing = await one<{ amount: string }>(db, "SELECT amount::text FROM nx_refunds WHERE order_id=$1", [orderId]);
    if (existing) return { refunded: true, duplicate: true, amount: BigInt(existing.amount) };
    assert(order.status === "PENDING", "Only pending orders can be rejected and refunded.", "STATUS");
    const debit = await one<{ id: string; amount: string }>(
      db, "SELECT id,amount::text FROM nx_ledger WHERE user_id=$1 AND type='ORDER_DEBIT' AND reference_id=$2 FOR UPDATE", [order.user_id, orderId],
    );
    assert(debit && BigInt(debit.amount) < 0n, "The original order debit was not found.", "LEDGER");
    const amount = -BigInt(debit.amount);
    const wallet = await one<{ balance: string }>(db, "SELECT balance::text FROM nx_wallets WHERE user_id=$1 FOR UPDATE", [order.user_id]);
    assert(wallet, "Wallet not found.", "WALLET");
    const before = BigInt(wallet.balance);
    await db.query("UPDATE nx_wallets SET balance=balance+$1,updated_at=now() WHERE user_id=$2", [amount.toString(), order.user_id]);
    const ledgerId = randomUUID();
    await db.query(
      `INSERT INTO nx_ledger(id,user_id,type,amount,balance_before,balance_after,reference_id,created_by,description)
       VALUES($1,$2,'REFUND',$3,$4,$5,$6,$7,$8)`,
      [ledgerId, order.user_id, amount.toString(), before.toString(), (before + amount).toString(), orderId, adminId, `Refund for order ${orderId}`],
    );
    await db.query(
      "INSERT INTO nx_refunds(order_id,debit_id,ledger_id,amount,admin_id,reason) VALUES($1,$2,$3,$4,$5,$6)",
      [orderId, debit.id, ledgerId, amount.toString(), adminId, safeReason],
    );
    await db.query("UPDATE nx_orders SET status='REFUNDED',updated_at=now(),internal_notes=concat(internal_notes,$2::text) WHERE id=$1", [orderId, `\nReject & refund: ${safeReason}`]);
    await audit(db, adminId, "ORDER_REFUNDED", orderId, { reason: safeReason }, amount);
    await notifyUser(db, order.user_id, "REFUND", `Order ${orderId} was rejected and refunded to your wallet.`, `order-refund:${orderId}`);
    return { refunded: true, duplicate: false, amount };
  });
}

export async function redeemCode(userId: string, rawCode: string) {
  const code = text(rawCode.toUpperCase(), 40);
  assert(/^[A-Z0-9-]{3,32}$/.test(code), "Enter a valid redeem code.");
  return transaction(async (db) => {
    const row = await one<{ code: string; amount: string; enabled: boolean; current_redemptions: number; maximum_redemptions: number; expiry: string | null; starts_at: string }>(
      db, "SELECT code,amount::text,enabled,current_redemptions,maximum_redemptions,expiry,starts_at FROM nx_redeem_codes WHERE code=$1 FOR UPDATE", [code],
    );
    assert(row && row.enabled && (!row.expiry || new Date(row.expiry).getTime() > Date.now()) && new Date(row.starts_at).getTime() <= Date.now(), "This code is invalid or expired.", "CODE");
    assert(row.current_redemptions < row.maximum_redemptions, "This code has reached its redemption limit.", "LIMIT");
    const existing = await one<{ id: string }>(db, "SELECT id FROM nx_redemptions WHERE code=$1 AND user_id=$2", [code, userId]);
    assert(!existing, "You have already used this code.", "DUPLICATE");
    const wallet = await one<{ balance: string }>(db, "SELECT balance::text FROM nx_wallets WHERE user_id=$1 FOR UPDATE", [userId]);
    assert(wallet, "Wallet not found.", "WALLET");
    const amount = BigInt(row.amount);
    const before = BigInt(wallet.balance);
    const id = randomUUID();
    await db.query("INSERT INTO nx_redemptions(id,user_id,code,amount) VALUES($1,$2,$3,$4)", [id, userId, code, amount.toString()]);
    await db.query("UPDATE nx_wallets SET balance=balance+$1,updated_at=now() WHERE user_id=$2", [amount.toString(), userId]);
    await db.query(
      `INSERT INTO nx_ledger(id,user_id,type,amount,balance_before,balance_after,reference_id,description)
       VALUES($1,$2,'REDEEM',$3,$4,$5,$6,$7)`,
      [randomUUID(), userId, amount.toString(), before.toString(), (before + amount).toString(), id, `Redeemed ${code}`],
    );
    await db.query("UPDATE nx_redeem_codes SET current_redemptions=current_redemptions+1 WHERE code=$1", [code]);
    await notifyUser(db, userId, "REDEEM", "Your redeem code was accepted and your wallet was credited.", `redeem:${id}`);
    await audit(db, userId, "REDEEMED", code, {}, amount);
    return amount;
  });
}

export async function adjustWallet(userId: string, adminId: string, amount: bigint, reason: string, operationId: string) {
  const safeReason = text(reason, 300);
  assert(amount !== 0n && amount <= 100000000000000n && amount >= -100000000000000n, "Wallet adjustment amount is outside the supported range.");
  return transaction(async (db) => {
    const operation = await one<{ confirmed_at: string | null; data: { userId: string; amount: string; reason: string }; result: { balance?: string } | null }>(
      db, "SELECT confirmed_at,data,result FROM nx_operations WHERE key=$1 AND actor_id=$2 AND kind='WALLET_ADJUSTMENT' FOR UPDATE", [operationId, adminId],
    );
    assert(operation, "This adjustment confirmation expired.", "NOT_FOUND");
    if (operation.confirmed_at) return { duplicate: true, balance: operation.result?.balance ?? "0" };
    assert(operation.data.userId === userId && operation.data.amount === amount.toString() && operation.data.reason === safeReason, "Adjustment details do not match.", "INVALID");
    const wallet = await one<{ balance: string }>(db, "SELECT balance::text FROM nx_wallets WHERE user_id=$1 FOR UPDATE", [userId]);
    assert(wallet, "Wallet not found.", "WALLET");
    const before = BigInt(wallet.balance);
    const after = before + amount;
    assert(after >= 0n && after <= 9223372036854775807n, "That adjustment would leave an invalid wallet balance.");
    await db.query("UPDATE nx_wallets SET balance=$1,updated_at=now() WHERE user_id=$2", [after.toString(), userId]);
    await db.query(
      `INSERT INTO nx_ledger(id,user_id,type,amount,balance_before,balance_after,reference_id,created_by,description)
       VALUES($1,$2,'ADMIN_ADJUSTMENT',$3,$4,$5,$6,$7,$8)`,
      [randomUUID(), userId, amount.toString(), before.toString(), after.toString(), operationId, adminId, safeReason],
    );
    await db.query("UPDATE nx_operations SET confirmed_at=now(),result=$2::jsonb WHERE key=$1 AND confirmed_at IS NULL", [operationId, JSON.stringify({ balance: after.toString() })]);
    await audit(db, adminId, "WALLET_ADJUSTMENT", userId, { reason: safeReason }, amount);
    await notifyUser(db, userId, "WALLET_ADJUSTMENT", `An administrator adjusted your wallet. Reason: ${safeReason}`, `wallet-adjustment:${operationId}`);
    return { duplicate: false, balance: after.toString() };
  });
}

export async function isMaintenanceEnabled(key: "enabled" | "orders" | "payments" | "services") {
  const setting = await one<{ value: Record<string, unknown> }>(pool, "SELECT value FROM nx_settings WHERE key='maintenance'");
  return setting?.value?.[key] === true;
}