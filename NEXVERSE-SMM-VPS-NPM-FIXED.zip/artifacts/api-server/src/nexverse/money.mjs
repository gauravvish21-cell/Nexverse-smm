export class DomainError extends Error {
  constructor(message, code = "INVALID") { super(message); this.code = code; }
}
export function assert(condition, message, code) {
  if (!condition) throw new DomainError(message, code);
}
// One unit is 0.000001 INR. A paise-per-1000 rate multiplied by quantity
// is always an integer in this representation; no floating point arithmetic.
export function money(input) {
  assert(typeof input === "string" && /^\d{1,10}(\.\d{1,2})?$/.test(input.trim()), "Enter a positive INR amount with at most two decimal places.");
  const [whole, fraction = ""] = input.trim().split(".");
  const units = BigInt(whole) * 1000000n + BigInt(fraction.padEnd(6, "0"));
  assert(units > 0n && units <= 100000000000000n, "Amount must be greater than zero and no more than ₹100,000,000.");
  return units;
}
export function rupees(units) {
  const n = BigInt(units), sign = n < 0n ? "-" : "", v = n < 0n ? -n : n;
  const f = (v % 1000000n).toString().padStart(6, "0").replace(/0+$/, "").padEnd(2, "0");
  return `${sign}₹${v / 1000000n}.${f}`;
}
export function quantity(input, service) {
  assert(/^\d+$/.test(String(input)), "Quantity must be a whole number.");
  const q = Number(input);
  assert(Number.isSafeInteger(q) && q >= service.minimum && q <= service.maximum, `Quantity must be ${service.minimum}–${service.maximum}.`);
  return q;
}
export function price(service, q) { return BigInt(service.customer_paise) * 10n * BigInt(quantity(q, service)); }
export function targetUrl(input) {
  let u;
  try { u = new URL(String(input)); } catch { throw new DomainError("Enter a valid public https:// target link."); }
  assert(u.protocol === "https:" && !u.username && !u.password && String(input).length <= 2048, "Enter a valid public https:// target link.");
  assert(!/^(localhost|127\.|0\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|::1|\[)/i.test(u.hostname) && u.hostname.includes("."), "Use a public target link.");
  return u.href;
}
export function text(input, max = 2000) {
  assert(typeof input === "string" && input.trim().length > 0 && input.length <= max, `Text is required (maximum ${max} characters).`);
  return input.trim();
}
export function escapeHtml(input) { return String(input).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]); }