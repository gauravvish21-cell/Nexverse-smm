export interface CatalogueService {
  id: number;
  name: string;
  category: string;
  platform: string;
  supplier_paise: number;
  customer_paise: number;
  minimum: number;
  maximum: number;
  description: string;
}
export const catalogue: CatalogueService[];
export function importCatalogue(db: { query: (sql: string, values?: unknown[]) => Promise<unknown> }): Promise<void>;