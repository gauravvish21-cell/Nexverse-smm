export type AdminRole =
  | "OWNER"
  | "SUPER_ADMIN"
  | "PAYMENT_ADMIN"
  | "ORDER_MANAGER"
  | "SERVICE_MANAGER"
  | "SUPPORT_AGENT"
  | "ANALYST";

export function configuredAdminRole(
  userId: string,
  adminIds: readonly string[],
): "OWNER" | null;
export function roleCan(role: AdminRole, capability: string): boolean;