import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { pool } from "@workspace/db";
import { catalogue, importCatalogue } from "./catalogue.mjs";
import { adjustWallet, applyCouponToDraft, approvePayment, createOrderDraft, createPayment, ensureUser, enqueueOutbox, notifyUser, placeOrder, redeemCode, rejectAndRefund, rejectPayment } from "./database";
import { processOutboxOnce } from "./outbox";
import { TelegramApiError } from "./telegram-api";
import { persistCompletedUpdate } from "./bot";
import { handleAdminCallback, roleCan } from "./admin";
import { isMaintenanceEnabled } from "./database";
import { editAdminUntil, setSession } from "./bot-utils";
import { handleCustomerCallback, handleCustomerMessage, homeScreen } from "./customer";
import { handleServiceBrowserCallback } from "./service-browser";

type DbClient = {
  query: (sql: string, values?: unknown[]) => Promise<{ rows: Array<Record<string, unknown>>; rowCount: number | null }>;
  release: () => void;
};
type TestPool = {
  options: { max: number; options?: string };
  connect: () => Promise<DbClient>;
  query: (sql: string, values?: unknown[]) => Promise<{ rows: Array<Record<string, unknown>>; rowCount: number | null }>;
  end: () => Promise<void>;
};

const testPool = pool as unknown as TestPool;
const schemaName = `nx_test_${randomUUID().replaceAll("-", "")}`;
const safeSchema = `"${schemaName}"`;
const userId = "8000000001";
const adminId = "8000000002";

async function balance() {
  const result = await pool.query("SELECT balance::text FROM nx_wallets WHERE user_id=$1", [userId]);
  return BigInt(String(result.rows[0]?.balance ?? "0"));
}

async function expectCode(action: Promise<unknown>, expectedCode: string) {
  await assert.rejects(action, (error: unknown) => (error as { code?: string })?.code === expectedCode);
}

async function main() {
  if (process.env.NODE_ENV !== "development" || process.env.NEXVERSE_TESTS !== "YES") {
    throw new Error("Integration tests are dev-only. Use the package test command against the development database.");
  }
  let schemaCreated = false;
  testPool.options.max = 1;
  testPool.options.options = `-c search_path=${schemaName}`;
  const originalFetch = globalThis.fetch;
  const telegramMessages: Array<Record<string, unknown>> = [];
  globalThis.fetch = async (_input, init) => {
    const payload = JSON.parse(String(init?.body ?? "{}")) as Record<string, unknown>;
    telegramMessages.push(payload);
    return new Response(JSON.stringify({
      ok: true,
      result: {
        message_id: telegramMessages.length,
        date: Math.floor(Date.now() / 1000),
        chat: { id: Number(payload.chat_id), type: "private" },
      },
    }), { status: 200, headers: { "content-type": "application/json" } });
  };
  try {
    const client = await pool.connect() as unknown as DbClient;
    try {
      await client.query(`CREATE SCHEMA ${safeSchema}`);
      schemaCreated = true;
      await client.query(`SET search_path TO ${safeSchema}`);
    } finally {
      client.release();
    }

    const here = dirname(fileURLToPath(import.meta.url));
    const schemaSql = await readFile(resolve(here, "../../src/nexverse/schema.sql"), "utf8");
    await pool.query(schemaSql);
    await importCatalogue(pool);
    const catalogCheck = await pool.query(
      "SELECT count(*)::int AS total,count(*) FILTER(WHERE customer_paise<>supplier_paise*2)::int AS bad FROM nx_services",
    );
    assert.equal(Number(catalogCheck.rows[0]?.total), catalogue.length);
    assert.equal(Number(catalogCheck.rows[0]?.bad), 0);

    await ensureUser({ id: userId, name: "Test Customer", username: "nx_test_customer" });
    await ensureUser({ id: adminId, name: "Test Admin", username: "nx_test_admin" });
    await pool.query("UPDATE nx_wallets SET balance=100000000 WHERE user_id=$1", [userId]);

    const firstDraft = await createOrderDraft(userId, 3, "1000", "https://t.me/nexverse_test_channel");
    assert.equal(firstDraft.amount, 33_340_000n);
    const placements = await Promise.all([placeOrder(userId, firstDraft.id), placeOrder(userId, firstDraft.id)]);
    assert.equal(placements[0].id, placements[1].id);
    assert.equal(placements.filter((item) => !item.duplicate).length, 1);
    assert.equal(await balance(), 66_660_000n);
    const firstOrder = await pool.query("SELECT id FROM nx_orders WHERE draft_id=$1", [firstDraft.id]);
    assert.equal(firstOrder.rowCount, 1);
    const firstOrderId = String(firstOrder.rows[0]?.id);

    await pool.query(
      "INSERT INTO nx_admin_roles(user_id,role,assigned_by) VALUES($1,'SUPER_ADMIN',$1)",
      [adminId],
    );
    await setSession(adminId, "menu", {});
    await editAdminUntil(adminId, new Date(Date.now() + 60 * 60 * 1000));
    const adminUser = { id: Number(adminId), first_name: "Test", username: "nx_test_admin" };
    const adminContext = {
      user: adminUser,
      chatId: adminId,
      callback: { id: randomUUID(), from: adminUser, data: "" },
      message: { message_id: 1, date: Math.floor(Date.now() / 1000), chat: { id: Number(adminId), type: "private" } },
    };
    const dispatchAdmin = async (data: string) => {
      const handled = await handleAdminCallback(adminContext, data);
      assert.equal(handled, true);
      return telegramMessages.at(-1);
    };

    await dispatchAdmin("adm:orders");
    assert.match(String(telegramMessages.at(-1)?.text), /All orders · Page 1 of 1/);
    await dispatchAdmin("adm:orders:ALL:999999");
    assert.match(String(telegramMessages.at(-1)?.text), /Page 1 of 1/);
    await dispatchAdmin(`adm:orders:detail:${firstOrderId}`);
    assert.match(String(telegramMessages.at(-1)?.text), /Order /);
    await dispatchAdmin(`adm:orders:s:${firstOrderId}:PROCESSING`);
    assert.match(String(telegramMessages.at(-1)?.text), /Confirm order/);
    await dispatchAdmin(`adm:orders:s2:${firstOrderId}:PROCESSING`);
    assert.match(String(telegramMessages.at(-1)?.text), /Order status set to PROCESSING/);
    await dispatchAdmin(`adm:orders:s2:${firstOrderId}:PROCESSING`);
    await dispatchAdmin(`adm:orders:s2:${firstOrderId}:FAILED`);
    const orderStatusNotifications = await pool.query(
      "SELECT body,dedupe_key FROM nx_notifications WHERE user_id=$1 AND kind='ORDER_STATUS' ORDER BY created_at",
      [userId],
    );
    assert.equal(orderStatusNotifications.rowCount, 2);
    assert.match(String(orderStatusNotifications.rows[0]?.body), /ORDER PROCESSING/);
    assert.match(String(orderStatusNotifications.rows[1]?.body), /ORDER FAILED/);
    const statusOutboxCount = await pool.query(
      "SELECT count(*)::int AS count FROM nx_outbox WHERE dedupe_key IN($1,$2)",
      [`order-status:${firstOrderId}:PROCESSING`, `order-status:${firstOrderId}:FAILED`],
    );
    assert.equal(Number(statusOutboxCount.rows[0]?.count), 2);

    await dispatchAdmin("adm:support");
    assert.match(String(telegramMessages.at(-1)?.text), /No all tickets found/);
    const ticketId = randomUUID();
    await pool.query("INSERT INTO nx_tickets(id,user_id,subject) VALUES($1,$2,'Integration ticket')", [ticketId, userId]);
    await pool.query(
      "INSERT INTO nx_ticket_messages(id,ticket_id,sender_id,body) VALUES($1,$2,$3,'Isolated integration message')",
      [randomUUID(), ticketId, userId],
    );
    await dispatchAdmin("adm:support:ALL:999999");
    assert.match(String(telegramMessages.at(-1)?.text), /All support tickets · Page 1 of 1/);
    await dispatchAdmin(`adm:support:detail:${ticketId}`);
    assert.match(String(telegramMessages.at(-1)?.text), /Isolated integration message/);
    await dispatchAdmin(`adm:ss:${ticketId}:IN_PROGRESS`);
    assert.match(String(telegramMessages.at(-1)?.text), /Ticket status set to IN_PROGRESS/);

    const customerUser = { id: Number(userId), first_name: "Test", username: "nx_test_customer" };
    const customerContext = {
      user: customerUser,
      chatId: userId,
      callback: { id: randomUUID(), from: customerUser, data: "" },
      message: { message_id: 2, date: Math.floor(Date.now() / 1000), chat: { id: Number(userId), type: "private" } },
    };
    await homeScreen(userId, userId);
    assert.match(String(telegramMessages.at(-1)?.text), /NEXVERSE SMM/);
    assert.equal(await handleCustomerCallback(customerContext, "allservices:0"), true);
    assert.match(String(telegramMessages.at(-1)?.text), /All Services · 50 available/);
    assert.equal(await handleServiceBrowserCallback(customerContext, "platform:0"), true);
    assert.match(String(telegramMessages.at(-1)?.text), /Choose a service type/);
    assert.equal(await handleCustomerCallback(customerContext, "service-search:all:0"), true);
    const customerMessageContext = {
      user: customerUser,
      chatId: userId,
      message: {
        message_id: 3,
        date: Math.floor(Date.now() / 1000),
        from: customerUser,
        chat: { id: Number(userId), type: "private" },
        text: "1",
      },
    };
    assert.equal(await handleCustomerMessage(customerMessageContext), true);
    assert.match(String(telegramMessages.at(-1)?.text), /Search: “1”/);
    const searchMarkup = telegramMessages.at(-1)?.reply_markup as { inline_keyboard?: Array<Array<{ callback_data?: string }>> };
    assert.ok(searchMarkup.inline_keyboard?.flat().some((item) => item.callback_data === "service:1"));
    assert.equal(await handleServiceBrowserCallback(customerContext, "serviceback"), true);
    assert.match(String(telegramMessages.at(-1)?.text), /Search: “1”/);
    assert.equal(await handleServiceBrowserCallback(customerContext, "favorite:1"), true);
    assert.match(String(telegramMessages.at(-1)?.text), /Added to favorites/);
    assert.equal(await handleServiceBrowserCallback(customerContext, "favorites:0"), true);
    assert.match(String(telegramMessages.at(-1)?.text), /Your favorite services/);
    assert.equal(await handleServiceBrowserCallback(customerContext, "service:1"), true);
    assert.match(String(telegramMessages.at(-1)?.text), /Service ID: 1/);
    assert.equal(await handleServiceBrowserCallback(customerContext, "recent:0"), true);
    assert.match(String(telegramMessages.at(-1)?.text), /Recently viewed or ordered services/);

    const screenshot = (utr: string) => ({
      id: randomUUID(), fileId: `test-file-${utr}`, size: 1024,
      sha256: "a".repeat(64), contentType: "image/jpeg",
    });
    const paymentId = await createPayment(userId, { name: "Test Customer", username: "nx_test_customer" }, 50_000_000n, "NXTESTUTR001", screenshot("001"));
    const approvals = await Promise.all([approvePayment(paymentId, adminId), approvePayment(paymentId, adminId)]);
    assert.equal(approvals.filter((item) => !item.duplicate).length, 1);
    assert.equal(await balance(), 116_660_000n);
    const depositCount = await pool.query("SELECT count(*)::int AS count FROM nx_ledger WHERE type='DEPOSIT' AND reference_id=$1", [paymentId]);
    assert.equal(Number(depositCount.rows[0]?.count), 1);

    const rejectedPayment = await createPayment(userId, { name: "Test Customer" }, 10_000_000n, "NXTESTUTR002", screenshot("002"));
    const beforeRejectedPayment = await balance();
    await rejectPayment(rejectedPayment, adminId, "Screenshot test rejection");
    assert.equal(await balance(), beforeRejectedPayment);
    const duplicateUtr = await createPayment(userId, { name: "Test Customer" }, 10_000_000n, "NXTESTUTR003", screenshot("003"));
    await rejectPayment(duplicateUtr, adminId, "Release test UTR");
    await expectCode(
      createPayment(userId, { name: "Test Customer" }, 10_000_000n, "NXTESTUTR003", screenshot("004")),
      "DUPLICATE",
    );

    await pool.query(
      "INSERT INTO nx_coupons(code,percent,maximum_uses,created_by) VALUES('NXTEST10',10,10,$1)",
      [adminId],
    );
    const couponDraft = await createOrderDraft(userId, 3, "1000", "https://t.me/nexverse_test_channel");
    const coupon = await applyCouponToDraft(userId, couponDraft.id, "NXTEST10");
    assert.equal(coupon.discount, 3_330_000n);
    assert.equal(coupon.amount, 30_010_000n);
    const discountedOrder = await placeOrder(userId, couponDraft.id);
    assert.equal(await balance(), 86_650_000n);
    const refundResults = await Promise.all([
      rejectAndRefund(discountedOrder.id, adminId, "Integration test refund"),
      rejectAndRefund(discountedOrder.id, adminId, "Integration test refund"),
    ]);
    assert.equal(refundResults.filter((item) => !item.duplicate).length, 1);
    assert.equal(refundResults[0].amount, 30_010_000n);
    assert.equal(await balance(), 116_660_000n);
    const refundCount = await pool.query("SELECT count(*)::int AS count FROM nx_refunds WHERE order_id=$1", [discountedOrder.id]);
    assert.equal(Number(refundCount.rows[0]?.count), 1);

    const processingDraft = await createOrderDraft(userId, 3, "100", "https://t.me/nexverse_test_channel");
    const processingOrder = await placeOrder(userId, processingDraft.id);
    await pool.query("UPDATE nx_orders SET status='PROCESSING' WHERE id=$1", [processingOrder.id]);
    const beforeProcessingRefund = await balance();
    await expectCode(rejectAndRefund(processingOrder.id, adminId, "Must not refund processing"), "STATUS");
    assert.equal(await balance(), beforeProcessingRefund);

    for (const status of ["COMPLETED", "CANCELLED", "REJECTED"]) {
      const draft = await createOrderDraft(userId, 3, "100", "https://t.me/nexverse_test_channel");
      const order = await placeOrder(userId, draft.id);
      await pool.query("UPDATE nx_orders SET status=$2 WHERE id=$1", [order.id, status]);
      const beforeRefund = await balance();
      await expectCode(rejectAndRefund(order.id, adminId, `Must not refund ${status}`), "STATUS");
      assert.equal(await balance(), beforeRefund);
      const rejectedRefund = await pool.query("SELECT count(*)::int AS count FROM nx_refunds WHERE order_id=$1", [order.id]);
      assert.equal(Number(rejectedRefund.rows[0]?.count), 0);
    }

    await pool.query(
      "INSERT INTO nx_redeem_codes(code,amount,maximum_redemptions,created_by) VALUES('NXTESTCODE',20000000,1,$1)",
      [adminId],
    );
    assert.equal(await redeemCode(userId, "nxtestcode"), 20_000_000n);
    const beforeDuplicateRedeem = await balance();
    await expectCode(redeemCode(userId, "NXTESTCODE"), "LIMIT");
    assert.equal(await balance(), beforeDuplicateRedeem);

    const adjustmentId = randomUUID();
    const adjustmentReason = "Verified integration adjustment";
    await pool.query(
      "INSERT INTO nx_operations(key,actor_id,kind,data) VALUES($1,$2,'WALLET_ADJUSTMENT',$3::jsonb)",
      [adjustmentId, adminId, JSON.stringify({ userId, amount: "-5000000", reason: adjustmentReason })],
    );
    const adjustment = await adjustWallet(userId, adminId, -5_000_000n, adjustmentReason, adjustmentId);
    assert.equal(adjustment.duplicate, false);
    const afterAdjustment = await balance();
    const duplicateAdjustment = await adjustWallet(userId, adminId, -5_000_000n, adjustmentReason, adjustmentId);
    assert.equal(duplicateAdjustment.duplicate, true);
    assert.equal(await balance(), afterAdjustment);

    await notifyUser(pool, userId, "TEST_NOTICE", "Integration notification.", "nx-test-notification");
    await notifyUser(pool, userId, "TEST_NOTICE", "Integration notification.", "nx-test-notification");
    const noticeCounts = await pool.query(
      `SELECT (SELECT count(*)::int FROM nx_notifications WHERE dedupe_key='nx-test-notification') AS notifications,
              (SELECT count(*)::int FROM nx_outbox WHERE dedupe_key='notification:nx-test-notification') AS queued`,
    );
    assert.equal(Number(noticeCounts.rows[0]?.notifications), 1);
    assert.equal(Number(noticeCounts.rows[0]?.queued), 1);

    await persistCompletedUpdate(998877);
    await persistCompletedUpdate(998877);
    const savedOffset = await pool.query("SELECT value FROM nx_runtime WHERE key='telegram_offset'");
    assert.equal(savedOffset.rows[0]?.value, "998878");
    const processedUpdate = await pool.query("SELECT count(*)::int AS count FROM nx_updates WHERE update_id=998877");
    assert.equal(Number(processedUpdate.rows[0]?.count), 1);

    assert.equal(roleCan("PAYMENT_ADMIN", "payments"), true);
    assert.equal(roleCan("PAYMENT_ADMIN", "orders"), false);
    assert.equal(roleCan("ANALYST", "audit"), true);
    assert.equal(roleCan("ANALYST", "settings"), false);
    assert.equal(roleCan("SUPER_ADMIN", "maintenance"), true);

    await pool.query("UPDATE nx_outbox SET status='SENT',sent_at=now() WHERE status<>'SENT'");
    await enqueueOutbox(pool, userId, "Retry test", "nx-test-outbox");
    const transientDelivery = async () => {
      throw new TelegramApiError("Rate limited", 429, 1);
    };
    assert.equal(await processOutboxOnce(transientDelivery), true);
    let outbox = await pool.query("SELECT status,attempts,last_error_code FROM nx_outbox WHERE dedupe_key='nx-test-outbox'");
    assert.equal(outbox.rows[0]?.status, "PENDING");
    assert.equal(Number(outbox.rows[0]?.attempts), 1);
    assert.equal(outbox.rows[0]?.last_error_code, "429");
    await pool.query("UPDATE nx_outbox SET available_at=now() WHERE dedupe_key='nx-test-outbox'");
    let deliveredMethod = "";
    assert.equal(await processOutboxOnce(async (method) => { deliveredMethod = method; }), true);
    assert.equal(deliveredMethod, "sendMessage");
    outbox = await pool.query("SELECT status,attempts FROM nx_outbox WHERE dedupe_key='nx-test-outbox'");
    assert.equal(outbox.rows[0]?.status, "SENT");
    assert.equal(Number(outbox.rows[0]?.attempts), 2);

    const maintenanceDraft = await createOrderDraft(userId, 3, "100", "https://t.me/nexverse_test_channel");
    await pool.query(
      "UPDATE nx_settings SET value='{\"enabled\":false,\"orders\":true,\"payments\":false,\"services\":false}'::jsonb WHERE key='maintenance'",
    );
    assert.equal(await isMaintenanceEnabled("orders"), true);
    await expectCode(placeOrder(userId, maintenanceDraft.id), "MAINTENANCE");
    await pool.query(
      "UPDATE nx_settings SET value='{\"enabled\":false,\"orders\":false,\"payments\":true,\"services\":false}'::jsonb WHERE key='maintenance'",
    );
    await expectCode(
      createPayment(userId, { name: "Test Customer" }, 10_000_000n, "NXTESTUTR004", screenshot("005")),
      "MAINTENANCE",
    );
    await pool.query("UPDATE nx_settings SET value='{\"enabled\":false}'::jsonb WHERE key='maintenance'");

    console.info("NEXVERSE integration checks passed: catalogue browsing, admin Orders and Support callbacks, status notifications, duplicate submissions, payments, refunds, coupons, redeem codes, wallet adjustments, outbox retry, permissions, maintenance, and persisted Telegram offsets.");
  } finally {
    try {
      if (schemaCreated) await pool.query(`DROP SCHEMA ${safeSchema} CASCADE`);
    } finally {
      globalThis.fetch = originalFetch;
      await pool.end();
    }
  }
}

main().catch((error) => {
  console.error("NEXVERSE integration checks failed:", (error as { stack?: string; message?: string }).stack ?? (error as { message?: string }).message ?? "unknown error");
  process.exitCode = 1;
});