export const genericUserErrorMessage: string;
export function getUserSafeErrorMessage(error: unknown): string | undefined;