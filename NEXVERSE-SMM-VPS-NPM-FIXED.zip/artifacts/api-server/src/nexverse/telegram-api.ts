import { config } from "./config.mjs";

export class TelegramApiError extends Error {
  constructor(
    message: string,
    readonly errorCode: number,
    readonly retryAfter?: number,
  ) {
    super(message);
    this.name = "TelegramApiError";
  }
}

export interface TelegramUser {
  id: number;
  is_bot?: boolean;
  username?: string;
  first_name?: string;
  last_name?: string;
}

export interface TelegramPhoto {
  file_id: string;
  file_unique_id: string;
  file_size?: number;
  width: number;
  height: number;
}

export interface TelegramMessage {
  message_id: number;
  date: number;
  chat: { id: number; type: string; username?: string };
  from?: TelegramUser;
  text?: string;
  caption?: string;
  photo?: TelegramPhoto[];
  document?: { file_id: string; file_name?: string; mime_type?: string; file_size?: number };
}

export interface TelegramCallback {
  id: string;
  from: TelegramUser;
  data?: string;
  message?: TelegramMessage;
}

export interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
  callback_query?: TelegramCallback;
}

export interface InlineKeyboardButton {
  text: string;
  callback_data?: string;
  url?: string;
}

export interface InlineKeyboardMarkup {
  inline_keyboard: InlineKeyboardButton[][];
}

interface TelegramResponse<T> {
  ok: boolean;
  result?: T;
  error_code?: number;
  description?: string;
  parameters?: { retry_after?: number };
}

export async function telegramCall<T>(method: string, payload: Record<string, unknown>): Promise<T> {
  if (!config.token) throw new TelegramApiError("Telegram bot is not configured.", 0);
  let response: Response;
  try {
    response = await fetch(`https://api.telegram.org/bot${config.token}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(method === "getUpdates" ? 38000 : 20000),
    });
  } catch {
    throw new TelegramApiError("Telegram request did not receive a response.", 0);
  }
  let body: TelegramResponse<T>;
  try {
    body = await response.json() as TelegramResponse<T>;
  } catch {
    throw new TelegramApiError("Telegram returned an unreadable response.", response.status);
  }
  if (!response.ok || !body.ok || body.result === undefined) {
    throw new TelegramApiError(
      body.description || `Telegram request failed (${response.status}).`,
      body.error_code || response.status,
      body.parameters?.retry_after,
    );
  }
  return body.result;
}

export async function sendMessage(chatId: string | number, text: string, replyMarkup?: InlineKeyboardMarkup) {
  const payload: Record<string, unknown> = { chat_id: String(chatId), text };
  if (replyMarkup) payload.reply_markup = replyMarkup;
  return telegramCall<TelegramMessage>("sendMessage", payload);
}

export async function answerCallback(callbackId: string, text?: string, showAlert = false) {
  return telegramCall<boolean>("answerCallbackQuery", {
    callback_query_id: callbackId,
    ...(text ? { text: text.slice(0, 190) } : {}),
    show_alert: showAlert,
  });
}

export async function sendPhoto(chatId: string | number, fileId: string, caption: string) {
  return telegramCall<TelegramMessage>("sendPhoto", { chat_id: String(chatId), photo: fileId, caption: caption.slice(0, 1000) });
}

export async function downloadTelegramFile(fileId: string) {
  const file = await telegramCall<{ file_path?: string; file_size?: number }>("getFile", { file_id: fileId });
  if (!file.file_path) throw new TelegramApiError("Telegram did not provide a file reference.", 0);
  if ((file.file_size ?? 0) <= 0 || (file.file_size ?? 0) > 10 * 1024 * 1024) {
    throw new TelegramApiError("Screenshot must be an image no larger than 10 MB.", 0);
  }
  let response: Response;
  try {
    response = await fetch(`https://api.telegram.org/file/bot${config.token}/${file.file_path}`, {
      signal: AbortSignal.timeout(20000),
    });
  } catch {
    throw new TelegramApiError("The screenshot could not be retrieved from Telegram.", 0);
  }
  if (!response.ok) throw new TelegramApiError("The screenshot could not be retrieved from Telegram.", response.status);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (!bytes.byteLength || bytes.byteLength > 10 * 1024 * 1024) throw new TelegramApiError("Screenshot must be an image no larger than 10 MB.", 0);
  return { bytes, size: bytes.byteLength };
}