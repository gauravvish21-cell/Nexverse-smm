export function configuredAdminRole(userId, adminIds) {
  return adminIds.includes(userId) ? "OWNER" : null;
}

export function roleCan(role, capability) {
  if (role === "OWNER" || role === "SUPER_ADMIN") return true;
  const map = {
    payments: ["PAYMENT_ADMIN"],
    orders: ["ORDER_MANAGER"],
    users: ["ANALYST", "PAYMENT_ADMIN", "ORDER_MANAGER", "SUPPORT_AGENT"],
    wallets: ["PAYMENT_ADMIN"],
    services: ["SERVICE_MANAGER"],
    redeem: ["SERVICE_MANAGER"],
    coupons: ["SERVICE_MANAGER"],
    support: ["SUPPORT_AGENT"],
    announcements: ["SUPPORT_AGENT"],
    notifications: ["ANALYST"],
    referrals: ["ANALYST"],
    audit: ["ANALYST"],
    analytics: ["ANALYST"],
    settings: [],
    maintenance: [],
    health: ["ANALYST"],
  };
  return map[capability]?.includes(role) ?? false;
}