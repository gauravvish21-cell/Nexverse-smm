export function classifyOutboxFailure(errorCode, retryAfter, attempts) {
  const isRateLimited = errorCode === 429;
  const retryable =
    isRateLimited ||
    errorCode === 0 ||
    errorCode === 408 ||
    (typeof errorCode === "number" && errorCode >= 500);
  const retryDelay = isRateLimited
    ? Math.max(1, Math.min(retryAfter ?? 5, 3600))
    : Math.min(3600, 5 * 2 ** Math.min(Math.max(attempts - 1, 0), 10));

  return {
    status: retryable && attempts < 8 ? "PENDING" : "FAILED",
    waitSeconds: retryDelay,
    safeCode: errorCode ? String(errorCode) : "NETWORK",
  };
}