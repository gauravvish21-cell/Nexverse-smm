import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { importCatalogue, catalogue } from "./catalogue.mjs";
import { pool } from "@workspace/db";

async function main() {
  if (process.env.NODE_ENV !== "development" || process.env.NEXVERSE_SCHEMA_SETUP !== "YES") {
    throw new Error("Schema setup is dev-only. Set NODE_ENV=development and NEXVERSE_SCHEMA_SETUP=YES for this explicit command.");
  }
  const here = dirname(fileURLToPath(import.meta.url));
  const schema = await readFile(resolve(here, "../../src/nexverse/schema.sql"), "utf8");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SET LOCAL lock_timeout = '10s'");
    await client.query("SET LOCAL statement_timeout = '60s'");
    await client.query(schema);
    await importCatalogue(client);
    const verify = await client.query(
      `SELECT count(*)::int AS count,
              count(*) FILTER(WHERE customer_paise<>supplier_paise*2)::int AS invalid_prices
       FROM nx_services WHERE id BETWEEN 1 AND 50`,
    );
    const result = verify.rows[0] as { count: number; invalid_prices: number };
    if (result.count !== catalogue.length || result.invalid_prices !== 0) {
      throw new Error(`Catalogue verification failed: found ${result.count} expected services and ${result.invalid_prices} invalid prices.`);
    }
    await client.query("COMMIT");
    console.info("NEXVERSE development schema is ready; all 50 catalogue rows and 2x prices verified.");
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((error) => {
  console.error("NEXVERSE dev schema setup failed:", (error as { message?: string }).message ?? "unknown error");
  process.exitCode = 1;
});