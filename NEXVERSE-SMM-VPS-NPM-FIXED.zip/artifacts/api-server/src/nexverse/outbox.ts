import { createHash } from "node:crypto";
import { logger } from "../lib/logger";
import { pool, transaction } from "./database";
import { TelegramApiError, telegramCall } from "./telegram-api";
import { classifyOutboxFailure } from "./outbox-policy.mjs";

let workerStarted = false;
let workerHealthy = false;
let nextRun: ReturnType<typeof setTimeout> | undefined;

export function outboxStatus() {
  return { running: workerStarted, healthy: workerHealthy };
}

export function classifyDeliveryFailure(error: unknown, attempts: number) {
  const apiError = error instanceof TelegramApiError ? error : undefined;
  return classifyOutboxFailure(apiError?.errorCode, apiError?.retryAfter, attempts);
}

async function claimMessage() {
  return transaction(async (db) => {
    const row = (await db.query(
      `SELECT id,method,params,dedupe_key,attempts
       FROM nx_outbox
       WHERE (status='PENDING' AND available_at<=now())
          OR (status='SENDING' AND lease_until<now())
       ORDER BY available_at,created_at
       FOR UPDATE SKIP LOCKED LIMIT 1`,
    )).rows[0] as { id: string; method: string; params: Record<string, unknown>; dedupe_key: string; attempts: number } | undefined;
    if (!row) return undefined;
    const claim = await db.query(
      `UPDATE nx_outbox SET status='SENDING',attempts=attempts+1,lease_until=now()+interval '60 seconds'
       WHERE id=$1 RETURNING attempts`,
      [row.id],
    );
    return { ...row, attempts: Number(claim.rows[0]?.attempts ?? row.attempts + 1) };
  });
}

async function processOne(deliver: (method: string, params: Record<string, unknown>) => Promise<unknown> = telegramCall) {
  const row = await claimMessage();
  if (!row) return false;
  try {
    if (!["sendMessage", "sendPhoto"].includes(row.method)) {
      throw new TelegramApiError("Unsupported queued Telegram method.", 400);
    }
    await deliver(row.method, row.params);
    await pool.query("UPDATE nx_outbox SET status='SENT',sent_at=now(),lease_until=NULL,last_error_code=NULL WHERE id=$1 AND status='SENDING'", [row.id]);
  } catch (error) {
    const { status, waitSeconds, safeCode } = classifyDeliveryFailure(error, row.attempts);
    await pool.query(
      `UPDATE nx_outbox SET status=$2,available_at=now()+($3::text||' seconds')::interval,
       lease_until=NULL,last_error_code=$4 WHERE id=$1 AND status='SENDING'`,
      [row.id, status, String(waitSeconds), safeCode],
    );
    logger.warn({ messageId: row.id, errorCode: safeCode, retry: status === "PENDING" }, "Telegram outbox delivery failed");
  }
  return true;
}

export async function processOutboxOnce(deliver?: (method: string, params: Record<string, unknown>) => Promise<unknown>) {
  return processOne(deliver);
}

async function run() {
  try {
    workerHealthy = true;
    const didWork = await processOne();
    nextRun = setTimeout(run, didWork ? 25 : 1200);
  } catch (error) {
    workerHealthy = false;
    const code = (error as { code?: string }).code ?? "OUTBOX";
    logger.error({ errorCode: code }, "Telegram outbox worker failed");
    nextRun = setTimeout(run, 3000);
  }
}

export function startOutboxWorker() {
  if (workerStarted) return;
  workerStarted = true;
  nextRun = setTimeout(run, 1000);
}

export async function enqueueUserMessage(chatId: string | number, text: string, dedupeKey: string) {
  const digest = createHash("sha256").update(dedupeKey).digest("hex");
  const params = { chat_id: String(chatId), text };
  await pool.query(
    "INSERT INTO nx_outbox(id,method,params,dedupe_key) VALUES(gen_random_uuid(),'sendMessage',$1::jsonb,$2) ON CONFLICT(dedupe_key) DO NOTHING",
    [JSON.stringify(params), `message:${digest}`],
  );
}

export async function stopOutboxWorker() {
  if (nextRun) clearTimeout(nextRun);
  workerStarted = false;
  workerHealthy = false;
}