export interface NexverseConfig {
  brand: string;
  support: string;
  upi: string;
  token: string;
  adminPassword: string;
  adminIds: readonly string[];
  botEnabled: boolean;
  deliveryEnabled: boolean;
}

export const config: Readonly<NexverseConfig>;
export function missingRequiredBotConfiguration(
  settings?: Pick<NexverseConfig, "token" | "adminPassword">,
): string[];