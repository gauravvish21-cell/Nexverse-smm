import { DomainError } from "./money.mjs";

export const genericUserErrorMessage =
  "Something went wrong. Please try again. If the issue continues, use /support.";

export function getUserSafeErrorMessage(error) {
  if (error instanceof DomainError && error.message.length < 500) {
    return error.message;
  }
  return undefined;
}