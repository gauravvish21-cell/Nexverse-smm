// Official catalogue. Descriptions were not provided separately: preserve the
// full catalogue name as the description rather than invent service claims.
const rows = [
  [1,"Telegram Members [Zero drop] 180 Days Refill ♻️ [Big Base 📦] SUPER FAST SPEED ⚡","Msp exclusive telegram","Telegram",6602,13204,100,1300000],
  [2,"Telegram Members [Non drop] HQ accounts 60k/day - 1 Day Refill ♻️ - Fast ⚡","Msp exclusive telegram","Telegram",444,888,500,50000],
  [3,"Telegram Members [cancel button enable] 7 days refill ♻️ - instant 🚀","Telegram world cheapest","Telegram",1667,3334,10,50000],
  [4,"Telegram Online Members [Non drop] 50k/day | 30 days refill ♻️","Telegram 24/7 online members","Telegram",4167,8334,500,50000],
  [5,"Telegram Online Members [60 Days Non Drop] 50k/day - 60 Days Refill ♻️ - Fast ⚡","Telegram 24/7 online members","Telegram",25200,50400,10,100000],
  [6,"Telegram India Members 🇮🇳 [non drop] 20k/day | 30 days refill ♻️","Telegram natural speed indian quality","Telegram",5008,10016,50,20000],
  [7,"TG India 🇮🇳 Members [Auto View + Reactions] [natural speed] New Post [7 days guarantee]","Telegram natural speed indian quality","Telegram",17488,34976,50,20000],
  [8,"Telegram Future Post Reaction [Positive Reactions + Bonus Views] [5 Future] - Fastest ⚡","Telegram Future Post Reaction [Stable]","Telegram",1695,3390,50,1000000],
  [9,"Telegram Post Views [Big Base] No Refill - Fast ⚡","Telegram single post views [stable]","Telegram",48,96,1000,1000000],
  [10,"Telegram Mix Positive Reaction + Free views","Telegram Reactions [Cheapest]","Telegram",201,402,100,1000000],
  [11,"Telegram Mix Negative Reaction + Free views","Telegram Reactions [Cheapest]","Telegram",201,402,100,1000000],
  [12,"Telegram Comment [Custom] [Fastest server] HQ Account with profile - Fast ⚡","Telegram channel comments","Telegram",192286,384572,5,20000],
  [13,"Telegram Bot Start [Cheapest] 100K/Day - Fast ⚡","Telegram Bot Start","Telegram",1123,2246,100,100000],
  [14,"Instagram Followers [High Drop] 10k/day | No Refill - Fast ⚡","Instagram followers [Working update]","Instagram",4627,9254,100,10000],
  [15,"Instagram Shares 200k/Hour | No Refill - Instant 🚀","Instagram Shares","Instagram",11,22,100,1000000],
  [16,"Instagram Video Views [1M/Day] | 0-1 Hour | Max 10M","Instagram views [Mix]","Instagram",28,56,100,217545811],
  [17,"Instagram Views [Max Unlimited] All Links Video + Reels + IGTV","Instagram views [Mix]","Instagram",30,60,100,2147483647],
  [18,"Instagram Post Save/Reels Indian Download - 60k/day","Instagram post save [Indian]","Instagram",99,198,250,5000],
  [19,"Instagram Profile Shares","Instagram Shares","Instagram",172,344,50,500000],
  [20,"Instagram Likes HQ Quality [30k/day] No Refill - Fastest","Instagram likes","Instagram",910,1820,100,1000000],
  [21,"Instagram Story Views Worldwide High Quality 100k/Day - Fast","Instagram story views","Instagram",1156,2312,100,200000],
  [22,"Instagram Comments [RANDOM] | 10K/Day [0-1 hour]","Instagram comment cheapest","Instagram",5837,11674,10,1000000],
  [23,"Instagram Repost + Reach [100K/day] High Quality - Fastest","Instagram Repost Fastest","Instagram",6500,13000,10,500000],
  [24,"Instagram Comments [CUSTOM] 10K/Day [0-1 hour]","Instagram comment cheapest","Instagram",5874,11748,10,1000000],
  [25,"Instagram Like VIP | Active Real Indian Women | 50K/D | Lifetime | Instant","Instagram Likes Indian - HQ","Instagram",3717,7434,10,3000000],
  [26,"Instagram Followers [Low Drop] Brazil | 50k/day | 30 Days Refill","Instagram Followers Country","Instagram",25865,51730,50,50000],
  [27,"Instagram Followers [Low Drop] 1K+/Hour | 30 Days Refill","Instagram followers","Instagram",26795,53590,100,100000],
  [28,"Instagram Followers [Low Drop] 1K+/Hour | No Refill","Instagram followers","Instagram",20999,41998,100,100000],
  [29,"Instagram Followers [Low/High Drop] 40k/day | No Refill - Fast","Instagram Followers Cheap","Instagram",30649,61298,10,1000000],
  [30,"Instagram Followers [Almost No Drop] High Quality 1M/Day | Big Profile Accepted | Lifetime Refill & Cancel","Instagram followers","Instagram",46376,92752,100,1000000],
  [31,"Instagram Followers [Low Drop] Korean | 50k/day | Lifetime Refill","Instagram Followers Country","Instagram",110473,220946,10,100000],
  [32,"YouTube Views [Max 1M] | Random Drop | No Refill | Instant Start | Day 10K","YouTube Video Views","YouTube",5784,11568,100,100000],
  [33,"YouTube Subscribers [100% Drop] Prank Subscribers | No Refill","YouTube subscriber no guarantee","YouTube",102,204,10,10000],
  [34,"YouTube Subscribers [High Drop] Max 50K | 10k/day | No Warranty","YouTube subscriber no guarantee","YouTube",952,1904,10,50000],
  [35,"YouTube Subscribers HQ Quality [Max 100K] 300-500/Day | 30 Days Refill","YouTube subscribers Non-drop","YouTube",326571,653142,100,10000],
  [36,"YouTube Subscribers High Quality Non-Drop 10K-20K/Day | 365 Days Refill","YouTube subscribers Non-drop","YouTube",559854,1119708,50,300000],
  [37,"YouTube Likes [Non-drop] HQ Profiles | 30 Days Refill | Day 1K","YouTube Likes","YouTube",12836,25672,50,10000],
  [38,"YouTube Best Quality Growth Bundle","YouTube Growth Bundle","YouTube",6860,13720,1000,1000],
  [39,"YouTube Likes [Non-drop] 50K/day | 30 Days Refill","YouTube Likes Cheapest","YouTube",5654,11308,10,5000],
  [40,"YouTube Live Stream Views [Max 60K] | Stay Time 15 Min","YouTube Livestream views","YouTube",973,1946,50,500000],
  [41,"YouTube Watchtime [4000 Hours] Stable [45 Days Refill]","YouTube Watchtime","YouTube",255746,511492,1000,4000],
  [42,"WhatsApp Channel Members [Non-drop] 20K+/Day | No Refill","WhatsApp Channel Members","WhatsApp",4191,8382,10,100000],
  [43,"WhatsApp Channel Post Emoji Reactions | Random Mix [30 Days Refill]","WhatsApp Services","WhatsApp",429,858,10,100000],
  [44,"Facebook Followers [Non-drop] All Type Profile | 100K+/Day | No Refill","Facebook Followers","Facebook",3558,7116,100,1000000],
  [45,"Facebook Followers [Non-drop] Page/Profile | 50K+/Day | Lifetime Refill","Facebook Followers","Facebook",6039,12078,100,1000000],
  [46,"Facebook Views [Non-drop] Lifetime Refill | Day 500K","Facebook Views","Facebook",474,948,500,2147483647],
  [47,"Facebook Group Members | HQ Accounts | Low Drop | 30 Day Refill | 50K/Day","Facebook Group Members","Facebook",4084,8168,10,100000],
  [48,"Twitter Followers [Low Drop] Worldwide | 30K+/Day | No Refill | Max 20K - Instant","Twitter Followers Updated","Twitter",22110,44220,10,100000],
  [49,"Twitter Followers [Low Drop] Worldwide | 50K+/Day | 365 Days Refill - Instant","Twitter Followers Updated","Twitter",53169,106338,50,100000],
  [50,"Google Review [Paid 5-Star Rating + Comments] 5K+/Day | Non-drop | 30 Days Refill","Google Map Review","Google Reviews",2580417,5160834,1,20000],
];
export const catalogue = rows.map(([id,name,category,platform,supplier_paise,customer_paise,minimum,maximum]) => ({
  id,name,category,platform,supplier_paise,customer_paise,minimum,maximum,description:name,
}));
export async function importCatalogue(db) {
  for (const s of catalogue) {
    await db.query(`INSERT INTO nx_services(id,name,category,platform,supplier_paise,customer_paise,minimum,maximum,description)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT(id) DO NOTHING`,
    [s.id,s.name,s.category,s.platform,s.supplier_paise,s.customer_paise,s.minimum,s.maximum,s.description]);
  }
}