export function classifyOutboxFailure(
  errorCode: number | undefined,
  retryAfter: number | undefined,
  attempts: number,
): {
  status: "PENDING" | "FAILED";
  waitSeconds: number;
  safeCode: string;
};