import { createHash, randomUUID } from "node:crypto";
import { logger } from "../lib/logger";
import { config } from "./config.mjs";
import { applyCouponToDraft, audit, createOrderDraft, createPayment, isMaintenanceEnabled, one, pool, redeemCode, transaction } from "./database";
import { DomainError, money, quantity, rupees, targetUrl } from "./money.mjs";
import { button, displayName, errorForUser, getSession, keyboard, nav, parseUuid, resetSession, send, setSession, type CallbackContext, type MessageContext } from "./bot-utils";
import { detectImageContentType } from "./image-validation.mjs";
import { downloadTelegramFile, sendPhoto, type InlineKeyboardButton } from "./telegram-api";
import { enqueueUserMessage } from "./outbox";
import { customerPlatformRows, handleServiceBrowserCallback, showServices } from "./service-browser";

const PAGE_SIZE = 8;
const customInputRequired = (name: string) => /\[custom\]/i.test(name);

async function walletBalance(userId: string) {
  return one<{ balance: string }>(pool, "SELECT balance::text FROM nx_wallets WHERE user_id=$1", [userId]);
}

export async function homeScreen(chatId: string, userId: string) {
  const summary = await one<{
    balance: string;
    active_orders: string;
    pending_payments: string;
    unread: string;
  }>(
    pool,
    `SELECT w.balance::text,
       (SELECT count(*)::text FROM nx_orders o WHERE o.user_id=w.user_id AND o.status IN('PENDING','PROCESSING')) AS active_orders,
       (SELECT count(*)::text FROM nx_payments p WHERE p.user_id=w.user_id AND p.status='PENDING') AS pending_payments,
       (SELECT count(*)::text FROM nx_notifications n WHERE n.user_id=w.user_id AND n.read_at IS NULL) AS unread
     FROM nx_wallets w WHERE w.user_id=$1`,
    [userId],
  );
  const text = [
    "NEXVERSE SMM",
    "",
    `Wallet balance: ${rupees(summary?.balance ?? "0")}`,
    `Active orders: ${summary?.active_orders ?? "0"}`,
    `Pending payments: ${summary?.pending_payments ?? "0"}`,
    `Unread notifications: ${summary?.unread ?? "0"}`,
  ].join("\n");
  const platformRows = await customerPlatformRows();
  const rows = [
    ...platformRows,
    [button("All Services", "allservices:0"), button("My Orders", "orders:0")],
    [button("Wallet", "wallet"), button("Add Funds", "addfunds")],
    [button("Transactions", "transactions:0"), button("Favorites", "favorites:0")],
    [button("Recent Services", "recent:0"), button("Notifications", "notifications:0")],
    [button("Support", "support"), button("Referral", "referral")],
    [button("Profile", "profile"), button("Help", "help")],
  ];
  await send(chatId, text, keyboard(rows));
}

async function showOrders(chatId: string, userId: string, page = 0) {
  const result = await pool.query(
    `SELECT id,service_name,quantity,amount::text,status,created_at
     FROM nx_orders WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [userId, PAGE_SIZE, page * PAGE_SIZE],
  );
  const rows = result.rows as Array<{ id: string; service_name: string; quantity: number; amount: string; status: string; created_at: Date }>;
  const buttons = rows.map((order) => [button(`#${order.id.slice(0, 8)} · ${order.status}`, `orderdetail:${order.id}`)]);
  if (rows.length) buttons.push([button("Next Orders", `orders:${page + 1}`)]);
  buttons.push(nav("home"));
  await send(chatId, rows.length ? "Your orders. Select one to view its details." : "You have no orders yet.", keyboard(buttons));
}

async function showOrderDetails(chatId: string, userId: string, orderId: string) {
  const order = await one<{
    id: string; service_name: string; quantity: number; amount: string; target: string;
    status: string; created_at: Date; updated_at: Date; extras: string; service_id: number;
  }>(
    pool,
    `SELECT id,service_name,quantity,amount::text,target,status,created_at,updated_at,extras,service_id
     FROM nx_orders WHERE id=$1 AND user_id=$2`,
    [orderId, userId],
  );
  if (!order) {
    await send(chatId, "Order not found.", keyboard([[button("My Orders", "orders:0"), button("Home", "home")]]));
    return;
  }
  const msg = [
    `Order ID: ${order.id}`,
    `Service: ${order.service_name}`,
    `Quantity: ${order.quantity}`,
    `Amount: ${rupees(order.amount)}`,
    `Target: ${order.target}`,
    `Status: ${order.status}`,
    `Created: ${new Date(order.created_at).toISOString()}`,
    `Updated: ${new Date(order.updated_at).toISOString()}`,
    ...(order.extras ? [`Details: ${order.extras}`] : []),
  ].join("\n");
  await send(chatId, msg, keyboard([
    [button("Reorder", `reorder:${order.id}`), button("Support", `supportorder:${order.id}`)],
    [button("My Orders", "orders:0"), button("Home", "home")],
  ]));
}

async function beginOrder(ctx: MessageContext | CallbackContext, serviceId: number, preset?: { quantity: number; target: string }) {
  const { chatId, user } = ctx;
  const service = await one<{ id: number; name: string; minimum: number; maximum: number; enabled: boolean }>(
    pool, "SELECT id,name,minimum,maximum,enabled FROM nx_services WHERE id=$1", [serviceId],
  );
  if (!service || !service.enabled) {
    await send(chatId, "This service is unavailable.", keyboard([[button("Services", "services:0"), button("Home", "home")]]));
    return;
  }
  await pool.query(
    `INSERT INTO nx_recent_services(user_id,service_id,last_used_at) VALUES($1,$2,now())
     ON CONFLICT(user_id,service_id) DO UPDATE SET last_used_at=now()`,
    [String(user.id), serviceId],
  );
  if (await isMaintenanceEnabled("enabled") || await isMaintenanceEnabled("orders")) {
    await send(chatId, "Ordering is temporarily paused. Your wallet and existing orders are unchanged.", keyboard([[button("Home", "home")]]));
    return;
  }
  if (preset) {
    try {
      const draft = await createOrderDraft(String(user.id), serviceId, String(preset.quantity), preset.target);
      await showOrderReview(chatId, String(user.id), draft.id);
    } catch (error) {
      await send(chatId, errorForUser(error), keyboard([[button("Services", "services:0"), button("Home", "home")]]));
    }
    return;
  }
  await setSession(String(user.id), "order_quantity", { serviceId });
  await send(chatId, `Enter a quantity for ${service.name} (${service.minimum}–${service.maximum}).`, keyboard([nav("service:" + serviceId)]));
}

async function showOrderReview(chatId: string, userId: string, draftId: string) {
  const draft = await one<{ id: string; service_id: number; quantity: number; target: string; quoted_amount: string; extras: string; coupon_code: string | null; discount: string }>(
    pool,
    "SELECT id,service_id,quantity,target,quoted_amount::text,extras,coupon_code,discount::text FROM nx_order_drafts WHERE id=$1 AND user_id=$2",
    [draftId, userId],
  );
  if (!draft) {
    await send(chatId, "That order draft expired. Start again from Services.", keyboard([[button("Services", "services:0")]]));
    return;
  }
  const service = await one<{ name: string }>(pool, "SELECT name FROM nx_services WHERE id=$1", [draft.service_id]);
  const wallet = await walletBalance(userId);
  const msg = [
    "Review your order",
    `Service: ${service?.name ?? "Unavailable"}`,
    `Quantity: ${draft.quantity}`,
    `Target: ${draft.target}`,
    ...(draft.extras ? [`Details: ${draft.extras}`] : []),
    ...(draft.coupon_code ? [`Coupon: ${draft.coupon_code} · discount ${rupees(draft.discount)}`] : []),
    `Total price: ${rupees(BigInt(draft.quoted_amount) - BigInt(draft.discount))}`,
    `Current wallet balance: ${rupees(wallet?.balance ?? "0")}`,
    "",
    "Confirming will debit your wallet.",
  ].join("\n");
  await setSession(userId, "order_review", { draftId });
  await send(chatId, msg, keyboard([
    [button("Confirm Order", `orderconfirm:${draftId}`)],
    ...(draft.coupon_code ? [] : [[button("Apply Coupon", `applycoupon:${draftId}`)]]),
    [button("Cancel", "cancel"), button("Home", "home")],
  ]));
}

async function showWallet(chatId: string, userId: string) {
  const row = await one<{ balance: string; created_at: Date }>(
    pool, "SELECT balance::text,created_at FROM nx_wallets WHERE user_id=$1", [userId],
  );
  const pending = await one<{ total: string }>(pool, "SELECT count(*)::text AS total FROM nx_payments WHERE user_id=$1 AND status='PENDING'", [userId]);
  await send(
    chatId,
    `Wallet balance: ${rupees(row?.balance ?? "0")}\nPending payment requests: ${pending?.total ?? "0"}`,
    keyboard([[button("Add Funds", "addfunds"), button("Transactions", "transactions:0")], nav("home")]),
  );
}

async function showTransactions(chatId: string, userId: string, page = 0) {
  const result = await pool.query(
    `SELECT type,amount::text,description,status,created_at FROM nx_ledger
     WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [userId, PAGE_SIZE, page * PAGE_SIZE],
  );
  const rows = result.rows as Array<{ type: string; amount: string; description: string; status: string; created_at: Date }>;
  const text = rows.length
    ? rows.map((row) => `${row.type}: ${rupees(row.amount)} · ${row.description}\n${new Date(row.created_at).toISOString()}`).join("\n\n")
    : "No transactions yet.";
  const buttons = rows.length === PAGE_SIZE ? [[button("More", `transactions:${page + 1}`)]] : [];
  buttons.push(nav("home"));
  await send(chatId, text, keyboard(buttons));
}

async function showNotifications(chatId: string, userId: string, page = 0) {
  const result = await pool.query(
    `SELECT id,body,read_at,created_at FROM nx_notifications WHERE user_id=$1
     ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [userId, PAGE_SIZE, page * PAGE_SIZE],
  );
  const rows = result.rows as Array<{ id: string; body: string; read_at: Date | null; created_at: Date }>;
  const lines = rows.map((row) => `${row.read_at ? "Read" : "New"} · ${new Date(row.created_at).toISOString()}\n${row.body}`);
  const buttons: InlineKeyboardButton[][] = rows.length === PAGE_SIZE ? [[button("More", `notifications:${page + 1}`)]] : [];
  buttons.push([button("Mark All Read", "notifications-read")], nav("home"));
  await send(chatId, lines.length ? lines.join("\n\n") : "You have no notifications.", keyboard(buttons));
}

async function showSupport(chatId: string, userId: string) {
  const tickets = await pool.query(
    "SELECT id,subject,status,updated_at FROM nx_tickets WHERE user_id=$1 ORDER BY updated_at DESC LIMIT 8",
    [userId],
  );
  const rows = (tickets.rows as Array<{ id: string; subject: string; status: string }>).map((ticket) => [button(`${ticket.status} · ${ticket.subject.slice(0, 28)}`, `ticket:${ticket.id}`)]);
  rows.push([button("Create Ticket", "support-new")], nav("home"));
  await send(chatId, "Support\nChoose an existing ticket or create a new one.", keyboard(rows));
}

async function showTicket(chatId: string, userId: string, ticketId: string) {
  const ticket = await one<{ id: string; subject: string; status: string }>(
    pool, "SELECT id,subject,status FROM nx_tickets WHERE id=$1 AND user_id=$2", [ticketId, userId],
  );
  if (!ticket) {
    await send(chatId, "Ticket not found.", keyboard([[button("Support", "support"), button("Home", "home")]]));
    return;
  }
  const messages = await pool.query(
    "SELECT body,is_admin,created_at FROM nx_ticket_messages WHERE ticket_id=$1 ORDER BY created_at DESC LIMIT 8",
    [ticketId],
  );
  const lines = (messages.rows as Array<{ body: string; is_admin: boolean; created_at: Date }>).reverse().map((item) =>
    `${item.is_admin ? "Support" : "You"} · ${new Date(item.created_at).toISOString()}\n${item.body}`,
  );
  await send(chatId, `Ticket: ${ticket.subject}\nStatus: ${ticket.status}\n\n${lines.join("\n\n") || "No messages yet."}`, keyboard([
    [button("Reply", `ticket-reply:${ticket.id}`)],
    [button("Close Ticket", `ticket-close:${ticket.id}`)],
    nav("support"),
  ]));
}

async function beginFunds(ctx: MessageContext | CallbackContext) {
  if (await isMaintenanceEnabled("enabled") || await isMaintenanceEnabled("payments")) {
    await send(ctx.chatId, "Payments are temporarily paused. Existing wallet balances are unchanged.", keyboard([[button("Home", "home")]]));
    return;
  }
  await setSession(String(ctx.user.id), "payment_amount", {});
  await send(ctx.chatId, "Enter the amount in INR you paid. Your wallet is credited only after manual review.", keyboard([nav("wallet")]));
}

export async function handleCustomerCommand(ctx: MessageContext, command: string, args: string[]) {
  const userId = String(ctx.user.id);
  switch (command) {
    case "/help":
      await send(ctx.chatId, "Commands: /start, /services, /orders, /wallet, /addfunds, /transactions, /redeem, /support, /referral, /profile, /notifications, /admin", keyboard([[button("Home", "home"), button("Services", "services:0")]]));
      return true;
    case "/services":
      await showServices(ctx.chatId, userId, { search: args.join(" ").trim() || undefined });
      return true;
    case "/orders":
      await showOrders(ctx.chatId, userId);
      return true;
    case "/wallet":
      await showWallet(ctx.chatId, userId);
      return true;
    case "/addfunds":
      await beginFunds(ctx);
      return true;
    case "/transactions":
      await showTransactions(ctx.chatId, userId);
      return true;
    case "/redeem":
      await setSession(userId, "redeem_code", {});
      await send(ctx.chatId, "Enter your redeem code.", keyboard([nav("home")]));
      return true;
    case "/support":
      await showSupport(ctx.chatId, userId);
      return true;
    case "/referral": {
      const user = await one<{ referral_code: string }>(pool, "SELECT referral_code FROM nx_users WHERE id=$1", [userId]);
      const me = getBotUsername();
      const enabled = await one<{ value: { enabled?: boolean } }>(pool, "SELECT value FROM nx_settings WHERE key='referral'");
      const link = me && user ? `https://t.me/${me}?start=ref_${user.referral_code}` : "Open this bot and share your referral code with a friend.";
      await send(ctx.chatId, `Your referral code: ${user?.referral_code ?? "not available"}\nReferral link: ${link}\nRewards: ${enabled?.value?.enabled ? "enabled" : "currently paused"}`, keyboard([nav("home")]));
      return true;
    }
    case "/profile": {
      const row = await one<{ id: string; username: string | null; name: string; created_at: Date; suspended: boolean }>(
        pool, "SELECT id::text,username,name,created_at,suspended FROM nx_users WHERE id=$1", [userId],
      );
      await send(ctx.chatId, `Profile\nName: ${row?.name ?? displayName(ctx.user)}\nUsername: ${row?.username ? `@${row.username}` : "not set"}\nTelegram ID: ${userId}\nMember since: ${row?.created_at ? new Date(row.created_at).toISOString() : "today"}\nAccount: ${row?.suspended ? "suspended" : "active"}`, keyboard([nav("home")]));
      return true;
    }
    case "/notifications":
      await showNotifications(ctx.chatId, userId);
      return true;
    default:
      return false;
  }
}

export async function handleCustomerCallback(ctx: CallbackContext, data: string) {
  const userId = String(ctx.user.id);
  const chatId = ctx.chatId;
  const [action, a, b] = data.split(":");
  if (await handleServiceBrowserCallback(ctx, data)) return true;
  switch (action) {
    case "home":
      await resetSession(userId, true);
      await homeScreen(chatId, userId);
      return true;
    case "help":
      await send(chatId, "Use the menu or these commands: /services, /orders, /wallet, /addfunds, /transactions, /redeem, /support, /referral, /profile, /notifications.", keyboard([[button("Home", "home")]]));
      return true;
    case "cancel":
      await resetSession(userId, true);
      await send(chatId, "Cancelled. No wallet or order changes were made.", keyboard([[button("Home", "home")]]));
      return true;
    case "service-search":
      {
        const platformIndex = /^\d+$/.test(a ?? "") ? Number(a) : undefined;
        const returnMode = a === "all" ? "all-services" : "platforms";
        const returnPage = a === "all" && /^\d+$/.test(b ?? "") ? Number(b) : 0;
        await setSession(userId, "service_search", { platformIndex, returnMode, returnPage });
        await send(
          chatId,
          "Enter a service name, category, platform, or ID to search.",
          keyboard([nav(platformIndex !== undefined ? `platform:${platformIndex}` : returnMode === "all-services" ? `allservices:${returnPage}` : "services:0")]),
        );
      }
      return true;
    case "orderstart":
      await beginOrder(ctx, Number(a));
      return true;
    case "orderconfirm": {
      if (!parseUuid(a ?? "")) return false;
      try {
        const result = await import("./database").then((mod) => mod.placeOrder(userId, a));
        await resetSession(userId, true);
        await send(chatId, result.duplicate ? `This order was already placed. Order ID: ${result.id}` : `Order placed.\nOrder ID: ${result.id}\nAmount: ${rupees(result.amount)}\nStatus: PENDING`, keyboard([[button("My Orders", "orders:0"), button("Home", "home")]]));
      } catch (error) {
        await send(chatId, errorForUser(error), keyboard([[button("Services", "services:0"), button("Home", "home")]]));
      }
      return true;
    }
    case "applycoupon": {
      if (!parseUuid(a ?? "")) return false;
      const draft = await one<{ id: string }>(pool, "SELECT id FROM nx_order_drafts WHERE id=$1 AND user_id=$2", [a, userId]);
      if (!draft) return false;
      await setSession(userId, "coupon_code", { draftId: a });
      await send(chatId, "Enter your coupon code.", keyboard([nav("home")]));
      return true;
    }
    case "orders":
      await showOrders(chatId, userId, Number(a ?? 0));
      return true;
    case "orderdetail":
      if (!parseUuid(a ?? "")) return false;
      await showOrderDetails(chatId, userId, a);
      return true;
    case "reorder": {
      if (!parseUuid(a ?? "")) return false;
      const order = await one<{ service_id: number; quantity: number; target: string }>(
        pool, "SELECT service_id,quantity,target FROM nx_orders WHERE id=$1 AND user_id=$2", [a, userId],
      );
      if (!order) return false;
      await beginOrder(ctx, order.service_id, { quantity: order.quantity, target: order.target });
      return true;
    }
    case "wallet":
      await showWallet(chatId, userId);
      return true;
    case "addfunds":
      await beginFunds(ctx);
      return true;
    case "transactions":
      await showTransactions(chatId, userId, Number(a ?? 0));
      return true;
    case "notifications":
      await showNotifications(chatId, userId, Number(a ?? 0));
      return true;
    case "notifications-read":
      await pool.query("UPDATE nx_notifications SET read_at=now() WHERE user_id=$1 AND read_at IS NULL", [userId]);
      await send(chatId, "Notifications marked as read.", keyboard([[button("Notifications", "notifications:0"), button("Home", "home")]]));
      return true;
    case "support":
      await showSupport(chatId, userId);
      return true;
    case "support-new":
      await setSession(userId, "support_new", {});
      await send(chatId, "Describe the issue. Include an order or payment ID if relevant.", keyboard([nav("support")]));
      return true;
    case "ticket":
      if (!parseUuid(a ?? "")) return false;
      await showTicket(chatId, userId, a);
      return true;
    case "ticket-reply":
      if (!parseUuid(a ?? "")) return false;
      await setSession(userId, "support_reply", { ticketId: a });
      await send(chatId, "Write your reply.", keyboard([nav("support")]));
      return true;
    case "supportorder":
      if (!parseUuid(a ?? "")) return false;
      await setSession(userId, "support_new", { orderId: a });
      await send(chatId, `Describe what you need help with for order ${a}.`, keyboard([nav("support")]));
      return true;
    case "ticket-close":
      if (!parseUuid(a ?? "")) return false;
      await pool.query("UPDATE nx_tickets SET status='CLOSED',updated_at=now() WHERE id=$1 AND user_id=$2 AND status<>'CLOSED'", [a, userId]);
      await send(chatId, "Ticket closed.", keyboard([[button("Support", "support"), button("Home", "home")]]));
      return true;
    case "referral": {
      const fakeMessage: MessageContext = { user: ctx.user, chatId, message: ctx.message ?? { message_id: 0, date: 0, chat: { id: Number(chatId), type: "private" } } };
      await handleCustomerCommand(fakeMessage, "/referral", []);
      return true;
    }
    case "profile": {
      const fakeMessage: MessageContext = { user: ctx.user, chatId, message: ctx.message ?? { message_id: 0, date: 0, chat: { id: Number(chatId), type: "private" } } };
      await handleCustomerCommand(fakeMessage, "/profile", []);
      return true;
    }
    default:
      return false;
  }
}

export async function handleCustomerMessage(ctx: MessageContext) {
  const userId = String(ctx.user.id);
  const body = ctx.message.text?.trim() ?? "";
  const session = await getSession(userId);
  const data = session.data;
  try {
    switch (session.state) {
      case "service_search":
        if (body.length < 1) throw new DomainError("Enter a service name, category, platform, or ID to search.");
        await showServices(ctx.chatId, userId, {
          search: body.slice(0, 80),
          platformIndex: typeof data.platformIndex === "number" ? data.platformIndex : undefined,
          returnMode: data.returnMode === "all-services" ? "all-services" : "platforms",
          returnPage: typeof data.returnPage === "number" ? data.returnPage : 0,
        });
        return true;
      case "order_quantity": {
        const serviceId = Number(data.serviceId);
        const service = await one<{ id: number; name: string; minimum: number; maximum: number }>(pool, "SELECT id,name,minimum,maximum FROM nx_services WHERE id=$1 AND enabled=true", [serviceId]);
        if (!service) throw new DomainError("That service is unavailable.");
        const q = quantity(body, service);
        await setSession(userId, "order_target", { serviceId, quantity: q });
        await send(ctx.chatId, "Send the public target link for this order (https://…).", keyboard([nav(`service:${serviceId}`)]));
        return true;
      }
      case "order_target": {
        const serviceId = Number(data.serviceId);
        const target = targetUrl(body);
        const service = await one<{ name: string }>(pool, "SELECT name FROM nx_services WHERE id=$1 AND enabled=true", [serviceId]);
        if (!service) throw new DomainError("That service is unavailable.");
        if (customInputRequired(service.name)) {
          await setSession(userId, "order_extras", { serviceId, quantity: Number(data.quantity), target });
          await send(ctx.chatId, "This service requires custom text. Enter the comments or instructions for the provider.", keyboard([nav(`service:${serviceId}`)]));
          return true;
        }
        const draft = await createOrderDraft(userId, serviceId, String(data.quantity), target);
        await showOrderReview(ctx.chatId, userId, draft.id);
        return true;
      }
      case "order_extras": {
        const extras = body.trim();
        if (extras.length < 2 || extras.length > 1000) throw new DomainError("Enter between 2 and 1,000 characters.");
        const draft = await createOrderDraft(userId, Number(data.serviceId), String(data.quantity), String(data.target), extras);
        await showOrderReview(ctx.chatId, userId, draft.id);
        return true;
      }
      case "payment_amount": {
        const amount = money(body);
        await setSession(userId, "payment_utr", { amount: amount.toString() });
      await send(ctx.chatId, `Pay ${rupees(amount)} to UPI ID ${config.upi}.\nThen enter your UTR/reference number. Wallet credit happens only after admin review.`, keyboard([nav("wallet")]));
        return true;
      }
      case "payment_utr": {
        const utr = body.toUpperCase();
        if (!/^[A-Z0-9-]{6,32}$/.test(utr)) throw new DomainError("Enter a valid UTR/reference (6–32 letters or digits).");
        await setSession(userId, "payment_photo", { ...data, utr });
        await send(ctx.chatId, "Upload the payment screenshot as a photo or image document. It will be reviewed by an administrator.", keyboard([nav("wallet")]));
        return true;
      }
      case "payment_photo": {
        const photo = ctx.message.photo?.at(-1);
        const document = ctx.message.document;
        const rawMime = document?.mime_type?.toLowerCase();
        const declaredContentType = document ? (rawMime === "image/jpg" ? "image/jpeg" : rawMime) : "image/jpeg";
        const fileId = photo?.file_id ?? (document?.file_id);
        if (!fileId) throw new DomainError("Upload an image screenshot as a photo or image document.");
        if (!["image/jpeg", "image/png", "image/webp"].includes(declaredContentType ?? "")) {
          throw new DomainError("Upload a JPEG, PNG, or WebP screenshot.");
        }
        if ((photo?.file_size ?? document?.file_size ?? 0) > 10 * 1024 * 1024) throw new DomainError("Screenshot must be no larger than 10 MB.");
        const file = await downloadTelegramFile(fileId);
        const contentType = detectImageContentType(file.bytes);
        if (!contentType || contentType !== declaredContentType) {
          throw new DomainError("The uploaded file is not a valid JPEG, PNG, or WebP screenshot.");
        }
        const digest = createHash("sha256").update(file.bytes).digest("hex");
        const paymentId = await createPayment(
          userId,
          { username: ctx.user.username, name: displayName(ctx.user) },
          BigInt(String(data.amount)),
          String(data.utr),
          { id: randomUUID(), fileId, size: file.size, sha256: digest, contentType },
        );
        await resetSession(userId, true);
        await send(ctx.chatId, `Payment request submitted.\nPayment ID: ${paymentId}\nStatus: PENDING\nYour wallet has not been credited yet.`, keyboard([[button("Wallet", "wallet"), button("Home", "home")]]));
        await alertAdmins(`New payment request ${paymentId}\nUser: ${displayName(ctx.user)} (${userId})\nAmount: ${rupees(String(data.amount))}\nUTR: ${String(data.utr)}`, `admin-payment:${paymentId}`);
        return true;
      }
      case "redeem_code": {
        const amount = await redeemCode(userId, body);
        await resetSession(userId, true);
        await send(ctx.chatId, `Code accepted. ${rupees(amount)} was added to your wallet.`, keyboard([[button("Wallet", "wallet"), button("Home", "home")]]));
        return true;
      }
      case "coupon_code": {
        const result = await applyCouponToDraft(userId, String(data.draftId ?? ""), body);
        await showOrderReview(ctx.chatId, userId, String(data.draftId));
        await send(ctx.chatId, `Coupon ${result.code} applied: ${result.percent}% off (${rupees(result.discount)}).`, keyboard([[button("Review Order", `orderconfirm:${data.draftId}`)]]));
        return true;
      }
      case "support_new": {
        const description = body.slice(0, 1500);
        if (description.length < 5) throw new DomainError("Please describe the issue in at least five characters.");
        const ticketId = randomUUID();
        const orderId = typeof data.orderId === "string" ? data.orderId : undefined;
        await transaction(async (db) => {
          const subject = orderId ? `Order support ${orderId.slice(0, 8)}` : description.slice(0, 90);
          await db.query("INSERT INTO nx_tickets(id,user_id,subject) VALUES($1,$2,$3)", [ticketId, userId, subject]);
          await db.query("INSERT INTO nx_ticket_messages(id,ticket_id,sender_id,body,is_admin) VALUES($1,$2,$3,$4,false)", [randomUUID(), ticketId, userId, description]);
          await audit(db, userId, "TICKET_CREATED", ticketId, {});
        });
        await resetSession(userId, true);
        await send(ctx.chatId, `Support ticket created.\nTicket ID: ${ticketId}`, keyboard([[button("View Ticket", `ticket:${ticketId}`), button("Home", "home")]]));
        await alertAdmins(`New support ticket ${ticketId}\nFrom: ${displayName(ctx.user)} (${userId})\n${description}`, `admin-ticket:${ticketId}`);
        return true;
      }
      case "support_reply": {
        const ticketId = String(data.ticketId ?? "");
        if (!/^[0-9a-f-]{36}$/i.test(ticketId)) throw new DomainError("Ticket not found.");
        const inserted = await transaction(async (db) => {
          const ticket = await one<{ status: string }>(db, "SELECT status FROM nx_tickets WHERE id=$1 AND user_id=$2 FOR UPDATE", [ticketId, userId]);
          if (!ticket || ticket.status === "CLOSED") throw new DomainError("This ticket is closed or unavailable.");
          await db.query("INSERT INTO nx_ticket_messages(id,ticket_id,sender_id,body,is_admin) VALUES($1,$2,$3,$4,false)", [randomUUID(), ticketId, userId, body.slice(0, 1500)]);
          await db.query("UPDATE nx_tickets SET status='OPEN',updated_at=now() WHERE id=$1", [ticketId]);
          await audit(db, userId, "TICKET_REPLIED", ticketId, {});
          return true;
        });
        if (inserted) {
          await resetSession(userId, true);
          await send(ctx.chatId, "Reply added to your ticket.", keyboard([[button("View Ticket", `ticket:${ticketId}`), button("Home", "home")]]));
        }
        return true;
      }
      default:
        return false;
    }
  } catch (error) {
    await send(ctx.chatId, errorForUser(error), keyboard([[button("Cancel", "cancel"), button("Home", "home")]]));
    return true;
  }
}

async function alertAdmins(message: string, dedupeKey: string) {
  for (const id of config.adminIds) {
    await enqueueUserMessage(id, message, `${dedupeKey}:${id}`).catch((error) => {
      logger.warn({ errorCode: (error as { code?: string })?.code ?? "OUTBOX" }, "Could not queue administrator alert");
    });
  }
}

export async function announcePaymentPhoto(chatId: string, fileId: string, caption: string) {
  await sendPhoto(chatId, fileId, caption);
}

export async function validateCustomerCallbackContext(userId: string, callback: string) {
  if (callback.startsWith("orderconfirm:")) {
    const draftId = callback.slice("orderconfirm:".length);
    const session = await getSession(userId);
    return session.state === "order_review" && session.data.draftId === draftId;
  }
  return true;
}

let botUsername = "";

export function setBotUsername(username: string) {
  botUsername = username.replace(/^@/, "");
}

function getBotUsername() {
  return botUsername;
}