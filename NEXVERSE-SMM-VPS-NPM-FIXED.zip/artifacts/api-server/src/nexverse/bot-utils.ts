import { logger } from "../lib/logger";
import { one, pool } from "./database";
import { genericUserErrorMessage, getUserSafeErrorMessage } from "./user-errors.mjs";
import { assertCallbackData } from "./telegram-callback.mjs";
import { answerCallback, sendMessage, type InlineKeyboardButton, type InlineKeyboardMarkup, type TelegramCallback, type TelegramMessage, type TelegramUser } from "./telegram-api";

export type SessionData = Record<string, unknown>;
export interface UserSession {
  [key: string]: unknown;
  state: string;
  data: SessionData;
  admin_until: string | null;
  failures: number;
  locked_until: string | null;
}

export function keyboard(rows: InlineKeyboardButton[][]): InlineKeyboardMarkup {
  return { inline_keyboard: rows };
}

export function button(text: string, callback_data: string): InlineKeyboardButton {
  assertCallbackData(callback_data);
  return { text, callback_data };
}

export function nav(back = "home") {
  return [button("Home", "home"), button("Back", back), button("Cancel", "cancel")];
}

export async function send(chatId: string | number, text: string, markup?: InlineKeyboardMarkup) {
  return sendMessage(chatId, text, markup);
}

export async function safeAnswer(callback: TelegramCallback, text?: string, alert = false) {
  try {
    await answerCallback(callback.id, text, alert);
  } catch {
    // Expired callback queries are expected; the caller still sends the current screen.
  }
}

export async function showExpired(chatId: string | number) {
  await send(chatId, "That button is no longer active. Open the current menu below.", keyboard([[button("Home", "home")]]));
}

export async function getSession(userId: string): Promise<UserSession> {
  const row = await one<UserSession>(
    pool,
    "SELECT state,data,admin_until,failures,locked_until FROM nx_sessions WHERE user_id=$1",
    [userId],
  );
  return row ?? { state: "menu", data: {}, admin_until: null, failures: 0, locked_until: null };
}

export async function setSession(userId: string, state = "menu", data: SessionData = {}, keepAdmin = true) {
  const json = JSON.stringify(data);
  await pool.query(
    `INSERT INTO nx_sessions(user_id,state,data)
     VALUES($1,$2,$3::jsonb)
     ON CONFLICT(user_id) DO UPDATE SET state=EXCLUDED.state,data=EXCLUDED.data,
       admin_until=CASE WHEN $4 THEN nx_sessions.admin_until ELSE NULL END,updated_at=now()`,
    [userId, state, json, keepAdmin],
  );
}

export async function resetSession(userId: string, keepAdmin = false) {
  await pool.query(
    `INSERT INTO nx_sessions(user_id,state,data)
     VALUES($1,'menu','{}'::jsonb)
     ON CONFLICT(user_id) DO UPDATE SET state='menu',data='{}'::jsonb,
       admin_until=CASE WHEN $2 THEN nx_sessions.admin_until ELSE NULL END,updated_at=now()`,
    [userId, keepAdmin],
  );
}

export async function editAdminUntil(userId: string, until: Date | null) {
  await pool.query(
    "UPDATE nx_sessions SET admin_until=$1,updated_at=now() WHERE user_id=$2",
    [until, userId],
  );
}

export async function recordAdminAttempt(userId: string, success: boolean) {
  if (success) {
    await pool.query("UPDATE nx_sessions SET failures=0,locked_until=NULL,updated_at=now() WHERE user_id=$1", [userId]);
  } else {
    await pool.query(
      `UPDATE nx_sessions SET failures=failures+1,
       locked_until=CASE WHEN failures+1>=5 THEN now()+interval '15 minutes' ELSE locked_until END,
       updated_at=now() WHERE user_id=$1`,
      [userId],
    );
  }
}

export interface MessageContext {
  user: TelegramUser;
  message: TelegramMessage;
  chatId: string;
}

export interface CallbackContext {
  user: TelegramUser;
  callback: TelegramCallback;
  chatId: string;
  message?: TelegramMessage;
}

export function displayName(user: TelegramUser) {
  return [user.first_name, user.last_name].filter(Boolean).join(" ").slice(0, 160) || user.username || "Telegram user";
}

function redactErrorText(value: string) {
  return value
    .replace(/\bbot\d{6,}:[A-Za-z0-9_-]{20,}\b/g, "[REDACTED_TELEGRAM_TOKEN]")
    .replace(/\b(postgres(?:ql)?:\/\/)[^\s/@]+(?::[^\s/@]*)?@/gi, "$1[REDACTED]@")
    .slice(0, 8000);
}

export function safeErrorLogFields(error: unknown) {
  const thrown = error instanceof Error ? error : undefined;
  const message = thrown?.message ?? (typeof error === "string" ? error : "Non-Error value thrown");
  const code =
    error && typeof error === "object" && "code" in error
      ? String((error as { code?: unknown }).code ?? "").slice(0, 40)
      : undefined;
  return {
    errorName: thrown?.name ?? "NonErrorThrown",
    errorMessage: redactErrorText(message),
    errorStack: redactErrorText(thrown?.stack ?? ""),
    ...(code ? { errorCode: code } : {}),
  };
}

export function errorForUser(
  error: unknown,
  context: { area?: string; action?: string; adminId?: string; recordId?: string } = {},
) {
  const safeMessage = getUserSafeErrorMessage(error);
  if (safeMessage) return safeMessage;
  logger.error({ ...safeErrorLogFields(error), ...context }, "Telegram handler failed");
  return genericUserErrorMessage;
}

export function parseUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}