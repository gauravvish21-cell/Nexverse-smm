import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
import { logger } from "../lib/logger";
import { configuredAdminRole, roleCan, type AdminRole } from "./admin-auth.mjs";
import { config } from "./config.mjs";
import { audit, adjustWallet, approvePayment, one, pool, rejectAndRefund, rejectPayment, transaction } from "./database";
import { DomainError, money, rupees } from "./money.mjs";
import { button, editAdminUntil, errorForUser, getSession, keyboard, recordAdminAttempt, resetSession, send, setSession, type CallbackContext, type MessageContext } from "./bot-utils";
import { sendPhoto, type InlineKeyboardButton } from "./telegram-api";

type Role = AdminRole;
const roles: Role[] = ["OWNER", "SUPER_ADMIN", "PAYMENT_ADMIN", "ORDER_MANAGER", "SERVICE_MANAGER", "SUPPORT_AGENT", "ANALYST"];
const TELEGRAM_TEXT_LIMIT = 3900;

function telegramSafeText(value: string) {
  const characters = Array.from(value);
  return characters.length <= TELEGRAM_TEXT_LIMIT
    ? value
    : `${characters.slice(0, TELEGRAM_TEXT_LIMIT - 24).join("")}\n… message shortened`;
}

async function getRole(userId: string): Promise<Role | null> {
  const configuredRole = configuredAdminRole(userId, config.adminIds);
  if (configuredRole) return configuredRole;
  const row = await one<{ role: Role }>(pool, "SELECT role FROM nx_admin_roles WHERE user_id=$1", [userId]);
  return row?.role ?? null;
}

export { roleCan };

async function hasAdminSession(userId: string) {
  const session = await getSession(userId);
  return Boolean(session.admin_until && new Date(session.admin_until).getTime() > Date.now());
}

function equalSecret(input: string, expected: string) {
  const left = createHash("sha256").update(input).digest();
  const right = createHash("sha256").update(expected).digest();
  return timingSafeEqual(left, right);
}

async function requireRole(userId: string, capability: string) {
  if (!(await hasAdminSession(userId))) return null;
  const role = await getRole(userId);
  return role && roleCan(role, capability) ? role : null;
}

function adminKeyboard(role: Role) {
  const entries: Array<[string, string, string]> = [
    ["Payments", "payments", "payments"],
    ["Orders", "orders", "orders"],
    ["Users", "users", "users"],
    ["Wallets", "wallets", "wallets"],
    ["Services", "services", "services"],
    ["Redeem Codes", "redeem", "redeem"],
    ["Coupons", "coupons", "coupons"],
    ["Support", "support", "support"],
    ["Announcements", "announcements", "announcements"],
    ["Notifications", "notifications", "notifications"],
    ["Referrals", "referrals", "referrals"],
    ["Audit Logs", "audit", "audit"],
    ["Analytics", "analytics", "analytics"],
    ["Settings", "settings", "settings"],
    ["Maintenance", "maintenance", "maintenance"],
    ["System Health", "health", "health"],
  ];
  const visible = entries.filter(([, capability]) => roleCan(role, capability));
  const rows: InlineKeyboardButton[][] = [];
  for (let i = 0; i < visible.length; i += 2) {
    rows.push(visible.slice(i, i + 2).map(([label, key]) => button(label, `adm:${key}`)));
  }
  rows.unshift([button("Search Records", "adm:search")]);
  rows.push([button("Log Out", "adm:logout"), button("Home", "home")]);
  return keyboard(rows);
}

async function adminHome(chatId: string, userId: string) {
  const role = await getRole(userId);
  if (!role || !(await hasAdminSession(userId))) {
    await send(chatId, "Admin session expired. Use /admin to sign in again.", keyboard([[button("Home", "home")]]));
    return;
  }
  await send(chatId, `NEXVERSE ADMIN\nRole: ${role}\nChoose a section.`, adminKeyboard(role));
}

export async function startAdmin(ctx: MessageContext) {
  const userId = String(ctx.user.id);
  const role = await getRole(userId);
  if (!role) {
    await send(ctx.chatId, "Admin access is not enabled for this Telegram account.", keyboard([[button("Home", "home")]]));
    return true;
  }
  if (!config.adminPassword) {
    await send(ctx.chatId, "Admin sign-in is unavailable because the private admin password is not configured.", keyboard([[button("Home", "home")]]));
    return true;
  }
  const session = await getSession(userId);
  if (session.locked_until && new Date(session.locked_until).getTime() > Date.now()) {
    await send(ctx.chatId, "Too many incorrect attempts. Try again after the account lock expires.", keyboard([[button("Home", "home")]]));
    return true;
  }
  if (await hasAdminSession(userId)) {
    await adminHome(ctx.chatId, userId);
    return true;
  }
  await setSession(userId, "admin_password", {});
  await send(ctx.chatId, "Enter the private administrator password. Do not share it in a group chat.", keyboard([[button("Cancel", "cancel")]]));
  return true;
}

export async function handleAdminCommand(ctx: MessageContext, args: string[]) {
  if (!args.length) return startAdmin(ctx);
  const userId = String(ctx.user.id);
  const role = await requireRole(userId, "settings");
  if (args[0] === "role" && role && (role === "OWNER" || role === "SUPER_ADMIN")) {
    const targetId = args[1] ?? "";
    const roleName = (args[2] ?? "").toUpperCase() as Role;
    if (!/^\d{1,20}$/.test(targetId) || !roles.includes(roleName) || roleName === "OWNER") {
      await send(ctx.chatId, "Usage: /admin role <telegram_id> <SUPER_ADMIN|PAYMENT_ADMIN|ORDER_MANAGER|SERVICE_MANAGER|SUPPORT_AGENT|ANALYST>", keyboard([[button("Admin Menu", "adm:home")]]));
      return true;
    }
    const exists = await one<{ id: string }>(pool, "SELECT id::text FROM nx_users WHERE id=$1", [targetId]);
    if (!exists) {
      await send(ctx.chatId, "That Telegram account must open the bot with /start before receiving an admin role.", keyboard([[button("Admin Menu", "adm:home")]]));
      return true;
    }
    await transaction(async (db) => {
      await db.query(
        `INSERT INTO nx_admin_roles(user_id,role,assigned_by)
         VALUES($1,$2,$3) ON CONFLICT(user_id) DO UPDATE SET role=EXCLUDED.role,assigned_by=EXCLUDED.assigned_by,updated_at=now()`,
        [targetId, roleName, userId],
      );
      await audit(db, userId, "ADMIN_ROLE_ASSIGNED", targetId, { role: roleName });
    });
    await send(ctx.chatId, `Assigned ${roleName} to Telegram account ${targetId}.`, keyboard([[button("Admin Menu", "adm:home")]]));
    return true;
  }
  return false;
}

export async function handleAdminMessage(ctx: MessageContext) {
  const userId = String(ctx.user.id);
  const session = await getSession(userId);
  const body = ctx.message.text?.trim() ?? "";
  if (session.state === "admin_password") {
    if (session.locked_until && new Date(session.locked_until).getTime() > Date.now()) {
      await send(ctx.chatId, "Too many incorrect attempts. Try again after the account lock expires.", keyboard([[button("Home", "home")]]));
      return true;
    }
    const isKnownAdmin = Boolean(await getRole(userId));
    const ok = isKnownAdmin && config.adminPassword.length > 0 && equalSecret(body, config.adminPassword);
    await recordAdminAttempt(userId, ok);
    await audit(pool, userId, ok ? "ADMIN_LOGIN" : "ADMIN_LOGIN_FAILED", userId, {});
    if (!ok) {
      const updated = await getSession(userId);
      await send(ctx.chatId, updated.locked_until ? "Too many incorrect attempts. Try again later." : "Incorrect password. Try again or cancel.", keyboard([[button("Cancel", "cancel")]]));
      return true;
    }
    await setSession(userId, "menu", {}, true);
    await editAdminUntil(userId, new Date(Date.now() + 30 * 60 * 1000));
    await adminHome(ctx.chatId, userId);
    return true;
  }
  const state = session.state;
  if (!state.startsWith("admin_")) return false;
  const capability = ({
    admin_payment_reject: "payments",
    admin_payment_search: "payments",
    admin_order_note: "orders",
    admin_order_search: "orders",
    admin_user_search: "users",
    admin_user_search_page: "users",
    admin_tx_search: "audit",
    admin_service_search: "services",
    admin_redeem_search: "redeem",
    admin_redeem_search_page: "redeem",
    admin_wallet_adjust: "wallets",
    admin_service_cost: "services",
    admin_redeem_create: "redeem",
    admin_coupon_create: "coupons",
    admin_support_reply: "support",
    admin_announcement: "announcements",
    admin_referral_config: "referrals",
  } as Record<string, string>)[state] ?? "";
  const role = await requireRole(userId, capability);
  if (!role) {
    await send(ctx.chatId, "Your administrator session expired or does not have permission for this action.", keyboard([[button("Admin Menu", "adm:home")]]));
    return true;
  }
  try {
    if (state === "admin_payment_reject") {
      const paymentId = String(session.data.paymentId ?? "");
      if (!isUuid(paymentId) || body.length < 3) throw new DomainError("Enter a rejection reason of at least three characters.");
      const result = await rejectPayment(paymentId, userId, body);
      await resetSession(userId, true);
      await send(ctx.chatId, result.duplicate ? `Payment is already ${result.status}.` : "Payment rejected. No wallet credit was made.", keyboard([[button("Payments", "adm:payments:PENDING:0"), button("Admin Menu", "adm:home")]]));
      return true;
    }
    if (state === "admin_order_note") {
      const orderId = String(session.data.orderId ?? "");
      if (!isUuid(orderId) || body.length < 2) throw new DomainError("Enter an internal note.");
      await pool.query("UPDATE nx_orders SET internal_notes=concat(internal_notes,$2),updated_at=now() WHERE id=$1", [orderId, `\n${new Date().toISOString()} by ${userId}: ${body.slice(0, 500)}`]);
      await audit(pool, userId, "ORDER_NOTE_ADDED", orderId, {});
      await resetSession(userId, true);
      await send(ctx.chatId, "Internal note saved.", keyboard([[button("Admin Orders", "adm:orders:0"), button("Admin Menu", "adm:home")]]));
      return true;
    }
    if (state === "admin_order_search") {
      await searchOrders(ctx.chatId, body);
      await resetSession(userId, true);
      return true;
    }
    if (state === "admin_payment_search") {
      await searchPayments(ctx.chatId, body);
      await resetSession(userId, true);
      return true;
    }
    if (state === "admin_tx_search") {
      await searchTransactions(ctx.chatId, body);
      await resetSession(userId, true);
      return true;
    }
    if (state === "admin_service_search") {
      await searchServices(ctx.chatId, body);
      await resetSession(userId, true);
      return true;
    }
    if (state === "admin_redeem_search") {
      const query = body.trim().slice(0, 32);
      await setSession(userId, "admin_redeem_search_page", { query, page: 0 }, true);
      await showRedeemCodes(ctx.chatId, 0, query);
      return true;
    }
    if (state === "admin_redeem_search_page") {
      const query = String(session.data.query ?? "");
      const page = Number(session.data.page ?? 0);
      await showRedeemCodes(ctx.chatId, page, query);
      return true;
    }
    if (state === "admin_order_refund_reason") {
      const orderId = String(session.data.orderId ?? "");
      if (!isUuid(orderId) || body.length < 3) throw new DomainError("Enter a refund reason of at least three characters.");
      const result = await rejectAndRefund(orderId, userId, body);
      await resetSession(userId, true);
      await send(ctx.chatId, result.duplicate ? "This order was already refunded." : `Order rejected and ${rupees(result.amount)} refunded to the customer's wallet.`, keyboard([[button("Order Details", `adm:orders:detail:${orderId}`), button("Admin Menu", "adm:home")]]));
      return true;
    }
    if (state === "admin_user_search") {
      await setSession(userId, "admin_user_search_page", { query: body.slice(0, 80), page: 0 });
      await searchUsers(ctx.chatId, body, 0);
      return true;
    }
    if (state === "admin_user_search_page") {
      const query = String(session.data.query ?? "");
      const page = Number(session.data.page ?? 0);
      await searchUsers(ctx.chatId, query, page);
      return true;
    }
    if (state === "admin_wallet_adjust") {
      await stageWalletAdjustment(ctx, body);
      return true;
    }
    if (state === "admin_service_cost") {
      await stageServiceCost(ctx, Number(session.data.serviceId), body);
      return true;
    }
    if (state === "admin_redeem_create") {
      await createRedeemCode(ctx, body);
      return true;
    }
    if (state === "admin_coupon_create") {
      await createCoupon(ctx, body);
      return true;
    }
    if (state === "admin_support_reply") {
      await addAdminTicketReply(ctx, String(session.data.ticketId ?? ""), body);
      return true;
    }
    if (state === "admin_announcement") {
      await createAnnouncement(ctx, body);
      return true;
    }
    if (state === "admin_referral_config") {
      await setReferralConfig(ctx, body);
      return true;
    }
  } catch (error) {
    const recordId = [session.data.orderId, session.data.ticketId].find((value): value is string => typeof value === "string");
    await send(
      ctx.chatId,
      errorForUser(error, { area: "admin-message", action: state, adminId: userId, recordId }),
      keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]),
    );
    return true;
  }
  return false;
}

function isUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

async function showPayments(chatId: string, status: string, page = 0) {
  if (!["PENDING", "APPROVED", "REJECTED"].includes(status)) status = "PENDING";
  const rows = await pool.query(
    `SELECT p.id,p.user_id::text,p.user_name,p.username,p.amount::text,p.utr,p.status,p.created_at
     FROM nx_payments p WHERE p.status=$1 ORDER BY p.created_at DESC LIMIT 8 OFFSET $2`,
    [status, page * 8],
  );
  const result = rows.rows as Array<{ id: string; user_id: string; user_name: string; username: string | null; amount: string; utr: string; status: string; created_at: Date }>;
  const messages: string[] = [];
  const buttons: InlineKeyboardButton[][] = result.map((payment) => {
    messages.push(
      `Payment ID: ${payment.id}\nUser: ${payment.user_name}${payment.username ? ` (@${payment.username})` : ""} · ${payment.user_id}\nAmount: ${rupees(payment.amount)}\nUTR: ${payment.utr}\nStatus: ${payment.status}\nTime: ${new Date(payment.created_at).toISOString()}`,
    );
    return payment.status === "PENDING"
      ? [button(`Screenshot ${payment.id.slice(0, 8)}`, `adm:payment:image:${payment.id}`), button("Approve", `adm:payment:approve:${payment.id}`), button("Reject", `adm:payment:reject:${payment.id}`)]
      : [button(`Screenshot ${payment.id.slice(0, 8)}`, `adm:payment:image:${payment.id}`)];
  });
  buttons.unshift([
    button("Pending", "adm:payments:PENDING:0"),
    button("Approved", "adm:payments:APPROVED:0"),
    button("Rejected", "adm:payments:REJECTED:0"),
  ]);
  buttons.splice(1, 0, [button("Search ID / UTR / User", "adm:payments:search")]);
  if (result.length === 8) buttons.push([button("Next", `adm:payments:${status}:${page + 1}`)]);
  buttons.push([button("Admin Menu", "adm:home")]);
  await send(chatId, messages.length ? messages.join("\n\n────────\n\n") : `No ${status.toLowerCase()} payments.`, keyboard(buttons));
}

async function paymentScreenshot(chatId: string, paymentId: string) {
  const asset = await one<{ telegram_file_id: string; user_name: string; amount: string; utr: string }>(
    pool,
    `SELECT a.telegram_file_id,p.user_name,p.amount::text,p.utr
     FROM nx_payments p JOIN nx_assets a ON a.id=p.screenshot_id WHERE p.id=$1`,
    [paymentId],
  );
  if (!asset) {
    await send(chatId, "Payment or screenshot not found.", keyboard([[button("Payments", "adm:payments:PENDING:0")]]));
    return;
  }
  await sendPhoto(chatId, asset.telegram_file_id, `Payment ${paymentId}\n${asset.user_name} · ${rupees(asset.amount)}\nUTR: ${asset.utr}`);
}

async function showOrders(chatId: string, page = 0, statusFilter = "ALL") {
  const allowedStatuses = ["ALL", "PENDING", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED", "REJECTED", "REFUNDED"];
  const status = allowedStatuses.includes(statusFilter) ? statusFilter : "ALL";
  page = Math.max(0, Math.min(Number.isSafeInteger(page) ? page : 0, 10000));
  const count = await one<{ total: string }>(
    pool,
    "SELECT count(*)::text AS total FROM nx_orders WHERE $1='ALL' OR status=$1",
    [status],
  );
  const pages = Math.max(1, Math.ceil(Number(count?.total ?? 0) / 8));
  page = Math.min(page, pages - 1);
  const result = await pool.query(
    `SELECT o.id,o.user_id::text,o.service_name,o.quantity,o.amount::text,o.status,o.created_at,u.name,u.username
     FROM nx_orders o LEFT JOIN nx_users u ON u.id=o.user_id
     WHERE $1='ALL' OR o.status=$1
     ORDER BY o.created_at DESC LIMIT 8 OFFSET $2`,
    [status, page * 8],
  );
  const rows = result.rows as Array<{ id: string; user_id: string; service_name: string; quantity: number; amount: string; status: string; created_at: Date; name: string | null; username: string | null }>;
  const buttons = rows.map((order) => [button(`#${order.id.slice(0, 8)} · ${order.status} · ${(order.name ?? "Unknown user").slice(0, 18)}`, `adm:orders:detail:${order.id}`)]);
  buttons.unshift([
    button("All", "adm:orders:ALL:0"),
    button("Pending", "adm:orders:PENDING:0"),
    button("Processing", "adm:orders:PROCESSING:0"),
  ]);
  buttons.splice(1, 0, [
    button("Completed", "adm:orders:COMPLETED:0"),
    button("Failed", "adm:orders:FAILED:0"),
    button("Rejected", "adm:orders:REJECTED:0"),
  ]);
  buttons.splice(2, 0, [
    button("Cancelled", "adm:orders:CANCELLED:0"),
    button("Refunded", "adm:orders:REFUNDED:0"),
  ]);
  const paging = [
    ...(page > 0 ? [button("Previous", `adm:orders:${status}:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `adm:orders:${status}:${page + 1}`)] : []),
  ];
  if (paging.length) buttons.push(paging);
  buttons.push([button("Search Orders", "adm:orders:search"), button("Admin Menu", "adm:home")]);
  const lines = rows.map((order) => `${order.id}\n${order.service_name}\n${order.quantity} · ${rupees(order.amount)} · ${order.status}\nCustomer: ${order.username ? `@${order.username}` : order.name ?? "Unknown customer"} · ${order.user_id}`).join("\n\n");
  const statusLabel = status === "ALL" ? "All" : status;
  await send(chatId, telegramSafeText(`${statusLabel} orders · Page ${page + 1} of ${pages}\n\n${lines || "No orders found."}`), keyboard(buttons));
}

async function orderDetails(chatId: string, orderId: string) {
  const order = await one<{ id: string; user_id: string; service_name: string; quantity: number; target: string; amount: string; status: string; created_at: Date; updated_at: Date; internal_notes: string; extras: string }>(
    pool, "SELECT id,user_id::text,service_name,quantity,target,amount::text,status,created_at,updated_at,internal_notes,extras FROM nx_orders WHERE id=$1", [orderId],
  );
  if (!order) {
    await send(chatId, "Order not found.", keyboard([[button("Orders", "adm:orders:0")]]));
    return;
  }
  const statusButtons: InlineKeyboardButton[][] = [];
  if (order.status === "PENDING") {
    statusButtons.push([button("Processing", `adm:orders:s:${order.id}:PROCESSING`), button("Complete", `adm:orders:s:${order.id}:COMPLETED`)]);
    statusButtons.push([button("Mark Failed", `adm:orders:s:${order.id}:FAILED`), button("Cancel", `adm:orders:s:${order.id}:CANCELLED`)]);
    statusButtons.push([button("Reject", `adm:orders:status:${order.id}:REJECTED`), button("Reject & Refund", `adm:orders:refund:${order.id}`)]);
  } else if (order.status === "PROCESSING") {
    statusButtons.push([button("Complete", `adm:orders:s:${order.id}:COMPLETED`), button("Mark Failed", `adm:orders:s:${order.id}:FAILED`)]);
    statusButtons.push([button("Cancel", `adm:orders:s:${order.id}:CANCELLED`), button("Reject", `adm:orders:status:${order.id}:REJECTED`)]);
  }
  statusButtons.push([button("Add Internal Note", `adm:orders:note:${order.id}`), button("User Details", `adm:user:${order.user_id}`)]);
  statusButtons.push([button("Admin Orders", "adm:orders:0"), button("Admin Menu", "adm:home")]);
  await send(chatId, telegramSafeText([
    `Order ID: ${order.id}`,
    `User: ${order.user_id}`,
    `Service: ${order.service_name}`,
    `Quantity: ${order.quantity}`,
    `Target: ${order.target}`,
    `Amount: ${rupees(order.amount)}`,
    `Status: ${order.status}`,
    `Created: ${new Date(order.created_at).toISOString()}`,
    `Updated: ${new Date(order.updated_at).toISOString()}`,
    order.extras ? `Extra instructions: ${order.extras}` : "",
    order.internal_notes ? `Internal notes: ${order.internal_notes}` : "",
  ].filter(Boolean).join("\n")), keyboard(statusButtons));
}

async function searchUsers(chatId: string, search: string, page = 0) {
  const term = search.trim().slice(0, 80);
  const result = await pool.query(
    `SELECT id::text,username,name,created_at,suspended FROM nx_users
     WHERE id::text=$1 OR username ILIKE $2 OR name ILIKE $2 ORDER BY created_at DESC LIMIT 8 OFFSET $3`,
    [term, `%${term}%`, page * 8],
  );
  const rows = result.rows as Array<{ id: string; username: string | null; name: string; created_at: Date; suspended: boolean }>;
  const buttons = rows.map((user) => [button(`${user.name.slice(0, 30)} · ${user.id}`, `adm:user:${user.id}`)]);
  if (rows.length === 8) buttons.push([button("Next Results", `adm:users:page:${page + 1}`)]);
  buttons.push([button("Search Again", "adm:users:search"), button("Admin Menu", "adm:home")]);
  await send(chatId, rows.length ? `Found ${rows.length} accounts.` : "No matching accounts.", keyboard(buttons));
}

async function searchOrders(chatId: string, search: string) {
  const term = search.trim().slice(0, 80);
  const result = await pool.query(
    `SELECT o.id,o.service_name,o.status,o.amount::text,u.id::text AS user_id,u.name
     FROM nx_orders o JOIN nx_users u ON u.id=o.user_id
     WHERE o.id::text=$1 OR u.id::text=$1 OR u.username ILIKE $2 OR u.name ILIKE $2 OR o.service_name ILIKE $2
     ORDER BY o.created_at DESC LIMIT 8`,
    [term, `%${term}%`],
  );
  const rows = result.rows as Array<{ id: string; service_name: string; status: string; amount: string; user_id: string; name: string }>;
  const buttons = rows.map((order) => [button(`${order.id.slice(0, 8)} · ${order.status} · ${order.name.slice(0, 18)}`, `adm:orders:detail:${order.id}`)]);
  buttons.push([button("Search Again", "adm:orders:search"), button("Admin Menu", "adm:home")]);
  await send(chatId, telegramSafeText(rows.map((order) => `${order.id}\n${order.service_name} · ${order.status} · ${rupees(order.amount)}\n${order.name} · ${order.user_id}`).join("\n\n") || "No matching orders."), keyboard(buttons));
}

async function searchPayments(chatId: string, search: string) {
  const term = search.trim().slice(0, 80);
  const result = await pool.query(
    `SELECT p.id,p.status,p.amount::text,p.utr,p.user_id::text,p.user_name
     FROM nx_payments p WHERE p.id::text=$1 OR p.utr ILIKE $2 OR p.user_id::text=$1 OR p.username ILIKE $2
     ORDER BY p.created_at DESC LIMIT 8`,
    [term, `%${term}%`],
  );
  const rows = result.rows as Array<{ id: string; status: string; amount: string; utr: string; user_id: string; user_name: string }>;
  const buttons = rows.map((payment) => [button(`${payment.status} · ${payment.id.slice(0, 8)} · ${payment.user_name.slice(0, 16)}`, `adm:payment:image:${payment.id}`)]);
  buttons.push([button("Payments", "adm:payments"), button("Admin Menu", "adm:home")]);
  await send(chatId, rows.map((payment) => `${payment.id} · ${payment.status}\n${payment.user_name} (${payment.user_id}) · ${rupees(payment.amount)} · UTR ${payment.utr}`).join("\n\n") || "No matching payments.", keyboard(buttons));
}

async function searchTransactions(chatId: string, search: string) {
  const term = search.trim().slice(0, 80);
  const result = await pool.query(
    `SELECT id::text,user_id::text,type,amount::text,reference_id,description,created_at
     FROM nx_ledger WHERE id::text=$1 OR reference_id=$1 OR user_id::text=$1
     ORDER BY created_at DESC LIMIT 8`,
    [term],
  );
  const rows = result.rows as Array<{ id: string; user_id: string; type: string; amount: string; reference_id: string; description: string; created_at: Date }>;
  await send(chatId, rows.map((row) => `${row.id} · ${row.type} · ${rupees(row.amount)}\nUser ${row.user_id} · Ref ${row.reference_id}\n${row.description} · ${new Date(row.created_at).toISOString()}`).join("\n\n") || "No matching transactions.", keyboard([[button("Search Again", "adm:txsearch"), button("Admin Menu", "adm:home")]]));
}

async function searchServices(chatId: string, search: string) {
  const term = search.trim().slice(0, 80);
  const result = await pool.query(
    "SELECT id,name,enabled FROM nx_services WHERE id::text=$1 OR name ILIKE $2 ORDER BY id LIMIT 8",
    [term, `%${term}%`],
  );
  const rows = result.rows as Array<{ id: number; name: string; enabled: boolean }>;
  await send(chatId, rows.map((row) => `${row.id} · ${row.enabled ? "enabled" : "disabled"} · ${row.name}`).join("\n") || "No matching services.", keyboard([
    ...rows.map((row) => [button(`Service ${row.id}`, `adm:service:detail:${row.id}`)]),
    [button("Search Again", "adm:servicefind"), button("Admin Menu", "adm:home")],
  ]));
}

async function redeemHistory(chatId: string, code: string) {
  const rows = await pool.query(
    `SELECT r.user_id::text,u.name,r.amount::text,r.created_at
     FROM nx_redemptions r JOIN nx_users u ON u.id=r.user_id
     WHERE r.code=$1 ORDER BY r.created_at DESC LIMIT 20`,
    [code],
  );
  const lines = (rows.rows as Array<{ user_id: string; name: string; amount: string; created_at: Date }>).map((row) =>
    `${row.name} · ${row.user_id} · ${rupees(row.amount)} · ${new Date(row.created_at).toISOString()}`,
  );
  await send(chatId, `Redemptions for ${code}\n${lines.join("\n") || "None yet."}`, keyboard([[button("Redeem Codes", "adm:redeem"), button("Admin Menu", "adm:home")]]));
}

async function showReconciliation(chatId: string, periodDays = 30) {
  const days = Math.max(1, Math.min(365, Number.isSafeInteger(periodDays) ? periodDays : 30));
  const summary = await one<{
    deposits: string; order_debits: string; refunds: string; redeem: string; bonuses: string;
    adjustments: string; liability: string; ledger_total: string;
    wallet_total: string; mismatch: string; pending: string;
  }>(
    pool,
    `SELECT
       coalesce(sum(amount) FILTER(WHERE type='DEPOSIT' AND created_at>=now()-($1::text||' days')::interval),0)::text AS deposits,
       coalesce(sum(-amount) FILTER(WHERE type='ORDER_DEBIT' AND created_at>=now()-($1::text||' days')::interval),0)::text AS order_debits,
       coalesce(sum(amount) FILTER(WHERE type='REFUND' AND created_at>=now()-($1::text||' days')::interval),0)::text AS refunds,
       coalesce(sum(amount) FILTER(WHERE type='REDEEM' AND created_at>=now()-($1::text||' days')::interval),0)::text AS redeem,
       coalesce(sum(amount) FILTER(WHERE type='BONUS' AND created_at>=now()-($1::text||' days')::interval),0)::text AS bonuses,
       coalesce(sum(amount) FILTER(WHERE type='ADMIN_ADJUSTMENT' AND created_at>=now()-($1::text||' days')::interval),0)::text AS adjustments,
       coalesce((SELECT sum(balance) FROM nx_wallets),0)::text AS liability,
       coalesce((SELECT sum(amount) FROM nx_ledger),0)::text AS ledger_total,
       coalesce((SELECT sum(balance) FROM nx_wallets),0)::text AS wallet_total,
       ((SELECT coalesce(sum(amount),0) FROM nx_ledger)-(SELECT coalesce(sum(balance),0) FROM nx_wallets))::text AS mismatch,
       (SELECT count(*)::text FROM nx_payments WHERE status='PENDING') AS pending
     FROM nx_ledger`,
    [days],
  );
  const top = await pool.query(
    `SELECT service_name,count(*)::text AS orders,coalesce(sum(amount),0)::text AS volume
     FROM nx_orders WHERE created_at>=now()-($1::text||' days')::interval
     GROUP BY service_name ORDER BY count(*) DESC LIMIT 5`,
    [days],
  );
  const referrals = await one<{ total: string; rewards: string }>(
    pool,
    `SELECT count(*)::text AS total,coalesce(sum(amount),0)::text AS rewards
     FROM nx_referrals WHERE created_at>=now()-($1::text||' days')::interval`,
    [days],
  );
  await send(chatId, [
    `Financial reconciliation · last ${days} days`,
    `Approved deposits: ${rupees(summary?.deposits ?? "0")}`,
    `Order debits: ${rupees(summary?.order_debits ?? "0")}`,
    `Refunds: ${rupees(summary?.refunds ?? "0")}`,
    `Redeem credits: ${rupees(summary?.redeem ?? "0")} · Bonuses: ${rupees(summary?.bonuses ?? "0")}`,
    `Admin adjustments (net): ${rupees(summary?.adjustments ?? "0")}`,
    `Customer wallet liability: ${rupees(summary?.liability ?? "0")}`,
    `Ledger balance sum: ${rupees(summary?.ledger_total ?? "0")} · Wallet balance sum: ${rupees(summary?.wallet_total ?? "0")}`,
    `Ledger/wallet difference: ${rupees(summary?.mismatch ?? "0")}`,
    `Pending payments: ${summary?.pending ?? "0"}`,
    "",
    `Top services:\n${(top.rows as Array<{ service_name: string; orders: string; volume: string }>).map((row) => `${row.service_name} · ${row.orders} orders · ${rupees(row.volume)}`).join("\n") || "No orders."}`,
    `Referral activity: ${referrals?.total ?? "0"} joined · ${rupees(referrals?.rewards ?? "0")} rewarded`,
    "The wallet liability is the sum of current wallet balances; reconciliation uses ledger and wallet records.",
  ].join("\n"), keyboard([
    [button("7 days", "adm:reconcile:7"), button("30 days", "adm:reconcile:30"), button("90 days", "adm:reconcile:90")],
    [button("Admin Menu", "adm:home")],
  ]));
}

export async function handleAdminCallback(ctx: CallbackContext, data: string) {
  if (!data.startsWith("adm:")) return false;
  const userId = String(ctx.user.id);
  const chatId = ctx.chatId;
  if (data === "adm:home") {
    if (!(await hasAdminSession(userId)) || !(await getRole(userId))) {
      await send(chatId, "Admin session expired. Use /admin to sign in.", keyboard([[button("Home", "home")]]));
    } else await adminHome(chatId, userId);
    return true;
  }
  if (data === "adm:logout") {
    if (!(await hasAdminSession(userId)) || !(await getRole(userId))) {
      await send(chatId, "Admin session expired.", keyboard([[button("Home", "home")]]));
    } else {
      await resetSession(userId, false);
      await audit(pool, userId, "ADMIN_LOGOUT", userId, {});
      await send(chatId, "Admin session ended.", keyboard([[button("Home", "home")]]));
    }
    return true;
  }
  if (data === "adm:search") {
    const searchRole = await getRole(userId);
    if (!searchRole || !(await hasAdminSession(userId))) {
      await send(chatId, "Admin session expired. Use /admin to sign in.", keyboard([[button("Home", "home")]]));
      return true;
    }
    const rows: InlineKeyboardButton[][] = [];
    if (roleCan(searchRole, "users")) rows.push([button("Users", "adm:users:search")]);
    if (roleCan(searchRole, "orders")) rows.push([button("Orders", "adm:orders:search")]);
    if (roleCan(searchRole, "payments")) rows.push([button("Payments / UTR", "adm:payments:search")]);
    if (roleCan(searchRole, "audit")) rows.push([button("Transactions", "adm:txsearch")]);
    if (roleCan(searchRole, "services")) rows.push([button("Services", "adm:servicefind")]);
    if (roleCan(searchRole, "redeem")) rows.push([button("Redeem Codes", "adm:redeemsearch")]);
    rows.push([button("Admin Menu", "adm:home")]);
    await send(chatId, "Choose what to search.", keyboard(rows));
    return true;
  }
  const parts = data.split(":");
  const section = parts[1] ?? "";
  const capabilityBySection: Record<string, string> = {
    payments: "payments", payment: "payments",
    orders: "orders", order: "orders",
    users: "users", user: "users", userorders: "users", userpayments: "users", usertickets: "users", ledger: "users",
    wallets: "wallets", wallet: "wallets",
    services: "services", service: "services",
    redeem: "redeem", coupon: "coupons", coupons: "coupons",
    support: "support", ss: "support", announcements: "announcements",
    notifications: "notifications", outbox: "notifications",
    referrals: "referrals", audit: "audit", analytics: "analytics", reconcile: "analytics",
    txsearch: "audit", servicefind: "services", redeemsearch: "redeem",
    settings: "settings", maintenance: "maintenance", health: "health",
  };
  const capability = capabilityBySection[section];
  const role = capability ? await requireRole(userId, capability) : null;
  if (!role) {
    await send(chatId, "Your admin session expired or your role does not allow this action.", keyboard([[button("Admin Menu", "adm:home"), button("Home", "home")]]));
    return true;
  }
  try {
    if (section === "payments" && parts.length === 2) await showPayments(chatId, "PENDING", 0);
    else if (section === "payments" && parts[2] === "search") {
      await setSession(userId, "admin_payment_search", {}, true);
      await send(chatId, "Search payments by payment ID, UTR, Telegram ID, or username.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "payments" && parts.length >= 4) await showPayments(chatId, parts[2], Number(parts[3]));
    else if (section === "payment" && parts[2] === "image" && isUuid(parts[3] ?? "")) await paymentScreenshot(chatId, parts[3]);
    else if (section === "payment" && parts[2] === "approve" && isUuid(parts[3] ?? "")) {
      await send(chatId, `Approve payment ${parts[3]}?\nThis credits the exact pending amount once.`, keyboard([
        [button("Confirm Approval", `adm:payment:approve2:${parts[3]}`)],
        [button("Cancel", "adm:payments:PENDING:0"), button("Admin Menu", "adm:home")],
      ]));
    } else if (section === "payment" && parts[2] === "approve2" && isUuid(parts[3] ?? "")) {
      const result = await approvePayment(parts[3], userId);
      await send(chatId, result.duplicate ? `Payment is already ${result.status}. No additional credit was made.` : "Payment approved and wallet credited exactly once.", keyboard([[button("Payments", "adm:payments:PENDING:0"), button("Admin Menu", "adm:home")]]));
    } else if (section === "payment" && parts[2] === "reject" && isUuid(parts[3] ?? "")) {
      await setSession(userId, "admin_payment_reject", { paymentId: parts[3] }, true);
      await send(chatId, "Enter the rejection reason. Rejection will not credit the wallet.", keyboard([[button("Cancel", "cancel"), button("Payments", "adm:payments:PENDING:0")]]));
    } else if (section === "orders" && parts.length === 2) await showOrders(chatId);
    else if (section === "orders" && ["ALL", "PENDING", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED", "REJECTED", "REFUNDED"].includes(parts[2] ?? "") && /^\d+$/.test(parts[3] ?? "")) {
      await showOrders(chatId, Number(parts[3]), parts[2]);
    } else if (section === "orders" && /^\d+$/.test(parts[2] ?? "")) await showOrders(chatId, Number(parts[2]));
    else if (section === "orders" && parts[2] === "search") {
      await setSession(userId, "admin_order_search", {}, true);
      await send(chatId, "Search orders by order ID, Telegram ID, username, name, or service name.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "orders" && parts[2] === "detail" && isUuid(parts[3] ?? "")) await orderDetails(chatId, parts[3]);
    else if (section === "orders" && (parts[2] === "status" || parts[2] === "s") && isUuid(parts[3] ?? "") && /^[A-Z_]+$/.test(parts[4] ?? "")) {
      const status = parts[4];
      await send(chatId, `Confirm order ${parts[3]} status change to ${status}? This does not issue a refund.`, keyboard([
        [button("Confirm Status", `adm:orders:s2:${parts[3]}:${status}`)],
        [button("Cancel", `adm:orders:detail:${parts[3]}`)],
      ]));
    } else if (section === "orders" && (parts[2] === "status2" || parts[2] === "s2") && isUuid(parts[3] ?? "")) await confirmOrderStatus(chatId, userId, parts[3], parts[4] ?? "");
    else if (section === "orders" && parts[2] === "refund" && isUuid(parts[3] ?? "")) {
      await send(chatId, `Reject and refund order ${parts[3]}?\nOnly a PENDING order can be refunded. The refund uses the original debit amount.`, keyboard([
        [button("Confirm Reject & Refund", `adm:orders:refund2:${parts[3]}`)],
        [button("Cancel", `adm:orders:detail:${parts[3]}`)],
      ]));
    } else if (section === "orders" && parts[2] === "refund2" && isUuid(parts[3] ?? "")) {
      await setSession(userId, "admin_order_refund_reason", { orderId: parts[3] }, true);
      await send(chatId, "Enter a reason for rejecting and refunding this order.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "orders" && parts[2] === "note" && isUuid(parts[3] ?? "")) {
      await setSession(userId, "admin_order_note", { orderId: parts[3] }, true);
      await send(chatId, "Enter an internal note. The customer will not see it.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "users" && parts[2] === "search") {
      await setSession(userId, "admin_user_search", {}, true);
      await send(chatId, "Search by Telegram ID, username, or name.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "txsearch") {
      await setSession(userId, "admin_tx_search", {}, true);
      await send(chatId, "Search ledger entries by transaction ID, reference ID, or Telegram ID.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "servicefind") {
      await setSession(userId, "admin_service_search", {}, true);
      await send(chatId, "Search services by ID or service name.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "redeemsearch") {
      await setSession(userId, "admin_redeem_search", {}, true);
      await send(chatId, "Search redeem codes by code.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "redeem" && parts[2] === "searchpage" && /^\d+$/.test(parts[3] ?? "")) {
      const session = await getSession(userId);
      if (session.state === "admin_redeem_search_page") {
        const page = Math.min(10000, Number(parts[3]));
        await setSession(userId, "admin_redeem_search_page", { ...session.data, page }, true);
        await showRedeemCodes(chatId, page, String(session.data.query ?? ""));
      } else await send(chatId, "Redeem search expired.", keyboard([[button("Search Again", "adm:redeemsearch")]]));
    } else if (section === "users" && parts[2] === "page" && /^\d+$/.test(parts[3] ?? "")) {
      const session = await getSession(userId);
      if (session.state === "admin_user_search_page") {
        await setSession(userId, "admin_user_search_page", { ...session.data, page: Number(parts[3]) }, true);
        await searchUsers(chatId, String(session.data.query ?? ""), Number(parts[3]));
      } else await send(chatId, "Search session expired.", keyboard([[button("Users", "adm:users:search")]]));
    } else if (section === "user" && /^\d{1,20}$/.test(parts[2] ?? "")) await userDetails(chatId, parts[2]);
    else if (["userorders", "userpayments", "usertickets", "ledger"].includes(section) && /^\d{1,20}$/.test(parts[2] ?? "")) {
      const kind = ({ userorders: "orders", userpayments: "payments", usertickets: "tickets", ledger: "ledger" } as const)[section as "userorders" | "userpayments" | "usertickets" | "ledger"];
      await showUserRecords(chatId, parts[2], kind);
    } else if (section === "wallets") {
      await setSession(userId, "admin_wallet_adjust", {}, true);
      await send(chatId, "Use: <telegram_id> +<amount> <reason> or <telegram_id> -<amount> <reason>.\nA separate confirmation is required before the wallet changes.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "wallet" && parts[2] === "user" && /^\d{1,20}$/.test(parts[3] ?? "")) {
      await setSession(userId, "admin_wallet_adjust", {}, true);
      await send(chatId, `Enter an adjustment for user ${parts[3]} as: ${parts[3]} +<amount> <reason> or ${parts[3]} -<amount> <reason>.`, keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "wallet" && parts[2] === "confirm" && isUuid(parts[3] ?? "")) await confirmWalletAdjustment(chatId, userId, parts[3]);
    else if (section === "services" && parts.length === 2) await showServices(chatId);
    else if (section === "services" && /^\d+$/.test(parts[2] ?? "")) await showServices(chatId, Number(parts[2]));
    else if (section === "service" && parts[2] === "detail" && /^\d+$/.test(parts[3] ?? "")) await serviceDetails(chatId, Number(parts[3]));
    else if (section === "service" && parts[2] === "toggle" && /^\d+$/.test(parts[3] ?? "")) await toggleService(chatId, userId, Number(parts[3]));
    else if (section === "service" && parts[2] === "cost" && /^\d+$/.test(parts[3] ?? "")) {
      await setSession(userId, "admin_service_cost", { serviceId: Number(parts[3]) }, true);
      await send(chatId, "Enter the new supplier cost per 1,000 in INR (up to two decimal places). The customer price will be set to exactly 2×. A second confirmation is required.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "service" && parts[2] === "costconfirm" && isUuid(parts[3] ?? "")) await confirmServiceCost(chatId, userId, parts[3]);
    else if (section === "redeem" && (parts.length === 2 || parts[2] === "page")) await showRedeemCodes(chatId, parts[2] === "page" ? Number(parts[3] ?? 0) : 0);
    else if (section === "redeem" && parts[2] === "create") {
      await setSession(userId, "admin_redeem_create", {}, true);
      await send(chatId, "Create a code using: CODE AMOUNT_INR MAX_REDEMPTIONS EXPIRY_DAYS (0 = no expiry).", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "redeem" && parts[2] === "toggle" && /^[A-Z0-9-]{3,32}$/i.test(parts[3] ?? "")) await toggleRedeemCode(chatId, userId, parts[3].toUpperCase());
    else if (section === "redeem" && parts[2] === "history" && /^[A-Z0-9-]{3,32}$/i.test(parts[3] ?? "")) await redeemHistory(chatId, parts[3].toUpperCase());
    else if (section === "coupons") await showCoupons(chatId);
    else if (section === "coupon" && parts[2] === "create") {
      await setSession(userId, "admin_coupon_create", {}, true);
      await send(chatId, "Create a coupon using: CODE DISCOUNT_PERCENT MAX_USES EXPIRY_DAYS (0 = no expiry).", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "coupon" && parts[2] === "toggle" && /^[A-Z0-9-]{3,32}$/i.test(parts[3] ?? "")) await toggleCoupon(chatId, userId, parts[3].toUpperCase());
    else if (section === "support" && parts.length === 2) await showSupportTickets(chatId);
    else if (section === "support" && ["ALL", "OPEN", "IN_PROGRESS", "WAITING", "RESOLVED", "CLOSED"].includes(parts[2] ?? "") && /^\d+$/.test(parts[3] ?? "")) {
      await showSupportTickets(chatId, parts[2], Number(parts[3]));
    }
    else if (section === "support" && parts[2] === "detail" && isUuid(parts[3] ?? "")) await showAdminTicket(chatId, parts[3]);
    else if (section === "support" && parts[2] === "reply" && isUuid(parts[3] ?? "")) {
      await setSession(userId, "admin_support_reply", { ticketId: parts[3] }, true);
      await send(chatId, "Enter your reply to the customer.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "support" && parts[2] === "assign" && isUuid(parts[3] ?? "")) {
      await transaction(async (db) => {
        const row = await one<{ id: string }>(db, "SELECT id FROM nx_tickets WHERE id=$1 FOR UPDATE", [parts[3]]);
        if (!row) throw new DomainError("Ticket not found.");
        await db.query("UPDATE nx_tickets SET assigned_to=$2,updated_at=now() WHERE id=$1", [parts[3], userId]);
        await audit(db, userId, "TICKET_ASSIGNED", parts[3], {});
      });
      await send(chatId, "Ticket assigned to you.", keyboard([[button("View Ticket", `adm:support:detail:${parts[3]}`), button("Admin Menu", "adm:home")]]));
    } else if (
      (section === "support" && parts[2] === "status" && isUuid(parts[3] ?? "") && ["OPEN", "IN_PROGRESS", "WAITING", "RESOLVED", "CLOSED"].includes(parts[4] ?? "")) ||
      (section === "ss" && isUuid(parts[2] ?? "") && ["OPEN", "IN_PROGRESS", "WAITING", "RESOLVED", "CLOSED"].includes(parts[3] ?? ""))
    ) {
      const ticketId = section === "ss" ? parts[2] : parts[3];
      const nextStatus = section === "ss" ? parts[3] : parts[4];
      await transaction(async (db) => {
        const row = await one<{ status: string }>(db, "SELECT status FROM nx_tickets WHERE id=$1 FOR UPDATE", [ticketId]);
        if (!row) throw new DomainError("Ticket not found.");
        await db.query("UPDATE nx_tickets SET status=$2,updated_at=now() WHERE id=$1", [ticketId, nextStatus]);
        await audit(db, userId, "TICKET_STATUS_CHANGED", ticketId, { from: row.status, to: nextStatus });
      });
      await send(chatId, `Ticket status set to ${nextStatus}.`, keyboard([[button("View Ticket", `adm:support:detail:${ticketId}`), button("Admin Menu", "adm:home")]]));
    } else if (section === "announcements") {
      await setSession(userId, "admin_announcement", {}, true);
      await send(chatId, "Send: all <message> or user <telegram_id> <message>. This queues delivery to the outbox.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
    } else if (section === "notifications") await showNotifications(chatId);
    else if (section === "outbox" && parts[2] === "failed") await showFailedOutbox(chatId, Number(parts[3] ?? 0));
    else if (section === "outbox" && parts[2] === "retry" && isUuid(parts[3] ?? "")) {
      if (role !== "OWNER" && role !== "SUPER_ADMIN") throw new DomainError("Only an owner or super admin can retry failed deliveries.");
      await retryOutbox(chatId, userId, parts[3]);
    } else if (section === "referrals") {
      if (parts[2] === "configure") {
        await setSession(userId, "admin_referral_config", {}, true);
        await send(chatId, "Set rewards using: on|off REWARD_INR MINIMUM_DEPOSIT_INR.", keyboard([[button("Cancel", "cancel"), button("Admin Menu", "adm:home")]]));
      } else await showReferrals(chatId);
    } else if (section === "audit") await showAudit(chatId, Number(parts[2] ?? 0));
    else if (section === "analytics") await showAnalytics(chatId, Number(parts[2] ?? 30));
    else if (section === "reconcile") await showReconciliation(chatId, Number(parts[2] ?? 30));
    else if (section === "settings") await showSettings(chatId);
    else if (section === "maintenance") {
      if (parts[2] === "confirm" && ["enabled", "orders", "payments", "services"].includes(parts[3] ?? "")) {
        await send(chatId, `Change ${parts[3]} maintenance state? This affects customer access but does not modify financial or order data.`, keyboard([
          [button("Confirm Change", `adm:maintenance:apply:${parts[3]}`)],
          [button("Cancel", "adm:maintenance"), button("Admin Menu", "adm:home")],
        ]));
      } else if (parts[2] === "apply" && ["enabled", "orders", "payments", "services"].includes(parts[3] ?? "")) await changeMaintenance(chatId, userId, parts[3]);
      else await showMaintenance(chatId);
    } else if (section === "health") await showHealth(chatId);
    else {
      await send(chatId, "That admin action is no longer available.", keyboard([[button("Admin Menu", "adm:home")]]));
    }
  } catch (error) {
    const recordId = parts.find((part) => isUuid(part));
    await send(
      chatId,
      errorForUser(error, {
        area: "admin-callback",
        action: [section, parts[2]].filter(Boolean).join(":"),
        adminId: userId,
        recordId,
      }),
      keyboard([[button("Admin Menu", "adm:home"), button("Home", "home")]]),
    );
  }
  return true;
}

async function userDetails(chatId: string, userId: string) {
  const user = await one<{ id: string; name: string; username: string | null; created_at: Date; suspended: boolean; balance: string }>(
    pool,
    `SELECT u.id::text,u.name,u.username,u.created_at,u.suspended,coalesce(w.balance,0)::text AS balance
     FROM nx_users u LEFT JOIN nx_wallets w ON w.user_id=u.id WHERE u.id=$1`,
    [userId],
  );
  if (!user) {
    await send(chatId, "User not found.", keyboard([[button("Users", "adm:users:search")]]));
    return;
  }
  const counts = await one<{ orders: string; payments: string; tickets: string; referrals: string; redemptions: string }>(
    pool,
    `SELECT
       (SELECT count(*)::text FROM nx_orders WHERE user_id=$1) AS orders,
       (SELECT count(*)::text FROM nx_payments WHERE user_id=$1) AS payments,
       (SELECT count(*)::text FROM nx_tickets WHERE user_id=$1) AS tickets,
       (SELECT count(*)::text FROM nx_referrals WHERE referrer_id=$1) AS referrals,
       (SELECT count(*)::text FROM nx_redemptions WHERE user_id=$1) AS redemptions`,
    [userId],
  );
  const rows: InlineKeyboardButton[][] = [[button("Wallet Adjustment", `adm:wallet:user:${userId}`)], [button("Recent Ledger", `adm:ledger:${userId}`), button("User Orders", `adm:userorders:${userId}`)], [button("User Payments", `adm:userpayments:${userId}`)], [button("User Tickets", `adm:usertickets:${userId}`)], [button("Admin Users", "adm:users:search"), button("Admin Menu", "adm:home")]];
  await send(chatId, [
    `User: ${user.name}`,
    `Telegram ID: ${user.id}`,
    `Username: ${user.username ? `@${user.username}` : "not set"}`,
    `Joined: ${new Date(user.created_at).toISOString()}`,
    `Account: ${user.suspended ? "suspended" : "active"}`,
    `Wallet balance: ${rupees(user.balance)}`,
    `Orders: ${counts?.orders ?? "0"} · Payments: ${counts?.payments ?? "0"}`,
    `Tickets: ${counts?.tickets ?? "0"} · Referrals: ${counts?.referrals ?? "0"} · Redemptions: ${counts?.redemptions ?? "0"}`,
  ].join("\n"), keyboard(rows));
}

async function showUserRecords(chatId: string, userId: string, kind: "ledger" | "orders" | "payments" | "tickets") {
  const allowed = {
    ledger: "SELECT type,amount::text,description,created_at FROM nx_ledger WHERE user_id=$1 ORDER BY created_at DESC LIMIT 8",
    orders: "SELECT id,service_name,status,amount::text,created_at FROM nx_orders WHERE user_id=$1 ORDER BY created_at DESC LIMIT 8",
    payments: "SELECT id,status,amount::text,utr,created_at FROM nx_payments WHERE user_id=$1 ORDER BY created_at DESC LIMIT 8",
    tickets: "SELECT id,subject,status,created_at FROM nx_tickets WHERE user_id=$1 ORDER BY created_at DESC LIMIT 8",
  } as const;
  const rows = await pool.query(allowed[kind], [userId]);
  const formatted = rows.rows.map((row) => Object.entries(row).map(([key, value]) => `${key}: ${value instanceof Date ? value.toISOString() : value}`).join("\n"));
  await send(chatId, formatted.join("\n\n────────\n\n") || `No ${kind} records for this user.`, keyboard([[button("User Details", `adm:user:${userId}`), button("Admin Menu", "adm:home")]]));
}

async function showServices(chatId: string, page = 0) {
  const result = await pool.query(
    "SELECT id,name,category,supplier_paise::text,customer_paise::text,minimum,maximum,enabled FROM nx_services ORDER BY id LIMIT 8 OFFSET $1",
    [page * 8],
  );
  const rows = result.rows as Array<{ id: number; name: string; category: string; supplier_paise: string; customer_paise: string; minimum: number; maximum: number; enabled: boolean }>;
  const keyboardRows = rows.map((service) => [
    button(`${service.id} · ${service.enabled ? "ON" : "OFF"} · ${service.name.slice(0, 28)}`, `adm:service:detail:${service.id}`),
    button(service.enabled ? "Disable" : "Enable", `adm:service:toggle:${service.id}`),
  ]);
  if (rows.length === 8) keyboardRows.push([button("Next", `adm:services:${page + 1}`)]);
  keyboardRows.push([button("Admin Menu", "adm:home")]);
  const details = rows.map((service) =>
    `${service.id}. ${service.name}\n${service.category} · ${service.minimum}–${service.maximum} · supplier ${rupees(BigInt(service.supplier_paise) * 10000n)} / 1K · customer ${rupees(BigInt(service.customer_paise) * 10000n)} / 1K`,
  );
  await send(chatId, details.join("\n\n") || "No services found.", keyboard(keyboardRows));
}

async function serviceDetails(chatId: string, serviceId: number) {
  const service = await one<{ id: number; name: string; supplier_paise: string; customer_paise: string; enabled: boolean; minimum: number; maximum: number; description: string }>(
    pool, "SELECT id,name,supplier_paise::text,customer_paise::text,enabled,minimum,maximum,description FROM nx_services WHERE id=$1", [serviceId],
  );
  if (!service) {
    await send(chatId, "Service not found.", keyboard([[button("Services", "adm:services:0")]]));
    return;
  }
  await send(chatId, [
    `Service ${service.id}: ${service.name}`,
    `Enabled: ${service.enabled}`,
    `Supplier cost per 1,000: ${rupees(BigInt(service.supplier_paise) * 10000n)}`,
    `Customer price per 1,000: ${rupees(BigInt(service.customer_paise) * 10000n)}`,
    `Minimum: ${service.minimum} · Maximum: ${service.maximum}`,
    `Description: ${service.description}`,
  ].join("\n"), keyboard([
    [button("Change Supplier Cost", `adm:service:cost:${service.id}`), button(service.enabled ? "Disable" : "Enable", `adm:service:toggle:${service.id}`)],
    [button("Services", "adm:services:0"), button("Admin Menu", "adm:home")],
  ]));
}

async function toggleService(chatId: string, adminId: string, serviceId: number) {
  const result = await transaction(async (db) => {
    const service = await one<{ name: string; enabled: boolean }>(db, "SELECT name,enabled FROM nx_services WHERE id=$1 FOR UPDATE", [serviceId]);
    if (!service) return undefined;
    await db.query("UPDATE nx_services SET enabled=$2,updated_at=now() WHERE id=$1", [serviceId, !service.enabled]);
    await audit(db, adminId, "SERVICE_TOGGLED", String(serviceId), { enabled: !service.enabled });
    return { name: service.name, enabled: !service.enabled };
  });
  await send(chatId, result ? `${result.name} is now ${result.enabled ? "enabled" : "disabled"}.` : "Service not found.", keyboard([[button("Service Details", `adm:service:detail:${serviceId}`), button("Admin Menu", "adm:home")]]));
}

async function stageWalletAdjustment(ctx: MessageContext, body: string) {
  const match = body.match(/^(\d{1,20})\s+([+-])(\d{1,10}(?:\.\d{1,2})?)\s+(.{3,300})$/);
  if (!match) throw new DomainError("Use: <telegram_id> +<amount> <reason> or <telegram_id> -<amount> <reason>.");
  const targetId = match[1];
  const sign = match[2] === "-" ? -1n : 1n;
  const amount = money(match[3]) * sign;
  const reason = match[4].trim();
  const user = await one<{ id: string }>(pool, "SELECT id::text FROM nx_users WHERE id=$1", [targetId]);
  if (!user) throw new DomainError("User not found.");
  const operationId = randomUUID();
  await transaction(async (db) => {
    await db.query(
      "INSERT INTO nx_operations(key,actor_id,kind,data) VALUES($1,$2,'WALLET_ADJUSTMENT',$3::jsonb)",
      [operationId, String(ctx.user.id), JSON.stringify({ userId: targetId, amount: amount.toString(), reason })],
    );
    await audit(db, String(ctx.user.id), "WALLET_ADJUSTMENT_PROPOSED", targetId, { reason }, amount);
  });
  await resetSession(String(ctx.user.id), true);
  await send(ctx.chatId, `Confirm wallet adjustment\nUser: ${targetId}\nChange: ${rupees(amount)}\nReason: ${reason}\n\nThis cannot be undone.`, keyboard([
    [button("Confirm Adjustment", `adm:wallet:confirm:${operationId}`)],
    [button("Cancel", "cancel"), button("Admin Menu", "adm:home")],
  ]));
}

async function confirmWalletAdjustment(chatId: string, adminId: string, operationId: string) {
  const op = await one<{ data: { userId: string; amount: string; reason: string } }>(
    pool, "SELECT data FROM nx_operations WHERE key=$1 AND actor_id=$2 AND kind='WALLET_ADJUSTMENT'", [operationId, adminId],
  );
  if (!op) {
    await send(chatId, "Adjustment was not found.", keyboard([[button("Admin Menu", "adm:home")]]));
    return;
  }
  const result = await adjustWallet(op.data.userId, adminId, BigInt(op.data.amount), op.data.reason, operationId);
  await send(chatId, result.duplicate ? "This adjustment was already applied." : `Wallet adjustment completed.\nNew balance: ${rupees(result.balance)}`, keyboard([[button("User Details", `adm:user:${op.data.userId}`), button("Admin Menu", "adm:home")]]));
}

async function stageServiceCost(ctx: MessageContext, serviceId: number, rawAmount: string) {
  if (!Number.isSafeInteger(serviceId) || serviceId < 1) throw new DomainError("Service not found.");
  const amount = money(rawAmount);
  if (amount % 10000n !== 0n) throw new DomainError("Supplier cost must be in whole paise (up to two decimal places).");
  const supplierPaise = amount / 10000n;
  if (supplierPaise <= 0n || supplierPaise > 9223372036854775807n / 2n) throw new DomainError("Supplier cost is outside the supported range.");
  const service = await one<{ name: string; supplier_paise: string; customer_paise: string }>(pool, "SELECT name,supplier_paise::text,customer_paise::text FROM nx_services WHERE id=$1", [serviceId]);
  if (!service) throw new DomainError("Service not found.");
  const operationId = randomUUID();
  await transaction(async (db) => {
    await db.query(
      "INSERT INTO nx_operations(key,actor_id,kind,data) VALUES($1,$2,'SERVICE_COST',$3::jsonb)",
      [operationId, String(ctx.user.id), JSON.stringify({ serviceId, supplierPaise: supplierPaise.toString() })],
    );
    await audit(db, String(ctx.user.id), "SERVICE_COST_PROPOSED", String(serviceId), { oldSupplierPaise: service.supplier_paise, newSupplierPaise: supplierPaise.toString() });
  });
  await resetSession(String(ctx.user.id), true);
  await send(ctx.chatId, `Confirm catalogue price update\n${service.name}\nSupplier cost: ${rupees(BigInt(service.supplier_paise) * 10000n)} → ${rupees(amount)} per 1,000\nCustomer price will be set to exactly 2× supplier cost.`, keyboard([
    [button("Confirm Price Change", `adm:service:costconfirm:${operationId}`)],
    [button("Cancel", "cancel"), button("Admin Menu", "adm:home")],
  ]));
}

async function confirmServiceCost(chatId: string, adminId: string, operationId: string) {
  const result = await transaction(async (db) => {
    const operation = await one<{ confirmed_at: string | null; data: { serviceId: number; supplierPaise: string } }>(
      db, "SELECT confirmed_at,data FROM nx_operations WHERE key=$1 AND actor_id=$2 AND kind='SERVICE_COST' FOR UPDATE", [operationId, adminId],
    );
    if (!operation) return "missing";
    if (operation.confirmed_at) return "duplicate";
    const updated = await db.query(
      "UPDATE nx_services SET supplier_paise=$1,customer_paise=$2,updated_at=now() WHERE id=$3 RETURNING id",
      [operation.data.supplierPaise, (BigInt(operation.data.supplierPaise) * 2n).toString(), operation.data.serviceId],
    );
    if (!updated.rowCount) return "missing";
    await db.query("UPDATE nx_operations SET confirmed_at=now(),result='{}'::jsonb WHERE key=$1", [operationId]);
    await audit(db, adminId, "SERVICE_PRICE_CHANGED", String(operation.data.serviceId), { supplierPaise: operation.data.supplierPaise, multiplier: 2 });
    return "updated";
  });
  await send(chatId, result === "updated" ? "Service supplier and customer prices were updated." : result === "duplicate" ? "This price change was already applied." : "Price change not found.", keyboard([[button("Services", "adm:services:0"), button("Admin Menu", "adm:home")]]));
}

async function createRedeemCode(ctx: MessageContext, body: string) {
  const match = body.trim().match(/^([A-Z0-9-]{3,32})\s+(\d{1,10}(?:\.\d{1,2})?)\s+(\d{1,9})\s+(\d{1,4})$/i);
  if (!match) throw new DomainError("Use: CODE AMOUNT_INR MAX_REDEMPTIONS EXPIRY_DAYS (use 0 for no expiry).");
  const code = match[1].toUpperCase();
  const amount = money(match[2]);
  const max = Number(match[3]);
  const days = Number(match[4]);
  if (!Number.isSafeInteger(max) || max < 1 || max > 10000000 || !Number.isSafeInteger(days) || days > 3650) throw new DomainError("Use a redemption limit from 1–10,000,000 and expiry from 0–3,650 days.");
  await transaction(async (db) => {
    await db.query(
      `INSERT INTO nx_redeem_codes(code,amount,maximum_redemptions,expiry,created_by,description)
       VALUES($1,$2,$3,CASE WHEN $4=0 THEN NULL ELSE now()+($4::text||' days')::interval END,$5,'Admin-created redeem code')`,
      [code, amount.toString(), max, days, String(ctx.user.id)],
    );
    await audit(db, String(ctx.user.id), "REDEEM_CODE_CREATED", code, { maximumRedemptions: max, expiryDays: days }, amount);
  });
  await resetSession(String(ctx.user.id), true);
  await send(ctx.chatId, `Redeem code ${code} created.\nCredit: ${rupees(amount)}\nLimit: ${max}\nExpires: ${days ? `in ${days} days` : "never"}`, keyboard([[button("Redeem Codes", "adm:redeem"), button("Admin Menu", "adm:home")]]));
}

async function showRedeemCodes(chatId: string, page = 0, search?: string) {
  const result = await pool.query(
    `SELECT code,amount::text,current_redemptions,maximum_redemptions,expiry,enabled
     FROM nx_redeem_codes WHERE $1::text IS NULL OR code ILIKE $1
     ORDER BY created_at DESC LIMIT 8 OFFSET $2`,
    [search ? `%${search.slice(0, 32)}%` : null, page * 8],
  );
  const rows = result.rows as Array<{ code: string; amount: string; current_redemptions: number; maximum_redemptions: number; expiry: Date | null; enabled: boolean }>;
  const buttons = rows.map((code) => [button(`${code.code} · ${code.enabled ? "ON" : "OFF"}`, `adm:redeem:toggle:${code.code}`), button("History", `adm:redeem:history:${code.code}`)]);
  if (rows.length === 8) buttons.push([button("Next", search ? `adm:redeem:searchpage:${page + 1}` : `adm:redeem:page:${page + 1}`)]);
  if (search) buttons.push([button("Search Again", "adm:redeemsearch")]);
  buttons.push([button("Create Code", "adm:redeem:create"), button("Admin Menu", "adm:home")]);
  const messages = rows.map((code) => `${code.code}: ${rupees(code.amount)} · ${code.current_redemptions}/${code.maximum_redemptions}${code.expiry ? ` · expires ${new Date(code.expiry).toISOString()}` : ""}`);
  await send(chatId, messages.join("\n") || "No redeem codes.", keyboard(buttons));
}

async function toggleRedeemCode(chatId: string, adminId: string, code: string) {
  const result = await transaction(async (db) => {
    const row = await one<{ enabled: boolean }>(db, "SELECT enabled FROM nx_redeem_codes WHERE code=$1 FOR UPDATE", [code]);
    if (!row) return undefined;
    await db.query("UPDATE nx_redeem_codes SET enabled=$2 WHERE code=$1", [code, !row.enabled]);
    await audit(db, adminId, "REDEEM_CODE_TOGGLED", code, { enabled: !row.enabled });
    return !row.enabled;
  });
  await send(chatId, result === undefined ? "Code not found." : `${code} is now ${result ? "enabled" : "disabled"}.`, keyboard([[button("Redeem Codes", "adm:redeem"), button("Admin Menu", "adm:home")]]));
}

async function createCoupon(ctx: MessageContext, body: string) {
  const match = body.trim().match(/^([A-Z0-9-]{3,32})\s+(\d{1,2})\s+(\d{1,9})\s+(\d{1,4})$/i);
  if (!match) throw new DomainError("Use: CODE DISCOUNT_PERCENT MAX_USES EXPIRY_DAYS (use 0 for no expiry).");
  const code = match[1].toUpperCase();
  const percent = Number(match[2]);
  const maximum = Number(match[3]);
  const days = Number(match[4]);
  if (percent < 1 || percent > 100 || maximum < 1 || maximum > 10000000 || days > 3650) throw new DomainError("Percent must be 1–100, uses 1–10,000,000, expiry 0–3,650 days.");
  await transaction(async (db) => {
    await db.query(
      `INSERT INTO nx_coupons(code,percent,maximum_uses,expiry,created_by)
       VALUES($1,$2,$3,CASE WHEN $4=0 THEN NULL ELSE now()+($4::text||' days')::interval END,$5)`,
      [code, percent, maximum, days, String(ctx.user.id)],
    );
    await audit(db, String(ctx.user.id), "COUPON_CREATED", code, { percent, maximum, days });
  });
  await resetSession(String(ctx.user.id), true);
  await send(ctx.chatId, `Coupon ${code} created.\nDiscount: ${percent}%\nMaximum uses: ${maximum}\nExpiry: ${days ? `in ${days} days` : "never"}`, keyboard([[button("Coupons", "adm:coupons"), button("Admin Menu", "adm:home")]]));
}

async function showCoupons(chatId: string) {
  const rows = await pool.query(
    "SELECT code,percent,enabled,used,maximum_uses,expiry FROM nx_coupons ORDER BY created_at DESC LIMIT 20",
  );
  const coupons = rows.rows as Array<{ code: string; percent: number; enabled: boolean; used: number; maximum_uses: number; expiry: Date | null }>;
  const buttons = coupons.map((coupon) => [button(`${coupon.code} · ${coupon.enabled ? "ON" : "OFF"}`, `adm:coupon:toggle:${coupon.code}`)]);
  buttons.push([button("Create Coupon", "adm:coupon:create"), button("Admin Menu", "adm:home")]);
  await send(chatId, coupons.map((coupon) => `${coupon.code}: ${coupon.percent}% · ${coupon.used}/${coupon.maximum_uses}${coupon.expiry ? ` · expires ${new Date(coupon.expiry).toISOString()}` : ""}`).join("\n") || "No coupons.", keyboard(buttons));
}

async function toggleCoupon(chatId: string, adminId: string, code: string) {
  const result = await transaction(async (db) => {
    const row = await one<{ enabled: boolean }>(db, "SELECT enabled FROM nx_coupons WHERE code=$1 FOR UPDATE", [code]);
    if (!row) return undefined;
    await db.query("UPDATE nx_coupons SET enabled=$2 WHERE code=$1", [code, !row.enabled]);
    await audit(db, adminId, "COUPON_TOGGLED", code, { enabled: !row.enabled });
    return !row.enabled;
  });
  await send(chatId, result === undefined ? "Coupon not found." : `${code} is now ${result ? "enabled" : "disabled"}.`, keyboard([[button("Coupons", "adm:coupons"), button("Admin Menu", "adm:home")]]));
}

async function showSupportTickets(chatId: string, status = "ALL", page = 0) {
  const valid = ["ALL", "OPEN", "IN_PROGRESS", "WAITING", "RESOLVED", "CLOSED"];
  if (!valid.includes(status)) status = "ALL";
  page = Math.max(0, Math.min(Number.isSafeInteger(page) ? page : 0, 10000));
  const count = await one<{ total: string }>(pool, "SELECT count(*)::text AS total FROM nx_tickets WHERE $1='ALL' OR status=$1", [status]);
  const pages = Math.max(1, Math.ceil(Number(count?.total ?? 0) / 8));
  page = Math.min(page, pages - 1);
  const result = await pool.query(
    `SELECT t.id,t.subject,t.status,t.updated_at,u.name,u.id::text AS user_id
     FROM nx_tickets t LEFT JOIN nx_users u ON u.id=t.user_id
     WHERE $1='ALL' OR t.status=$1 ORDER BY t.updated_at DESC LIMIT 8 OFFSET $2`,
    [status, page * 8],
  );
  const tickets = result.rows as Array<{ id: string; subject: string; status: string; updated_at: Date; name: string | null; user_id: string }>;
  const buttons = tickets.map((ticket) => [button(`${ticket.status} · ${ticket.subject.slice(0, 28)}`, `adm:support:detail:${ticket.id}`)]);
  buttons.unshift([button("All", "adm:support:ALL:0"), button("Open", "adm:support:OPEN:0"), button("In Progress", "adm:support:IN_PROGRESS:0")]);
  buttons.splice(1, 0, [button("Waiting", "adm:support:WAITING:0"), button("Resolved", "adm:support:RESOLVED:0"), button("Closed", "adm:support:CLOSED:0")]);
  const paging = [
    ...(page > 0 ? [button("Previous", `adm:support:${status}:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `adm:support:${status}:${page + 1}`)] : []),
  ];
  if (paging.length) buttons.push(paging);
  buttons.push([button("Admin Menu", "adm:home")]);
  const lines = tickets.map((ticket) => `${ticket.subject}\n${ticket.status} · ${ticket.name ?? "Unknown customer"} · ${ticket.user_id}\n${ticket.id}`).join("\n\n────────\n\n");
  const statusLabel = status === "ALL" ? "All" : status.replace("_", " ");
  await send(chatId, telegramSafeText(`${statusLabel} support tickets · Page ${page + 1} of ${pages}\n\n${lines || `No ${statusLabel.toLowerCase()} tickets found.`}`), keyboard(buttons));
}

async function showAdminTicket(chatId: string, ticketId: string) {
  const ticket = await one<{ id: string; user_id: string; subject: string; status: string; assigned_to: string | null }>(
    pool, "SELECT id,user_id::text,subject,status,assigned_to::text FROM nx_tickets WHERE id=$1", [ticketId],
  );
  if (!ticket) {
    await send(chatId, "Ticket not found.", keyboard([[button("Support", "adm:support")]]));
    return;
  }
  const messages = await pool.query("SELECT sender_id::text,body,is_admin,created_at FROM nx_ticket_messages WHERE ticket_id=$1 ORDER BY created_at DESC LIMIT 5", [ticketId]);
  const lines = (messages.rows as Array<{ sender_id: string; body: string; is_admin: boolean; created_at: Date }>).reverse().map((row) => {
    const body = row.body.length > 600 ? `${row.body.slice(0, 600)}…` : row.body;
    return `${row.is_admin ? "Admin" : "User"} (${row.sender_id}) · ${new Date(row.created_at).toISOString()}\n${body}`;
  });
  await send(chatId, telegramSafeText(`Ticket ${ticket.id}\nUser: ${ticket.user_id}\nSubject: ${ticket.subject}\nStatus: ${ticket.status}\nAssigned to: ${ticket.assigned_to ?? "unassigned"}\n\n${lines.join("\n\n") || "No messages yet."}`), keyboard([
    [button("Reply", `adm:support:reply:${ticket.id}`), button("Assign to Me", `adm:support:assign:${ticket.id}`)],
    [button("In Progress", `adm:ss:${ticket.id}:IN_PROGRESS`), button("Resolve", `adm:ss:${ticket.id}:RESOLVED`)],
    [button("Close", `adm:ss:${ticket.id}:CLOSED`), button("Reopen", `adm:ss:${ticket.id}:OPEN`)],
    [button("Tickets", "adm:support"), button("Admin Menu", "adm:home")],
  ]));
}

async function addAdminTicketReply(ctx: MessageContext, ticketId: string, body: string) {
  const messageId = randomUUID();
  const userId = await transaction(async (db) => {
    const ticket = await one<{ user_id: string; status: string }>(db, "SELECT user_id::text,status FROM nx_tickets WHERE id=$1 FOR UPDATE", [ticketId]);
    if (!ticket || ticket.status === "CLOSED") throw new DomainError("Ticket is closed or unavailable.");
    await db.query("INSERT INTO nx_ticket_messages(id,ticket_id,sender_id,body,is_admin) VALUES($1,$2,$3,$4,true)", [messageId, ticketId, String(ctx.user.id), body.slice(0, 1500)]);
    await db.query("UPDATE nx_tickets SET status='WAITING',updated_at=now() WHERE id=$1", [ticketId]);
    await audit(db, String(ctx.user.id), "TICKET_ADMIN_REPLIED", ticketId, {});
    await db.query(
      "INSERT INTO nx_notifications(id,user_id,kind,body,dedupe_key) VALUES($1,$2,'SUPPORT_REPLY',$3,$4) ON CONFLICT(dedupe_key) DO NOTHING",
      [randomUUID(), ticket.user_id, `Support replied to ticket ${ticketId}: ${body.slice(0, 500)}`, `support-reply:${messageId}`],
    );
    return ticket.user_id;
  });
  await pool.query(
    "INSERT INTO nx_outbox(id,method,params,dedupe_key) VALUES($1,'sendMessage',$2::jsonb,$3) ON CONFLICT(dedupe_key) DO NOTHING",
    [randomUUID(), JSON.stringify({ chat_id: userId, text: `Support replied to ticket ${ticketId}:\n${body.slice(0, 900)}` }), `ticket-reply:${messageId}`],
  );
  await resetSession(String(ctx.user.id), true);
  await send(ctx.chatId, "Reply sent to the customer.", keyboard([[button("View Ticket", `adm:support:detail:${ticketId}`), button("Admin Menu", "adm:home")]]));
}

async function createAnnouncement(ctx: MessageContext, raw: string) {
  const match = raw.trim().match(/^(all|user\s+\d{1,20})\s+([\s\S]{5,1500})$/i);
  if (!match) throw new DomainError("Use: all <message> or user <telegram_id> <message>.");
  const target = match[1].toLowerCase() === "all" ? "all" : match[1].split(/\s+/)[1];
  const body = match[2].trim();
  const id = randomUUID();
  const result = await transaction(async (db) => {
    if (target !== "all") {
      const user = await one<{ id: string }>(db, "SELECT id::text FROM nx_users WHERE id=$1", [target]);
      if (!user) throw new DomainError("Target user not found.");
    }
    const audience = target === "all" ? { all: true } : { userId: target };
    await db.query("INSERT INTO nx_announcements(id,body,audience,created_by) VALUES($1,$2,$3::jsonb,$4)", [id, body, JSON.stringify(audience), String(ctx.user.id)]);
    const sent = await db.query(
      `INSERT INTO nx_outbox(id,method,params,dedupe_key)
       SELECT gen_random_uuid(),'sendMessage',jsonb_build_object('chat_id',u.id::text,'text',$2),$1||':'||u.id::text
       FROM nx_users u WHERE ($3::boolean OR u.id=$4)
       ON CONFLICT(dedupe_key) DO NOTHING`,
      [`announcement:${id}`, body, target === "all", target === "all" ? null : target],
    );
    await db.query(
      `INSERT INTO nx_notifications(id,user_id,kind,body,dedupe_key)
       SELECT gen_random_uuid(),u.id,'ANNOUNCEMENT',$2,'announcement:'||$1||':'||u.id::text
       FROM nx_users u WHERE ($3::boolean OR u.id=$4)
       ON CONFLICT(dedupe_key) DO NOTHING`,
      [id, body, target === "all", target === "all" ? null : target],
    );
    await db.query("UPDATE nx_announcements SET sent_at=now() WHERE id=$1", [id]);
    await audit(db, String(ctx.user.id), "ANNOUNCEMENT_QUEUED", id, { audience, queued: sent.rowCount ?? 0 });
    return sent.rowCount ?? 0;
  });
  await resetSession(String(ctx.user.id), true);
  await send(ctx.chatId, `Announcement ${id} queued for ${result} recipient(s). Delivery will continue through the outbox.`, keyboard([[button("Notifications", "adm:notifications"), button("Admin Menu", "adm:home")]]));
}

async function showNotifications(chatId: string) {
  const [outbox, recent] = await Promise.all([
    one<{ pending: string; failed: string; sent: string }>(
      pool,
      `SELECT count(*) FILTER(WHERE status IN('PENDING','SENDING'))::text AS pending,
       count(*) FILTER(WHERE status='FAILED')::text AS failed,count(*) FILTER(WHERE status='SENT')::text AS sent FROM nx_outbox`,
    ),
    pool.query("SELECT action,target,created_at FROM nx_audit ORDER BY created_at DESC LIMIT 8"),
  ]);
  const rows = (recent.rows as Array<{ action: string; target: string; created_at: Date }>).map((row) => `${row.action} · ${row.target} · ${new Date(row.created_at).toISOString()}`);
  await send(chatId, `Outbox: ${outbox?.pending ?? "0"} queued · ${outbox?.failed ?? "0"} failed · ${outbox?.sent ?? "0"} sent\n\nRecent events:\n${rows.join("\n") || "No audit events."}`, keyboard([
    ...(Number(outbox?.failed ?? 0) > 0 ? [[button("Review Failed Messages", "adm:outbox:failed:0")]] : []),
    [button("Admin Menu", "adm:home")],
  ]));
}

async function showFailedOutbox(chatId: string, page = 0) {
  const result = await pool.query(
    "SELECT id,method,status,attempts,last_error_code,created_at FROM nx_outbox WHERE status='FAILED' ORDER BY created_at DESC LIMIT 8 OFFSET $1",
    [page * 8],
  );
  const messages = result.rows as Array<{ id: string; method: string; attempts: number; last_error_code: string | null; created_at: Date }>;
  const buttons = messages.map((row) => [button(`Retry ${row.id.slice(0, 8)} · ${row.last_error_code ?? "error"}`, `adm:outbox:retry:${row.id}`)]);
  if (messages.length === 8) buttons.push([button("Next", `adm:outbox:failed:${page + 1}`)]);
  buttons.push([button("Notifications", "adm:notifications"), button("Admin Menu", "adm:home")]);
  await send(chatId, messages.map((row) => `${row.id} · ${row.method} · attempts ${row.attempts} · ${row.last_error_code ?? "error"}`).join("\n") || "No failed messages.", keyboard(buttons));
}

async function retryOutbox(chatId: string, adminId: string, messageId: string) {
  const result = await transaction(async (db) => {
    const row = await one<{ status: string }>(db, "SELECT status FROM nx_outbox WHERE id=$1 FOR UPDATE", [messageId]);
    if (!row) return "missing";
    if (row.status !== "FAILED") return "not_failed";
    await db.query("UPDATE nx_outbox SET status='PENDING',attempts=0,available_at=now(),lease_until=NULL,last_error_code=NULL WHERE id=$1", [messageId]);
    await audit(db, adminId, "OUTBOX_RETRY", messageId, {});
    return "queued";
  });
  await send(chatId, result === "queued" ? "Message queued for retry." : result === "missing" ? "Message not found." : "Only failed messages can be retried.", keyboard([[button("Notifications", "adm:notifications"), button("Admin Menu", "adm:home")]]));
}

async function showReferrals(chatId: string) {
  const totals = await one<{ referrals: string; pending: string; rewarded: string; credited: string }>(
    pool,
    `SELECT count(*)::text AS referrals,count(*) FILTER(WHERE reward_status='PENDING')::text AS pending,
       count(*) FILTER(WHERE reward_status='REWARDED')::text AS rewarded,coalesce(sum(amount),0)::text AS credited FROM nx_referrals`,
  );
  const rows = await pool.query(
    `SELECT r.referrer_id::text,r.referred_id::text,r.reward_status,r.amount::text,r.created_at
     FROM nx_referrals r ORDER BY r.created_at DESC LIMIT 12`,
  );
  const entries = (rows.rows as Array<{ referrer_id: string; referred_id: string; reward_status: string; amount: string; created_at: Date }>).map((row) =>
    `${row.referrer_id} → ${row.referred_id} · ${row.reward_status} · ${rupees(row.amount)}`,
  );
  const cfg = await one<{ value: { enabled?: boolean; reward?: string; minimum_deposit?: string } }>(pool, "SELECT value FROM nx_settings WHERE key='referral'");
  await send(chatId, [
    `Referral system: ${cfg?.value?.enabled ? "enabled" : "paused"}`,
    `Reward: ${rupees(cfg?.value?.reward ?? "0")} · minimum qualifying deposit: ${rupees(cfg?.value?.minimum_deposit ?? "0")}`,
    `Referrals: ${totals?.referrals ?? "0"} · Pending: ${totals?.pending ?? "0"} · Rewarded: ${totals?.rewarded ?? "0"}`,
    `Total credit: ${rupees(totals?.credited ?? "0")}`,
    "",
    entries.join("\n") || "No referrals yet.",
  ].join("\n"), keyboard([
    [button("Configure Rewards", "adm:referrals:configure")],
    [button("Admin Menu", "adm:home")],
  ]));
}

async function setReferralConfig(ctx: MessageContext, raw: string) {
  const match = raw.trim().match(/^(on|off)\s+(\d{1,10}(?:\.\d{1,2})?)\s+(\d{1,10}(?:\.\d{1,2})?)$/i);
  if (!match) throw new DomainError("Use: on|off REWARD_INR MINIMUM_DEPOSIT_INR.");
  const value = {
    enabled: match[1].toLowerCase() === "on",
    reward: money(match[2]).toString(),
    minimum_deposit: money(match[3]).toString(),
  };
  await transaction(async (db) => {
    await db.query("INSERT INTO nx_settings(key,value) VALUES('referral',$1::jsonb) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()", [JSON.stringify(value)]);
    await audit(db, String(ctx.user.id), "REFERRAL_CONFIG_UPDATED", "referral", { enabled: value.enabled, reward: value.reward, minimumDeposit: value.minimum_deposit });
  });
  await resetSession(String(ctx.user.id), true);
  await send(ctx.chatId, `Referral rewards ${value.enabled ? "enabled" : "paused"}.\nReward: ${rupees(value.reward)}\nMinimum qualifying deposit: ${rupees(value.minimum_deposit)}`, keyboard([[button("Referrals", "adm:referrals"), button("Admin Menu", "adm:home")]]));
}

async function showAudit(chatId: string, page = 0) {
  const result = await pool.query(
    `SELECT id,actor_id::text,action,target,amount::text,details,created_at FROM nx_audit
     ORDER BY created_at DESC LIMIT 10 OFFSET $1`,
    [page * 10],
  );
  const lines = result.rows.map((row) => `${new Date(row.created_at as Date).toISOString()} · ${row.action}\nActor: ${row.actor_id ?? "system"} · Target: ${row.target}${row.amount ? ` · Amount: ${rupees(String(row.amount))}` : ""}\n${JSON.stringify(row.details)}`);
  await send(chatId, lines.join("\n\n") || "No audit events.", keyboard([
    ...(result.rows.length === 10 ? [[button("Next", `adm:audit:${page + 1}`)]] : []),
    [button("Admin Menu", "adm:home")],
  ]));
}

async function showAnalytics(chatId: string, days = 30) {
  const period = Math.max(1, Math.min(365, Number.isSafeInteger(days) ? days : 30));
  const row = await one<{ users: string; new_users: string; orders: string; order_volume: string; deposits: string; deposits_approved: string; pending_payments: string; refunds: string; open_tickets: string }>(
    pool,
    `SELECT
       (SELECT count(*)::text FROM nx_users) AS users,
       (SELECT count(*)::text FROM nx_users WHERE created_at>=now()-($1::text||' days')::interval) AS new_users,
       (SELECT count(*)::text FROM nx_orders WHERE created_at>=now()-($1::text||' days')::interval) AS orders,
       (SELECT coalesce(sum(amount),0)::text FROM nx_orders WHERE created_at>=now()-($1::text||' days')::interval) AS order_volume,
       (SELECT count(*)::text FROM nx_payments WHERE created_at>=now()-($1::text||' days')::interval) AS deposits,
       (SELECT coalesce(sum(amount),0)::text FROM nx_payments WHERE status='APPROVED' AND created_at>=now()-($1::text||' days')::interval) AS deposits_approved,
       (SELECT count(*)::text FROM nx_payments WHERE status='PENDING') AS pending_payments,
       (SELECT coalesce(sum(amount),0)::text FROM nx_refunds WHERE created_at>=now()-($1::text||' days')::interval) AS refunds,
       (SELECT count(*)::text FROM nx_tickets WHERE status IN('OPEN','IN_PROGRESS','WAITING')) AS open_tickets`,
    [period],
  );
  await send(chatId, [
    `Analytics · last ${period} days`,
    `Users total: ${row?.users ?? "0"} · New: ${row?.new_users ?? "0"}`,
    `Orders: ${row?.orders ?? "0"} · Gross order volume: ${rupees(row?.order_volume ?? "0")}`,
    `Deposit requests: ${row?.deposits ?? "0"} · Approved deposits: ${rupees(row?.deposits_approved ?? "0")}`,
    `Pending payments: ${row?.pending_payments ?? "0"} · Refunds: ${rupees(row?.refunds ?? "0")}`,
    `Open support tickets: ${row?.open_tickets ?? "0"}`,
    "",
    "Values use persisted wallet units (micro-rupees); no supplier-cost or profit totals are inferred.",
  ].join("\n"), keyboard([
    [button("7 days", "adm:analytics:7"), button("30 days", "adm:analytics:30"), button("90 days", "adm:analytics:90")],
    [button("Audit Logs", "adm:audit"), button("Admin Menu", "adm:home")],
  ]));
}

async function showSettings(chatId: string) {
  const [maintenance, referral] = await Promise.all([
    one<{ value: Record<string, unknown> }>(pool, "SELECT value FROM nx_settings WHERE key='maintenance'"),
    one<{ value: { enabled?: boolean; reward?: string; minimum_deposit?: string } }>(pool, "SELECT value FROM nx_settings WHERE key='referral'"),
  ]);
  const m = maintenance?.value ?? {};
  const r = referral?.value;
  await send(chatId, [
    `Global maintenance: ${m.enabled === true ? "ON" : "OFF"}`,
    `Order pause: ${m.orders === true ? "ON" : "OFF"}`,
    `Payment pause: ${m.payments === true ? "ON" : "OFF"}`,
    `Service browsing pause: ${m.services === true ? "ON" : "OFF"}`,
    `Referral rewards: ${r?.enabled ? "ON" : "OFF"}`,
    `Referral reward: ${rupees(r?.reward ?? "0")} · min deposit: ${rupees(r?.minimum_deposit ?? "0")}`,
    `UPI ID: ${config.upi}`,
    `Support: ${config.support}`,
  ].join("\n"), keyboard([
    [button("Referral Settings", "adm:referrals")],
    [button("Maintenance Controls", "adm:maintenance"), button("Admin Menu", "adm:home")],
  ]));
}

async function showMaintenance(chatId: string) {
  const setting = await one<{ value: Record<string, unknown> }>(pool, "SELECT value FROM nx_settings WHERE key='maintenance'");
  const value = setting?.value ?? {};
  const states = ["enabled", "orders", "payments", "services"];
  const rows = states.map((key) => [button(`${key}: ${value[key] === true ? "ON" : "OFF"}`, `adm:maintenance:confirm:${key}`)]);
  rows.push([button("Settings", "adm:settings"), button("Admin Menu", "adm:home")]);
  await send(chatId, "Each maintenance change requires a second confirmation. Global maintenance pauses customer operations without changing wallet or order data.", keyboard(rows));
}

async function changeMaintenance(chatId: string, adminId: string, key: string) {
  if (!["enabled", "orders", "payments", "services"].includes(key)) {
    await send(chatId, "Unknown maintenance setting.", keyboard([[button("Maintenance", "adm:maintenance")]]));
    return;
  }
  const newValue = await transaction(async (db) => {
    const row = await one<{ value: Record<string, unknown> }>(db, "SELECT value FROM nx_settings WHERE key='maintenance' FOR UPDATE");
    const value = { ...(row?.value ?? {}), [key]: row?.value?.[key] !== true };
    await db.query("INSERT INTO nx_settings(key,value) VALUES('maintenance',$1::jsonb) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()", [JSON.stringify(value)]);
    await audit(db, adminId, "MAINTENANCE_CHANGED", key, { enabled: value[key] });
    return value[key];
  });
  await send(chatId, `${key} maintenance is now ${newValue ? "ON" : "OFF"}.`, keyboard([[button("Maintenance", "adm:maintenance"), button("Admin Menu", "adm:home")]]));
}

async function showHealth(chatId: string) {
  const db = await pool.query("SELECT now() AS database_time");
  const counts = await one<{ users: string; orders: string; pending: string; failed: string; sending: string }>(
    pool,
    `SELECT (SELECT count(*)::text FROM nx_users) AS users,
      (SELECT count(*)::text FROM nx_orders) AS orders,
      (SELECT count(*)::text FROM nx_outbox WHERE status='PENDING') AS pending,
      (SELECT count(*)::text FROM nx_outbox WHERE status='FAILED') AS failed,
      (SELECT count(*)::text FROM nx_outbox WHERE status='SENDING') AS sending`,
  );
  await send(chatId, [
    `Database: ${db.rows.length ? "reachable" : "no result"}`,
    `Database clock: ${new Date(db.rows[0]?.database_time as Date).toISOString()}`,
    `Bot token configured: ${config.token ? "yes" : "no"}`,
    `Admin password configured: ${config.adminPassword ? "yes" : "no"}`,
    `Configured owner IDs: ${config.adminIds.length}`,
    `Users: ${counts?.users ?? "0"} · Orders: ${counts?.orders ?? "0"}`,
    `Outbox pending: ${counts?.pending ?? "0"} · Sending: ${counts?.sending ?? "0"} · Failed: ${counts?.failed ?? "0"}`,
  ].join("\n"), keyboard([[button("Notifications", "adm:notifications"), button("Admin Menu", "adm:home")]]));
}

function customerOrderStatusMessage(order: {
  id: string;
  service_id: number;
  service_name: string;
  quantity: number;
  amount: string;
}, status: string) {
  const heading: Record<string, string> = {
    PROCESSING: "⚙️ ORDER PROCESSING",
    COMPLETED: "✅ ORDER COMPLETED",
    FAILED: "⚠️ ORDER FAILED",
    CANCELLED: "❌ ORDER CANCELLED",
    REJECTED: "❌ ORDER REJECTED",
  };
  const lines = [
    heading[status] ?? `ORDER ${status}`,
    "",
    status === "COMPLETED"
      ? "Your order has been successfully completed."
      : status === "PROCESSING"
        ? "Your order is now being processed. Please wait while it is fulfilled."
        : status === "FAILED"
          ? "Unfortunately, your order could not be completed. If a refund is issued, it will appear in your wallet transactions."
          : status === "CANCELLED"
            ? "Your order has been cancelled. Any refund will be shown in your wallet transactions."
            : "Your order has been rejected. Check your wallet transactions for any refund.",
    "",
    `Order ID: ${order.id}`,
    `Service: ${order.service_name}`,
    `Service ID: ${order.service_id}`,
    `Quantity: ${order.quantity}`,
    `Amount: ${rupees(order.amount)}`,
    `Status: ${status}`,
    ...(status === "COMPLETED" ? ["", "Thank you for choosing NEXVERSE SMM!"] : []),
  ];
  return telegramSafeText(lines.join("\n"));
}

async function confirmOrderStatus(chatId: string, adminId: string, orderId: string, status: string) {
  const allowed = ["PROCESSING", "COMPLETED", "FAILED", "CANCELLED", "REJECTED"];
  if (!allowed.includes(status)) {
    await send(chatId, "Unsupported order status.", keyboard([[button("Admin Orders", "adm:orders:0")]]));
    return;
  }
  const result = await transaction(async (db) => {
    const order = await one<{
      user_id: string;
      status: string;
      id: string;
      service_id: number;
      service_name: string;
      quantity: number;
      amount: string;
    }>(
      db,
      "SELECT user_id::text,status,id,service_id,service_name,quantity,amount::text FROM nx_orders WHERE id=$1 FOR UPDATE",
      [orderId],
    );
    if (!order) return "missing";
    const permitted =
      (order.status === "PENDING" && ["PROCESSING", "COMPLETED", "FAILED", "CANCELLED", "REJECTED"].includes(status)) ||
      (order.status === "PROCESSING" && ["COMPLETED", "FAILED", "CANCELLED", "REJECTED"].includes(status));
    if (!permitted) return "invalid";
    await db.query("UPDATE nx_orders SET status=$2,updated_at=now() WHERE id=$1", [orderId, status]);
    await audit(db, adminId, "ORDER_STATUS_CHANGED", orderId, { from: order.status, to: status });
    const message = customerOrderStatusMessage(order, status);
    await db.query(
      "INSERT INTO nx_notifications(id,user_id,kind,body,dedupe_key) VALUES($1,$2,'ORDER_STATUS',$3,$4) ON CONFLICT(dedupe_key) DO NOTHING",
      [randomUUID(), order.user_id, message, `order-status:${orderId}:${status}`],
    );
    await db.query(
      "INSERT INTO nx_outbox(id,method,params,dedupe_key) VALUES($1,'sendMessage',$2::jsonb,$3) ON CONFLICT(dedupe_key) DO NOTHING",
      [
        randomUUID(),
        JSON.stringify({
          chat_id: order.user_id,
          text: message,
          reply_markup: keyboard([[button("View Order", `orderdetail:${order.id}`), button("Home", "home")]]),
        }),
        `order-status:${orderId}:${status}`,
      ],
    );
    return "updated";
  });
  await send(chatId, result === "updated" ? `Order status set to ${status}. No refund was made.` : result === "missing" ? "Order not found." : "This order is no longer in a status that can take that action.", keyboard([[button("Order Details", `adm:orders:detail:${orderId}`), button("Admin Menu", "adm:home")]]));
}