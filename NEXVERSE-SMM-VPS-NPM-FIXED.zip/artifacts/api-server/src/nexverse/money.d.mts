export class DomainError extends Error {
  code: string;
  constructor(message: string, code?: string);
}
export function assert(condition: unknown, message: string, code?: string): asserts condition;
export function money(input: string): bigint;
export function rupees(units: bigint | number | string): string;
export function quantity(input: string | number, service: { minimum: number; maximum: number }): number;
export function price(service: { customer_paise: bigint | number | string }, quantity: number): bigint;
export function targetUrl(input: string): string;
export function text(input: string, max?: number): string;
export function escapeHtml(input: unknown): string;