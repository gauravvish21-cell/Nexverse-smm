// Server-only configuration. Never serialize this object or import it into a browser bundle.
// Store BOT_TOKEN and ADMIN_PASSWORD in Replit Secrets. Add owner Telegram IDs below.
export const config = Object.freeze({
  brand: "NEXVERSE SMM",
  support: "@fragmentauctioneer",
  upi: process.env.UPI_ID?.trim() ?? "",
  token: process.env.BOT_TOKEN?.trim() ?? "",
  adminPassword: process.env.ADMIN_PASSWORD ?? "",
  adminIds: Object.freeze([...new Set((process.env.ADMIN_TELEGRAM_IDS || "").split(",").map((value) => value.trim()).filter((value) => /^\d{1,20}$/.test(value)))]),
  botEnabled: process.env.BOT_ENABLED === "true",
  deliveryEnabled: process.env.BOT_DELIVERY_ENABLED === "true",
});

export function missingRequiredBotConfiguration(settings = config) {
  const missing = [];
  if (!settings.token) missing.push("BOT_TOKEN");
  if (!settings.adminPassword) missing.push("ADMIN_PASSWORD");
  return missing;
}