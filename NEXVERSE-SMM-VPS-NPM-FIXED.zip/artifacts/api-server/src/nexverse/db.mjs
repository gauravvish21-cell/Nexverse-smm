import pg from "pg";
import { DomainError } from "./money.mjs";
export function createPool(connectionString = process.env.DATABASE_URL, options = {}) {
  if (!connectionString) throw new Error("Persistent database configuration is missing.");
  return new pg.Pool({ connectionString, max: 12, connectionTimeoutMillis: 10000, ...options });
}
export async function transaction(pool, fn) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SET LOCAL lock_timeout = '10s'");
    await client.query("SET LOCAL statement_timeout = '30s'");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    if (err.code === "23505") throw new DomainError("This request or reference has already been used.", "DUPLICATE");
    throw err;
  } finally { client.release(); }
}
export async function one(db, sql, values = []) {
  return (await db.query(sql, values)).rows[0];
}