// Telegram Bot API callback_data is limited to 64 UTF-8 bytes.
export function assertCallbackData(value) {
  if (typeof value !== "string" || !value) throw new Error("Telegram callback data must be a non-empty string.");
  const bytes = Buffer.byteLength(value, "utf8");
  if (bytes > 64) throw new Error(`Telegram callback data exceeds 64 bytes (${bytes}).`);
  return value;
}
