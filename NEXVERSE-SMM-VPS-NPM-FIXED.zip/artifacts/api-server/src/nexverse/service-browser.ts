import { isMaintenanceEnabled, one, pool } from "./database";
import { rupees } from "./money.mjs";
import { button, getSession, keyboard, nav, send, setSession, type CallbackContext } from "./bot-utils";

const PAGE_SIZE = 8;
const PLATFORM_ORDER = ["Telegram", "Instagram", "YouTube", "WhatsApp", "Facebook", "Twitter", "Google Reviews"];
const PLATFORM_LABEL: Record<string, string> = { Twitter: "Twitter / X" };

const SERVICE_TYPES = [
  { id: "members", label: "Followers / Members" },
  { id: "views", label: "Views" },
  { id: "likes", label: "Likes" },
  { id: "reactions", label: "Reactions" },
  { id: "comments", label: "Comments" },
  { id: "shares", label: "Shares / Reposts" },
  { id: "saves", label: "Saves" },
  { id: "poll-votes", label: "Poll Votes" },
  { id: "watchtime", label: "Watch Time" },
  { id: "reviews", label: "Reviews" },
  { id: "bot-starts", label: "Bot Starts" },
  { id: "bundles", label: "Bundles" },
  { id: "other", label: "Other Services" },
] as const;

type ServiceTypeId = (typeof SERVICE_TYPES)[number]["id"];
type ServiceRow = {
  id: number;
  name: string;
  category: string;
  platform: string;
  customer_paise: string;
  minimum: number;
  maximum: number;
  description?: string;
  enabled?: boolean;
};

function safePage(value: number) {
  return Number.isSafeInteger(value) ? Math.max(0, Math.min(value, 10000)) : 0;
}

function displayPlatform(platform: string) {
  return PLATFORM_LABEL[platform] ?? platform;
}

function displayType(type: ServiceTypeId, platform: string) {
  if (type === "members") {
    if (platform === "YouTube") return "Subscribers";
    if (platform === "Instagram" || platform === "Facebook" || platform === "Twitter") return "Followers";
    if (platform === "WhatsApp") return "Channel Members";
    if (platform === "Telegram") return "Members";
  }
  return SERVICE_TYPES.find((item) => item.id === type)?.label ?? "Other Services";
}

function classifyService(service: Pick<ServiceRow, "name" | "category">): ServiceTypeId {
  const text = `${service.name} ${service.category}`.toLowerCase();
  if (/\bpoll\b|\bvot(?:e|es|ing)\b/.test(text)) return "poll-votes";
  if (/\bbot\s*start/.test(text)) return "bot-starts";
  if (/\breviews?\b/.test(text)) return "reviews";
  if (/\bwatch[\s-]*time\b/.test(text)) return "watchtime";
  if (/\bbundles?\b/.test(text)) return "bundles";
  if (/\bcomments?\b/.test(text)) return "comments";
  if (/\breactions?\b/.test(text)) return "reactions";
  if (/\blikes?\b/.test(text)) return "likes";
  if (/\bshares?\b|\breposts?\b/.test(text)) return "shares";
  if (/\bsaves?\b/.test(text)) return "saves";
  if (/\bviews?\b/.test(text)) return "views";
  if (/\bfollowers?\b|\bmembers?\b|\bsubscribers?\b/.test(text)) return "members";
  return "other";
}

async function platformRows() {
  const result = await pool.query(
    "SELECT platform,count(*)::int AS total FROM nx_services WHERE enabled=true GROUP BY platform",
  );
  const rows = result.rows as Array<{ platform: string; total: number }>;
  return rows.sort((left, right) => {
    const leftRank = PLATFORM_ORDER.indexOf(left.platform);
    const rightRank = PLATFORM_ORDER.indexOf(right.platform);
    if (leftRank !== -1 || rightRank !== -1) {
      return (leftRank === -1 ? Number.MAX_SAFE_INTEGER : leftRank) -
        (rightRank === -1 ? Number.MAX_SAFE_INTEGER : rightRank);
    }
    return left.platform.localeCompare(right.platform);
  });
}

export async function customerPlatformRows() {
  const platforms = await platformRows();
  const buttons = platforms.map((item, index) =>
    button(`${displayPlatform(item.platform)} · ${item.total}`, `platform:${index}`),
  );
  const rows = buttons.reduce<Array<ReturnType<typeof button>[]>>((result, item, index) => {
    if (index % 2 === 0) result.push([item]);
    else result[result.length - 1].push(item);
    return result;
  }, []);
  return rows;
}

export async function showServices(
  chatId: string,
  userId: string,
  options: { search?: string; platformIndex?: number; page?: number; returnMode?: "platforms" | "all-services"; returnPage?: number } = {},
) {
  const page = safePage(options.page ?? 0);
  if (await isMaintenanceEnabled("enabled") || await isMaintenanceEnabled("services")) {
    await send(chatId, "Service browsing is temporarily unavailable. Please check again later.", keyboard([[button("Home", "home")]]));
    return;
  }

  if (!options.search) {
    await showPlatformList(chatId, userId);
    return;
  }

  const platforms = await platformRows();
  const platform = options.platformIndex === undefined ? undefined : platforms[options.platformIndex]?.platform;
  const search = options.search.trim().slice(0, 80);
  const pattern = `%${search}%`;
  const predicate = `enabled=true AND ($4::text IS NULL OR platform=$4)
    AND (CAST(id AS text) ILIKE $1 OR name ILIKE $1 OR category ILIKE $1 OR platform ILIKE $1)`;
  const result = await pool.query(
    `SELECT id,name,category,platform FROM nx_services WHERE ${predicate}
     ORDER BY id LIMIT $2 OFFSET $3`,
    [pattern, PAGE_SIZE, page * PAGE_SIZE, platform ?? null],
  );
  const count = await one<{ total: string }>(
    pool,
    `SELECT count(*)::text AS total FROM nx_services
     WHERE enabled=true AND ($2::text IS NULL OR platform=$2)
       AND (CAST(id AS text) ILIKE $1 OR name ILIKE $1 OR category ILIKE $1 OR platform ILIKE $1)`,
    [pattern, platform ?? null],
  );
  const rows = result.rows as Array<Pick<ServiceRow, "id" | "name">>;
  const total = Number(count?.total ?? 0);
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const returnPage = safePage(options.returnPage ?? 0);
  await setSession(userId, "search_results", {
    query: search,
    platformIndex: options.platformIndex,
    page,
    returnMode: options.returnMode,
    returnPage,
  });
  const buttons = rows.map((service) => [
    button(`${service.id}. ${service.name.slice(0, 42)}`, `service:${service.id}`),
  ]);
  const searchPaging = [
    ...(page > 0 ? [button("Previous", `searchpage:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `searchpage:${page + 1}`)] : []),
  ];
  if (searchPaging.length) buttons.push(searchPaging);
  const searchCallback = options.platformIndex !== undefined
    ? `service-search:${options.platformIndex}`
    : options.returnMode === "all-services"
      ? `service-search:all:${returnPage}`
      : "service-search";
  buttons.push([button("New Search", searchCallback)]);
  buttons.push(nav(options.platformIndex !== undefined
    ? `platform:${options.platformIndex}`
    : options.returnMode === "all-services" ? `allservices:${returnPage}` : "services:0"));
  const title = platform ? displayPlatform(platform) : "All platforms";
  await send(
    chatId,
    rows.length
      ? `${title} · Search: “${search}”\nPage ${page + 1} of ${pages}`
      : `No services matched “${search}”${platform ? ` on ${displayPlatform(platform)}` : ""}.`,
    keyboard(buttons),
  );
}

async function showAllServices(chatId: string, userId: string, pageNumber = 0) {
  if (await isMaintenanceEnabled("enabled") || await isMaintenanceEnabled("services")) {
    await send(chatId, "Service browsing is temporarily unavailable. Please check again later.", keyboard([[button("Home", "home")]]));
    return;
  }
  const total = await one<{ total: string }>(pool, "SELECT count(*)::text AS total FROM nx_services WHERE enabled=true");
  const pages = Math.max(1, Math.ceil(Number(total?.total ?? 0) / PAGE_SIZE));
  const page = Math.min(safePage(pageNumber), pages - 1);
  const result = await pool.query(
    "SELECT id,name FROM nx_services WHERE enabled=true ORDER BY id LIMIT $1 OFFSET $2",
    [PAGE_SIZE, page * PAGE_SIZE],
  );
  const rows = result.rows as Array<{ id: number; name: string }>;
  await setSession(userId, "service_browse", { mode: "all-services", page });
  const buttons = rows.map((service) => [
    button(`${service.id}. ${service.name.slice(0, 42)}`, `service:${service.id}`),
  ]);
  const paging = [
    ...(page > 0 ? [button("Previous", `allservices:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `allservices:${page + 1}`)] : []),
  ];
  if (paging.length) buttons.push(paging);
  buttons.push([button("Search All Services", `service-search:all:${page}`)]);
  buttons.push([button("Browse by Platform", "services:0"), button("Home", "home")]);
  const lines = rows.length ? `Page ${page + 1} of ${pages}` : "No services are currently available.";
  await send(chatId, `All Services · ${Number(total?.total ?? 0)} available\n${lines}`, keyboard(buttons));
}

async function showPlatformList(chatId: string, userId: string) {
  const rows = await customerPlatformRows();
  await setSession(userId, "service_browse", { mode: "platforms" });
  rows.push([button("Search All Services", "service-search")]);
  rows.push([button("Favorites", "favorites:0"), button("Recent Services", "recent:0")]);
  rows.push(nav("home"));
  await send(chatId, rows.length > 3 ? "Choose a platform to browse its service types." : "No services are currently available.", keyboard(rows));
}

async function getPlatform(platformIndex: number) {
  if (!Number.isSafeInteger(platformIndex) || platformIndex < 0) return undefined;
  return (await platformRows())[platformIndex]?.platform;
}

async function showServiceTypes(chatId: string, userId: string, platformIndex: number) {
  const platform = await getPlatform(platformIndex);
  if (!platform) {
    await showPlatformList(chatId, userId);
    return;
  }
  const result = await pool.query(
    "SELECT id,name,category FROM nx_services WHERE enabled=true AND platform=$1 ORDER BY id",
    [platform],
  );
  const services = result.rows as Array<Pick<ServiceRow, "id" | "name" | "category">>;
  const counts = new Map<ServiceTypeId, number>();
  for (const service of services) {
    const type = classifyService(service);
    counts.set(type, (counts.get(type) ?? 0) + 1);
  }
  await setSession(userId, "service_browse", { mode: "platform", platformIndex });
  const rows = SERVICE_TYPES
    .filter((type) => counts.has(type.id))
    .map((type) => [button(`${displayType(type.id, platform)} · ${counts.get(type.id)}`, `type:${platformIndex}:${type.id}`)]);
  rows.push([button("Search This Platform", `service-search:${platformIndex}`)]);
  rows.push([button("All Platforms", "services:0"), button("Home", "home")]);
  await send(chatId, `${displayPlatform(platform)}\nChoose a service type.`, keyboard(rows));
}

async function showServiceTypePage(chatId: string, userId: string, platformIndex: number, typeId: string, pageNumber: number) {
  const platform = await getPlatform(platformIndex);
  const type = SERVICE_TYPES.find((item) => item.id === typeId);
  if (!platform || !type) {
    await showPlatformList(chatId, userId);
    return;
  }
  const result = await pool.query(
    "SELECT id,name,category,platform,customer_paise::text,minimum,maximum FROM nx_services WHERE enabled=true AND platform=$1 ORDER BY id",
    [platform],
  );
  const all = result.rows as ServiceRow[];
  const matching = all.filter((service) => classifyService(service) === type.id);
  const pages = Math.max(1, Math.ceil(matching.length / PAGE_SIZE));
  const page = Math.min(safePage(pageNumber), pages - 1);
  const visible = matching.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  await setSession(userId, "service_browse", { mode: "type", platformIndex, typeId, page });
  const rows = visible.map((service) => [
    button(`${service.id}. ${service.name.slice(0, 42)}`, `service:${service.id}`),
  ]);
  const paging = [
    ...(page > 0 ? [button("Previous", `typepage:${platformIndex}:${type.id}:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `typepage:${platformIndex}:${type.id}:${page + 1}`)] : []),
  ];
  if (paging.length) rows.push(paging);
  rows.push([button("Back to Types", `platform:${platformIndex}`), button("Search", `service-search:${platformIndex}`)]);
  rows.push([button("All Platforms", "services:0"), button("Home", "home")]);
  await send(
    chatId,
    `${displayPlatform(platform)} · ${displayType(type.id, platform)}\nPage ${page + 1} of ${pages}`,
    keyboard(rows),
  );
}

async function showLegacyCategory(chatId: string, userId: string, categoryIndex: number, pageNumber = 0) {
  const categories = await pool.query("SELECT DISTINCT category FROM nx_services WHERE enabled=true ORDER BY category");
  const categoryRows = categories.rows as Array<{ category: string }>;
  const category = categoryRows[categoryIndex]?.category;
  if (!category) {
    await showPlatformList(chatId, userId);
    return;
  }
  const total = await one<{ total: string }>(
    pool, "SELECT count(*)::text AS total FROM nx_services WHERE enabled=true AND category=$1", [category],
  );
  const pages = Math.max(1, Math.ceil(Number(total?.total ?? 0) / PAGE_SIZE));
  const page = Math.min(safePage(pageNumber), pages - 1);
  const result = await pool.query(
    "SELECT id,name FROM nx_services WHERE enabled=true AND category=$1 ORDER BY id LIMIT $2 OFFSET $3",
    [category, PAGE_SIZE, page * PAGE_SIZE],
  );
  await setSession(userId, "service_browse", { mode: "legacy-category", categoryIndex, page });
  const rows = (result.rows as Array<{ id: number; name: string }>).map((service) => [
    button(`${service.id}. ${service.name.slice(0, 42)}`, `service:${service.id}`),
  ]);
  const paging = [
    ...(page > 0 ? [button("Previous", `categorypage:${categoryIndex}:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `categorypage:${categoryIndex}:${page + 1}`)] : []),
  ];
  if (paging.length) rows.push(paging);
  rows.push([button("All Platforms", "services:0"), button("Home", "home")]);
  await send(chatId, `${category}\nPage ${page + 1} of ${pages}`, keyboard(rows));
}

async function showService(chatId: string, userId: string, serviceId: number) {
  const service = await one<ServiceRow>(
    pool,
    `SELECT id,name,category,platform,customer_paise::text,minimum,maximum,description,enabled
     FROM nx_services WHERE id=$1`,
    [serviceId],
  );
  if (!service || !service.enabled) {
    await send(chatId, "That service is no longer available.", keyboard([[button("Services", "services:0"), button("Home", "home")]]));
    return;
  }
  const isFavorite = await one<{ present: boolean }>(
    pool, "SELECT true AS present FROM nx_favorites WHERE user_id=$1 AND service_id=$2", [userId, serviceId],
  );
  await pool.query(
    `INSERT INTO nx_recent_services(user_id,service_id,last_used_at) VALUES($1,$2,now())
     ON CONFLICT(user_id,service_id) DO UPDATE SET last_used_at=now()`,
    [userId, serviceId],
  );
  const pricePerThousand = BigInt(service.customer_paise) * 10000n;
  const message = [
    `Service ID: ${service.id}`,
    service.name,
    "",
    `Platform: ${displayPlatform(service.platform)}`,
    `Category: ${service.category}`,
    `Price per 1,000: ${rupees(pricePerThousand)}`,
    `Minimum: ${service.minimum}`,
    `Maximum: ${service.maximum}`,
    `Description: ${service.description ?? ""}`,
  ].join("\n");
  await send(chatId, message, keyboard([
    [button("Order", `orderstart:${service.id}`), button(isFavorite ? "Remove Favorite" : "Add Favorite", `favorite:${service.id}`)],
    [button("Back", "serviceback"), button("Home", "home")],
  ]));
}

async function showFavorites(chatId: string, userId: string, pageNumber = 0) {
  const total = await one<{ total: string }>(
    pool, "SELECT count(*)::text AS total FROM nx_favorites f JOIN nx_services s ON s.id=f.service_id WHERE f.user_id=$1 AND s.enabled=true", [userId],
  );
  const pages = Math.max(1, Math.ceil(Number(total?.total ?? 0) / PAGE_SIZE));
  const page = Math.min(safePage(pageNumber), pages - 1);
  const result = await pool.query(
    `SELECT s.id,s.name FROM nx_favorites f JOIN nx_services s ON s.id=f.service_id
     WHERE f.user_id=$1 AND s.enabled=true ORDER BY f.created_at DESC LIMIT $2 OFFSET $3`,
    [userId, PAGE_SIZE, page * PAGE_SIZE],
  );
  await setSession(userId, "service_browse", { mode: "favorites", page });
  const buttons = (result.rows as Array<{ id: number; name: string }>).map((service) => [
    button(`${service.id}. ${service.name.slice(0, 42)}`, `service:${service.id}`),
  ]);
  const paging = [
    ...(page > 0 ? [button("Previous", `favorites:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `favorites:${page + 1}`)] : []),
  ];
  if (paging.length) buttons.push(paging);
  buttons.push([button("Browse Services", "services:0"), button("Home", "home")]);
  await send(chatId, Number(total?.total ?? 0) > 0 ? "Your favorite services." : "You have not saved any favorite services yet.", keyboard(buttons));
}

async function showRecent(chatId: string, userId: string, pageNumber = 0) {
  const total = await one<{ total: string }>(
    pool, "SELECT count(*)::text AS total FROM nx_recent_services r JOIN nx_services s ON s.id=r.service_id WHERE r.user_id=$1 AND s.enabled=true", [userId],
  );
  const pages = Math.max(1, Math.ceil(Number(total?.total ?? 0) / PAGE_SIZE));
  const page = Math.min(safePage(pageNumber), pages - 1);
  const result = await pool.query(
    `SELECT s.id,s.name FROM nx_recent_services r JOIN nx_services s ON s.id=r.service_id
     WHERE r.user_id=$1 AND s.enabled=true ORDER BY r.last_used_at DESC LIMIT $2 OFFSET $3`,
    [userId, PAGE_SIZE, page * PAGE_SIZE],
  );
  await setSession(userId, "service_browse", { mode: "recent", page });
  const buttons = (result.rows as Array<{ id: number; name: string }>).map((service) => [
    button(`${service.id}. ${service.name.slice(0, 42)}`, `service:${service.id}`),
  ]);
  const paging = [
    ...(page > 0 ? [button("Previous", `recent:${page - 1}`)] : []),
    ...(page + 1 < pages ? [button("Next", `recent:${page + 1}`)] : []),
  ];
  if (paging.length) buttons.push(paging);
  buttons.push([button("Browse Services", "services:0"), button("Home", "home")]);
  await send(chatId, Number(total?.total ?? 0) > 0 ? "Recently viewed or ordered services." : "You have not viewed or ordered a service yet.", keyboard(buttons));
}

async function returnToServiceBrowse(ctx: CallbackContext) {
  const userId = String(ctx.user.id);
  const session = await getSession(userId);
  if (session.state === "search_results" && typeof session.data.query === "string") {
    await showServices(ctx.chatId, userId, {
      search: session.data.query,
      platformIndex: typeof session.data.platformIndex === "number" ? session.data.platformIndex : undefined,
      page: typeof session.data.page === "number" ? session.data.page : 0,
      returnMode: session.data.returnMode === "all-services" ? "all-services" : "platforms",
      returnPage: typeof session.data.returnPage === "number" ? session.data.returnPage : 0,
    });
    return;
  }
  if (session.state !== "service_browse") {
    await showPlatformList(ctx.chatId, userId);
    return;
  }
  const mode = session.data.mode;
  if (mode === "platform" && typeof session.data.platformIndex === "number") {
    await showServiceTypes(ctx.chatId, userId, session.data.platformIndex);
  } else if (mode === "type" && typeof session.data.platformIndex === "number" && typeof session.data.typeId === "string") {
    await showServiceTypePage(ctx.chatId, userId, session.data.platformIndex, session.data.typeId, Number(session.data.page ?? 0));
  } else if (mode === "favorites") {
    await showFavorites(ctx.chatId, userId, Number(session.data.page ?? 0));
  } else if (mode === "recent") {
    await showRecent(ctx.chatId, userId, Number(session.data.page ?? 0));
  } else if (mode === "all-services") {
    await showAllServices(ctx.chatId, userId, Number(session.data.page ?? 0));
  } else if (mode === "legacy-category" && typeof session.data.categoryIndex === "number") {
    await showLegacyCategory(ctx.chatId, userId, session.data.categoryIndex, Number(session.data.page ?? 0));
  } else {
    await showPlatformList(ctx.chatId, userId);
  }
}

export async function handleServiceBrowserCallback(ctx: CallbackContext, data: string) {
  const userId = String(ctx.user.id);
  const [action, a, b, c] = data.split(":");
  if (action === "services") {
    await showServices(ctx.chatId, userId);
    return true;
  }
  if (action === "allservices" && /^\d*$/.test(a ?? "")) {
    await showAllServices(ctx.chatId, userId, Number(a || 0));
    return true;
  }
  if (action === "platform" && /^\d+$/.test(a ?? "")) {
    await showServiceTypes(ctx.chatId, userId, Number(a));
    return true;
  }
  if (action === "type" && /^\d+$/.test(a ?? "") && b) {
    await showServiceTypePage(ctx.chatId, userId, Number(a), b, 0);
    return true;
  }
  if (action === "typepage" && /^\d+$/.test(a ?? "") && b && /^\d+$/.test(c ?? "")) {
    await showServiceTypePage(ctx.chatId, userId, Number(a), b, Number(c));
    return true;
  }
  if (action === "category" && /^\d+$/.test(a ?? "")) {
    await showLegacyCategory(ctx.chatId, userId, Number(a));
    return true;
  }
  if (action === "categorypage" && /^\d+$/.test(a ?? "") && /^\d+$/.test(b ?? "")) {
    await showLegacyCategory(ctx.chatId, userId, Number(a), Number(b));
    return true;
  }
  if (action === "searchpage" && /^\d+$/.test(a ?? "")) {
    const session = await getSession(userId);
    if (session.state !== "search_results" || typeof session.data.query !== "string") {
      await showPlatformList(ctx.chatId, userId);
    } else {
      await showServices(ctx.chatId, userId, {
        search: session.data.query,
        platformIndex: typeof session.data.platformIndex === "number" ? session.data.platformIndex : undefined,
        page: Number(a),
        returnMode: session.data.returnMode === "all-services" ? "all-services" : "platforms",
        returnPage: typeof session.data.returnPage === "number" ? session.data.returnPage : 0,
      });
    }
    return true;
  }
  if (action === "service" && /^\d+$/.test(a ?? "")) {
    await showService(ctx.chatId, userId, Number(a));
    return true;
  }
  if (action === "serviceback") {
    await returnToServiceBrowse(ctx);
    return true;
  }
  if (action === "favorite" && /^\d+$/.test(a ?? "")) {
    const serviceId = Number(a);
    const old = await one<{ service_id: number }>(
      pool, "DELETE FROM nx_favorites WHERE user_id=$1 AND service_id=$2 RETURNING service_id", [userId, serviceId],
    );
    if (!old) {
      await pool.query(
        "INSERT INTO nx_favorites(user_id,service_id) SELECT $1,$2 WHERE EXISTS(SELECT 1 FROM nx_services WHERE id=$2 AND enabled=true) ON CONFLICT DO NOTHING",
        [userId, serviceId],
      );
    }
    await send(ctx.chatId, old ? "Removed from favorites." : "Added to favorites.", keyboard([
      [button("View Service", `service:${serviceId}`), button("Back", "serviceback")],
      [button("Favorites", "favorites:0"), button("Home", "home")],
    ]));
    return true;
  }
  if (action === "favorites" && /^\d*$/.test(a ?? "")) {
    await showFavorites(ctx.chatId, userId, Number(a || 0));
    return true;
  }
  if (action === "recent" && /^\d*$/.test(a ?? "")) {
    await showRecent(ctx.chatId, userId, Number(a || 0));
    return true;
  }
  return false;
}