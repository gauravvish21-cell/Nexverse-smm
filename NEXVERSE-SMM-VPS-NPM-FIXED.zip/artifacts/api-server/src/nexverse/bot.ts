import { logger } from "../lib/logger";
import { config, missingRequiredBotConfiguration } from "./config.mjs";
import { attachReferral, ensureUser, one, pool, transaction } from "./database";
import { handleAdminCallback, handleAdminCommand, handleAdminMessage } from "./admin";
import { handleCustomerCallback, handleCustomerCommand, handleCustomerMessage, homeScreen, setBotUsername } from "./customer";
import { displayName, errorForUser, resetSession, safeAnswer, safeErrorLogFields, send, showExpired, type CallbackContext, type MessageContext } from "./bot-utils";
import { TelegramApiError, telegramCall, type TelegramMessage, type TelegramUpdate, type TelegramUser } from "./telegram-api";
import { outboxStatus, startOutboxWorker, stopOutboxWorker } from "./outbox";

const advisoryLockKey = 827461193;
let started = false;
let polling = false;
let healthy = false;
type AdvisoryClient = { query: (sql: string, values?: unknown[]) => Promise<{ rows: Array<Record<string, unknown>> }>; release: () => void };
const lockHolder: { client?: AdvisoryClient } = {};
let pollTask: Promise<void> | undefined;
let offset = 0;
let lastUpdateAt: string | null = null;
let botUsername = "";

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function telegramPollingPermitted() {
  return process.env.NODE_ENV === "production" || process.env.NEXVERSE_ALLOW_DEV_POLLING === "YES";
}

export function botStatus() {
  return {
    enabled: config.botEnabled && telegramPollingPermitted(),
    configured: missingRequiredBotConfiguration().length === 0,
    running: started && polling,
    healthy,
    username: botUsername || null,
    lastUpdateAt,
    outbox: outboxStatus(),
  };
}

function makeMessageContext(message: TelegramMessage, user: TelegramUser): MessageContext {
  return { user, message, chatId: String(message.chat.id) };
}

function makeCallbackContext(callback: NonNullable<TelegramUpdate["callback_query"]>): CallbackContext | undefined {
  const message = callback.message;
  const chatId = String(message?.chat.id ?? callback.from.id);
  if (message?.chat.type && message.chat.type !== "private") return undefined;
  return { user: callback.from, callback, chatId, message };
}

async function isSuspended(userId: string) {
  const row = await one<{ suspended: boolean }>(pool, "SELECT suspended FROM nx_users WHERE id=$1", [userId]);
  return row?.suspended === true;
}

async function runStart(ctx: MessageContext, payload = "") {
  const userId = String(ctx.user.id);
  await ensureUser({ id: userId, username: ctx.user.username, name: displayName(ctx.user) });
  if (payload.startsWith("ref_")) await attachReferral(userId, payload.slice(4));
  if (await isSuspended(userId)) {
    await send(ctx.chatId, `This account is suspended. Contact support at ${config.support}.`);
    return;
  }
  await resetSession(userId, true);
  await homeScreen(ctx.chatId, userId);
}

async function executeCommand(ctx: MessageContext, rawText: string) {
  const parts = rawText.trim().split(/\s+/);
  let command = (parts.shift() ?? "").split("@")[0].toLowerCase();
  const args = parts;
  if (command === "/start") {
    await runStart(ctx, args[0] ?? "");
    return true;
  }
  const userId = String(ctx.user.id);
  if (await isSuspended(userId)) {
    if (command === "/support") return handleCustomerCommand(ctx, command, args);
    await send(ctx.chatId, `This account is suspended. Contact support at ${config.support}.`);
    return true;
  }
  if (command === "/cancel") {
    await resetSession(userId, true);
    await send(ctx.chatId, "Cancelled. No order or wallet changes were made.", {
      inline_keyboard: [[{ text: "Home", callback_data: "home" }]],
    });
    return true;
  }
  if (command === "/back") {
    await resetSession(userId, true);
    await homeScreen(ctx.chatId, userId);
    return true;
  }
  if (command === "/admin") return handleAdminCommand(ctx, args);
  const handled = await handleCustomerCommand(ctx, command, args);
  if (handled) return true;
  return false;
}

async function handleMessage(message: TelegramMessage) {
  const user = message.from;
  if (!user || user.is_bot || message.chat.type !== "private") return;
  const ctx = makeMessageContext(message, user);
  await ensureUser({ id: String(user.id), username: user.username, name: displayName(user) });
  if (message.text?.trim().startsWith("/")) {
    const handled = await executeCommand(ctx, message.text);
    if (handled) return;
  }
  if (await isSuspended(String(user.id))) {
    await send(ctx.chatId, `This account is suspended. Contact support at ${config.support}.`);
    return;
  }
  if (await handleAdminMessage(ctx)) return;
  if (await handleCustomerMessage(ctx)) return;
  await send(ctx.chatId, "Use the menu below or send /help.", {
    inline_keyboard: [[{ text: "Home", callback_data: "home" }, { text: "Help", callback_data: "help" }]],
  });
}

async function handleCallback(update: TelegramUpdate) {
  const callback = update.callback_query;
  if (!callback || callback.from.is_bot) return;
  const ctx = makeCallbackContext(callback);
  if (!ctx) {
    await safeAnswer(callback, "Open the bot in a private chat to continue.", true);
    return;
  }
  await ensureUser({ id: String(ctx.user.id), username: ctx.user.username, name: displayName(ctx.user) });
  await safeAnswer(callback);
  const data = callback.data ?? "";
  if (!data || Buffer.byteLength(data, "utf8") > 64 || /[\u0000-\u001f]/.test(data)) {
    await showExpired(ctx.chatId);
    return;
  }
  if (await isSuspended(String(ctx.user.id))) {
    await send(ctx.chatId, `This account is suspended. Contact support at ${config.support}.`);
    return;
  }
  if (await handleAdminCallback(ctx, data)) return;
  if (await handleCustomerCallback(ctx, data)) return;
  await showExpired(ctx.chatId);
}

async function processUpdate(update: TelegramUpdate) {
  if (update.message) await handleMessage(update.message);
  if (update.callback_query) await handleCallback(update);
}

export async function persistCompletedUpdate(updateId: number) {
  await transaction(async (db) => {
    await db.query("INSERT INTO nx_updates(update_id) VALUES($1) ON CONFLICT(update_id) DO NOTHING", [updateId]);
    await db.query(
      "INSERT INTO nx_runtime(key,value) VALUES('telegram_offset',$1) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value",
      [String(updateId + 1)],
    );
  });
  offset = updateId + 1;
  lastUpdateAt = new Date().toISOString();
}

async function alreadyProcessed(updateId: number) {
  return Boolean(await one<{ update_id: string }>(pool, "SELECT update_id::text FROM nx_updates WHERE update_id=$1", [updateId]));
}

async function pollingLoop() {
  polling = true;
  healthy = true;
  while (started) {
    try {
      const updates = await telegramCall<TelegramUpdate[]>("getUpdates", {
        offset,
        timeout: 25,
        allowed_updates: ["message", "callback_query"],
      });
      healthy = true;
      for (const update of updates) {
        if (update.update_id < offset) continue;
        if (await alreadyProcessed(update.update_id)) {
          await persistCompletedUpdate(update.update_id);
          continue;
        }
        try {
          await processUpdate(update);
          await persistCompletedUpdate(update.update_id);
        } catch (error) {
          healthy = false;
          const callbackData = update.callback_query?.data ?? "";
          const callbackParts = callbackData.split(":");
          const callbackId = callbackParts.find((part) => /^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(part));
          const actorId = update.callback_query?.from.id ?? update.message?.from?.id;
          const command = update.message?.text?.trim().match(/^\/[A-Za-z0-9_]+/)?.[0];
          logger.error(
            {
              ...safeErrorLogFields(error),
              updateId: update.update_id,
              actorId: actorId === undefined ? undefined : String(actorId),
              updateType: update.callback_query ? "callback" : "message",
              action: update.callback_query
                ? callbackParts.slice(0, 3).join(":")
                : command ?? "message",
              recordId: callbackId,
            },
            "Telegram update handling failed; update will be retried",
          );
          await wait(1500);
          break;
        }
      }
    } catch (error) {
      healthy = false;
      const apiError = error instanceof TelegramApiError ? error : undefined;
      logger.warn({ errorCode: apiError?.errorCode ?? "POLL", retryAfter: apiError?.retryAfter }, "Telegram polling failed");
      await wait(apiError?.errorCode === 401 ? 30000 : 5000);
    }
  }
  polling = false;
}

export async function startTelegramBot() {
  if (started) return;
  if (!telegramPollingPermitted()) {
    healthy = true;
    logger.info("Telegram polling and outbox delivery are disabled in development to avoid competing with production.");
    return;
  }
  const missingConfiguration = missingRequiredBotConfiguration();
  if (missingConfiguration.length > 0) {
    healthy = false;
    logger.error(
      { missingConfiguration },
      "NEXVERSE bot startup blocked: required credentials are missing from server configuration",
    );
    return;
  }
  if (!config.botEnabled) {
    logger.info("Telegram bot is disabled by server configuration");
    return;
  }
  const client = await pool.connect() as unknown as AdvisoryClient;
  lockHolder.client = client;
  const lock = await client.query("SELECT pg_try_advisory_lock($1) AS locked", [advisoryLockKey]);
  if (!lock.rows[0]?.locked) {
    client.release();
    lockHolder.client = undefined;
    logger.warn("Telegram polling is already active in another API server process");
    return;
  }
  try {
    const me = await telegramCall<TelegramUser>("getMe", {});
    botUsername = me.username ?? "";
    if (botUsername) setBotUsername(botUsername);
    const savedOffset = await one<{ value: string }>(pool, "SELECT value FROM nx_runtime WHERE key='telegram_offset'");
    offset = Math.max(0, Number(savedOffset?.value ?? 0));
    if (!Number.isSafeInteger(offset)) throw new Error("Persisted Telegram offset is invalid.");
    started = true;
    if (config.deliveryEnabled) startOutboxWorker();
    else logger.info("Telegram outbox delivery is disabled by server configuration");
    pollTask = pollingLoop();
    logger.info({ username: botUsername || "not available" }, "Telegram bot polling started");
  } catch (error) {
    await client.query("SELECT pg_advisory_unlock($1)", [advisoryLockKey]).catch(() => undefined);
    client.release();
    lockHolder.client = undefined;
    throw error;
  }
}

export async function stopTelegramBot() {
  started = false;
  await pollTask?.catch(() => undefined);
  pollTask = undefined;
  await stopOutboxWorker();
  const client = lockHolder.client;
  if (client) {
    await client.query("SELECT pg_advisory_unlock($1)", [advisoryLockKey]).catch(() => undefined);
    client.release();
    lockHolder.client = undefined;
  }
  healthy = false;
  polling = false;
}

export async function getBotRuntimeHealth() {
  let database = false;
  try {
    await pool.query("SELECT 1");
    database = true;
  } catch {
    database = false;
  }
  return { database, bot: botStatus(), outbox: outboxStatus() };
}