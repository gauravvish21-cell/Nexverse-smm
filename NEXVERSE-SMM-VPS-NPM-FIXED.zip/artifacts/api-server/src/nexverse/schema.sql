-- Development schema source of truth. Applied explicitly, never at production startup.
CREATE TABLE IF NOT EXISTS nx_users (
 id bigint PRIMARY KEY, username text, name text NOT NULL, email text,
 referral_code text UNIQUE NOT NULL, suspended boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_accounts (
 user_id bigint PRIMARY KEY REFERENCES nx_users(id), password_hash text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_sessions (
 user_id bigint PRIMARY KEY REFERENCES nx_users(id), state text NOT NULL DEFAULT 'menu',
 data jsonb NOT NULL DEFAULT '{}', admin_until timestamptz, failures integer NOT NULL DEFAULT 0,
 locked_until timestamptz, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_wallets (
 user_id bigint PRIMARY KEY REFERENCES nx_users(id), balance bigint NOT NULL DEFAULT 0 CHECK(balance>=0),
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_ledger (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id),
 type text NOT NULL CHECK(type IN('DEPOSIT','ORDER_DEBIT','REFUND','ADMIN_ADJUSTMENT','REDEEM','BONUS','REVERSAL')),
 amount bigint NOT NULL CHECK(amount<>0), balance_before bigint NOT NULL CHECK(balance_before>=0),
 balance_after bigint NOT NULL CHECK(balance_after>=0), reference_id text NOT NULL,
 status text NOT NULL DEFAULT 'COMPLETED', created_by bigint REFERENCES nx_users(id),
 description text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(balance_after=balance_before+amount), UNIQUE(user_id,type,reference_id)
);
CREATE INDEX IF NOT EXISTS nx_ledger_user_time ON nx_ledger(user_id,created_at DESC);
CREATE TABLE IF NOT EXISTS nx_services (
 id integer PRIMARY KEY, name text NOT NULL, category text NOT NULL, platform text NOT NULL,
 supplier_paise bigint NOT NULL CHECK(supplier_paise>0), customer_paise bigint NOT NULL CHECK(customer_paise=supplier_paise*2),
 minimum integer NOT NULL CHECK(minimum>0), maximum integer NOT NULL CHECK(maximum>=minimum),
 description text NOT NULL, enabled boolean NOT NULL DEFAULT true, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_order_drafts (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id), service_id integer NOT NULL REFERENCES nx_services(id),
 quantity integer NOT NULL, target text NOT NULL, quoted_amount bigint NOT NULL, extras text NOT NULL DEFAULT '',
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_orders (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id), service_id integer NOT NULL REFERENCES nx_services(id),
 draft_id uuid NOT NULL UNIQUE REFERENCES nx_order_drafts(id), quantity integer NOT NULL, target text NOT NULL,
 amount bigint NOT NULL CHECK(amount>0), service_name text NOT NULL, extras text NOT NULL DEFAULT '',
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN('PENDING','PROCESSING','COMPLETED','FAILED','CANCELLED','REJECTED','REFUNDED')),
 internal_notes text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
DO $order_status_failed_migration$
BEGIN
 IF NOT EXISTS (
   SELECT 1
   FROM pg_constraint
   WHERE conrelid='nx_orders'::regclass
     AND conname='nx_orders_status_check'
     AND pg_get_constraintdef(oid) ILIKE '%FAILED%'
 ) THEN
   ALTER TABLE nx_orders DROP CONSTRAINT IF EXISTS nx_orders_status_check;
   ALTER TABLE nx_orders ADD CONSTRAINT nx_orders_status_check
     CHECK(status IN('PENDING','PROCESSING','COMPLETED','FAILED','CANCELLED','REJECTED','REFUNDED'));
 END IF;
END
$order_status_failed_migration$;
CREATE INDEX IF NOT EXISTS nx_orders_user_time ON nx_orders(user_id,created_at DESC);
CREATE TABLE IF NOT EXISTS nx_order_items (
 order_id uuid PRIMARY KEY REFERENCES nx_orders(id), service_id integer NOT NULL REFERENCES nx_services(id),
 quantity integer NOT NULL, customer_paise bigint NOT NULL, amount bigint NOT NULL
);
CREATE TABLE IF NOT EXISTS nx_refunds (
 order_id uuid PRIMARY KEY REFERENCES nx_orders(id), debit_id uuid UNIQUE NOT NULL REFERENCES nx_ledger(id),
 ledger_id uuid UNIQUE NOT NULL REFERENCES nx_ledger(id), amount bigint NOT NULL CHECK(amount>0),
 admin_id bigint NOT NULL REFERENCES nx_users(id), reason text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_assets (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id), object_key text UNIQUE NOT NULL,
 telegram_file_id text NOT NULL, content_type text NOT NULL, size integer NOT NULL CHECK(size>0),
 sha256 text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_payments (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id),
 username text, user_name text NOT NULL, email text, amount bigint NOT NULL CHECK(amount>0),
 currency text NOT NULL DEFAULT 'INR' CHECK(currency='INR'), utr text NOT NULL,
 screenshot_id uuid NOT NULL REFERENCES nx_assets(id), request_key text NOT NULL UNIQUE,
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN('PENDING','APPROVED','REJECTED')),
 reviewed_by bigint REFERENCES nx_users(id), reviewed_at timestamptz, rejection_reason text,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS nx_payments_active_utr ON nx_payments(utr) WHERE status IN('PENDING','APPROVED');
CREATE UNIQUE INDEX IF NOT EXISTS nx_payments_utr_unique ON nx_payments(utr);
CREATE INDEX IF NOT EXISTS nx_payments_user_time ON nx_payments(user_id,created_at DESC);
CREATE TABLE IF NOT EXISTS nx_redeem_codes (
 code text PRIMARY KEY, amount bigint NOT NULL CHECK(amount>0), maximum_redemptions integer NOT NULL CHECK(maximum_redemptions>0),
 current_redemptions integer NOT NULL DEFAULT 0 CHECK(current_redemptions>=0 AND current_redemptions<=maximum_redemptions),
 per_user_limit integer NOT NULL DEFAULT 1 CHECK(per_user_limit=1), starts_at timestamptz NOT NULL DEFAULT now(),
 expiry timestamptz, enabled boolean NOT NULL DEFAULT true, description text NOT NULL DEFAULT '',
 created_by bigint NOT NULL REFERENCES nx_users(id), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_redemptions (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id), code text NOT NULL REFERENCES nx_redeem_codes(code),
 amount bigint NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(user_id,code)
);
CREATE TABLE IF NOT EXISTS nx_coupons (
 code text PRIMARY KEY, percent integer NOT NULL CHECK(percent BETWEEN 1 AND 100), enabled boolean NOT NULL DEFAULT true,
 expiry timestamptz, maximum_uses integer NOT NULL CHECK(maximum_uses>0), used integer NOT NULL DEFAULT 0 CHECK(used<=maximum_uses),
 created_by bigint NOT NULL REFERENCES nx_users(id), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_coupon_uses (
 code text NOT NULL REFERENCES nx_coupons(code), user_id bigint NOT NULL REFERENCES nx_users(id),
 order_id uuid UNIQUE NOT NULL REFERENCES nx_orders(id), discount bigint NOT NULL, PRIMARY KEY(code,user_id)
);
CREATE TABLE IF NOT EXISTS nx_tickets (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id), subject text NOT NULL,
 status text NOT NULL DEFAULT 'OPEN' CHECK(status IN('OPEN','IN_PROGRESS','WAITING','RESOLVED','CLOSED')),
 assigned_to bigint REFERENCES nx_users(id), created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_ticket_messages (
 id uuid PRIMARY KEY, ticket_id uuid NOT NULL REFERENCES nx_tickets(id), sender_id bigint NOT NULL REFERENCES nx_users(id),
 body text NOT NULL, is_admin boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_announcements (
 id uuid PRIMARY KEY, body text NOT NULL, audience jsonb NOT NULL DEFAULT '[]', sent_at timestamptz,
 deleted_at timestamptz, created_by bigint NOT NULL REFERENCES nx_users(id), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_notifications (
 id uuid PRIMARY KEY, user_id bigint NOT NULL REFERENCES nx_users(id), kind text NOT NULL, body text NOT NULL,
 dedupe_key text NOT NULL UNIQUE, read_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_referrals (
 referred_id bigint PRIMARY KEY REFERENCES nx_users(id), referrer_id bigint NOT NULL REFERENCES nx_users(id),
 reward_status text NOT NULL DEFAULT 'PENDING' CHECK(reward_status IN('PENDING','REWARDED')),
 amount bigint NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now(), rewarded_at timestamptz,
 CHECK(referred_id<>referrer_id)
);
CREATE TABLE IF NOT EXISTS nx_audit (
 id uuid PRIMARY KEY, actor_id bigint REFERENCES nx_users(id), action text NOT NULL, target text NOT NULL,
 amount bigint, details jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_settings (
 key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_operations (
 key text PRIMARY KEY, actor_id bigint NOT NULL REFERENCES nx_users(id), kind text NOT NULL, data jsonb NOT NULL,
 result jsonb, confirmed_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_updates (
 update_id bigint PRIMARY KEY, processed_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS nx_runtime (
 key text PRIMARY KEY, value text NOT NULL
);
CREATE TABLE IF NOT EXISTS nx_outbox (
 id uuid PRIMARY KEY, method text NOT NULL, params jsonb NOT NULL, dedupe_key text NOT NULL UNIQUE,
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN('PENDING','SENDING','SENT','FAILED')),
 attempts integer NOT NULL DEFAULT 0, available_at timestamptz NOT NULL DEFAULT now(),
 lease_until timestamptz, last_error_code text, sent_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS nx_outbox_work ON nx_outbox(status,available_at);
INSERT INTO nx_settings(key,value) VALUES
 ('maintenance','{"enabled":false,"message":"NEXVERSE SMM is undergoing maintenance. Please try again later."}'),
 ('referral','{"enabled":false,"reward":"10000000","minimum_deposit":"100000000"}')
 ON CONFLICT(key) DO NOTHING;

-- Additive features. All statements are safe to run repeatedly.
ALTER TABLE nx_order_drafts ADD COLUMN IF NOT EXISTS coupon_code text;
ALTER TABLE nx_order_drafts ADD COLUMN IF NOT EXISTS discount bigint NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS nx_favorites (
 user_id bigint NOT NULL REFERENCES nx_users(id), service_id integer NOT NULL REFERENCES nx_services(id),
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(user_id,service_id)
);
CREATE TABLE IF NOT EXISTS nx_recent_services (
 user_id bigint NOT NULL REFERENCES nx_users(id), service_id integer NOT NULL REFERENCES nx_services(id),
 last_used_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(user_id,service_id)
);
CREATE INDEX IF NOT EXISTS nx_recent_services_user_time ON nx_recent_services(user_id,last_used_at DESC);
CREATE TABLE IF NOT EXISTS nx_admin_roles (
 user_id bigint PRIMARY KEY REFERENCES nx_users(id),
 role text NOT NULL CHECK(role IN('SUPER_ADMIN','PAYMENT_ADMIN','ORDER_MANAGER','SERVICE_MANAGER','SUPPORT_AGENT','ANALYST')),
 assigned_by bigint NOT NULL REFERENCES nx_users(id),
 updated_at timestamptz NOT NULL DEFAULT now()
);