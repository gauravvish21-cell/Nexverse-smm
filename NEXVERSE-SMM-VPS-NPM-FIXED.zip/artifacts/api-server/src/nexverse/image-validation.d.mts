export function detectImageContentType(
  bytes: Uint8Array,
): "image/jpeg" | "image/png" | "image/webp" | undefined;